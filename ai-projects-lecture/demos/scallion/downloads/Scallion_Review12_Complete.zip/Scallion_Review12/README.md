# 青葱工坊 · 机械修订12

基于用户提供的修订11工程继续迭代。新增双通道输送与翻转上料、外侧料位交接、成袋站底封、独立连袋检重、升降移载和带扶正圈的24位成品盘。

- 浏览 `dist/index.html`（通过静态HTTP服务）。三维使用本地Three.js依赖；无WebGL时仍可用同一时序的SVG流程动画。
- `engineering/build12.py` 构建名义CAD与GLB，需要CadQuery/OpenCascade、NumPy、SciPy。
- `node check12.mjs` 检查20,001个时刻的关节限位、分度联锁及8次物料交接的位置和姿态连续性，需要Three.js。
- `engineering/check_collision12.py` 使用python-fcl筛查新增与变更刚体。它不表示连续时间、软膜、含全部管路的整机零干涉。
- `engineering/package12.py` 以STEPCAF重读层级并生成SW装配交换包；无原生SW运行环境。

自动上料从根向一致的双通道输送来料开始，不宣称随机缠绕大葱已实现全自动解缠理料。称重为整袋毛重，净重需扣实测袋重；示例读数不是真实传感器数据。包装顶部开口，底封后检重，末站复检。24位成品盘满后停止，取料与空盘更换尚未自动化。

本版保留旧版管路未关闭事项。请以 `dist/downloads/review12_checks.json`、`rigid_screen12.json`、`mount12.json` 和 `sw_assembly_checks12.json` 的实际范围理解检查结果。本版是设计预览及装配交换草案，不是生产制造放行文件。
