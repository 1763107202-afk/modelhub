// Same constant-length neutral-line calculation as engineering/service_routes.py.
const sub=(a,b)=>a.map((x,i)=>x-b[i]),dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),norm=a=>Math.hypot(...a);
export function hosePoints(a,b,normal,length,count=33,straight=false){
 const d=sub(b,a),dd=dot(d,d);let n=normal.map((x,i)=>x-d[i]*dot(normal,d)/Math.max(dd,1e-12));
 if(norm(n)<1e-7){const c=Math.abs(d[2])<.8*norm(d)?[0,0,1]:[0,1,0];n=[d[1]*c[2]-d[2]*c[1],d[2]*c[0]-d[0]*c[2],d[0]*c[1]-d[1]*c[0]];}
 const nn=norm(n);n=n.map(x=>x/nn);
 const points=h=>Array.from({length:count},(_,i)=>{const u=i/(count-1);return a.map((x,j)=>x+d[j]*u+(straight?0:4*u*(1-u)*n[j]*h));});
 if(straight)return points(0);
 let lo=0,hi=Math.max(length,1);
 for(let k=0;k<42;k++){const mid=(lo+hi)/2,q=points(mid);let l=0;for(let i=1;i<q.length;i++)l+=norm(sub(q[i],q[i-1]));if(l<length)lo=mid;else hi=mid;}
 return points((lo+hi)/2);
}

export function guidedHosePoints(a,b,u,v,length,radius=.06,steps=32){
 const d=dot(sub(b,a),u),arc=2*radius*steps*Math.sin(Math.PI/(2*steps)),turn=(length+d-arc)/2;
 const calc=(x,y)=>a.map((c,i)=>c+x*u[i]+y*v[i]);const ps=[a,calc(turn,0)];
 for(let i=1;i<=steps;i++){const t=-Math.PI/2+Math.PI*i/steps;ps.push(calc(turn+radius*Math.cos(t),radius*(1+Math.sin(t))));}ps.push(b);return ps;
}
export function routedPoints(cfg,ports,getWorldPoint,getDirection){
 if(cfg.path)return cfg.path.points.map(point=>getWorldPoint({parent:cfg.path.parent,point}));
 const a=getWorldPoint(ports[cfg.start]),b=getWorldPoint(ports[cfg.end]);
 if(cfg.guided)return guidedHosePoints(a,b,getDirection(cfg.basis,cfg.guided.u_axis??[1,0,0]),getDirection(cfg.basis,cfg.guided.v_axis??[0,1,0]),cfg.length_m,cfg.guided.radius,cfg.guided.steps);
 return hosePoints(a,b,getDirection(cfg.basis,cfg.normal),cfg.length_m,33,cfg.straight);
}
