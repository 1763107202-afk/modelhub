import json,time,os
from pathlib import Path
import numpy as np
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
import machine as m
k=m.k
by={p['name']:p for p in m.PART};cache={}
def obj(n):
 if n not in cache:
  p=by[n];s=k.shape_for(p['kind'],p['dims']).moved(k.GL[p['parent']]*k.loc(p));bb=s.BoundingBox();cache[n]=(s,np.array([bb.xmin,bb.ymin,bb.zmin]),np.array([bb.xmax,bb.ymax,bb.zmax]))
 return cache[n]
selected=set(os.environ.get('PARTS','').split(','))-{''}
previous=json.loads(Path('dist/downloads/mount_checks.json').read_text()) if selected else None
fail=[];checked=[];unknown=[];start=time.time()
for link in m.MOUNTS:
 a,b=link['part'],link['support']
 if selected and a not in selected and b not in selected:continue
 if a not in by or b not in by:unknown.append(link);continue
 if not by[a]['cad'] or not by[b]['cad']:continue
 if link['type'] not in ['rigid','bolted','flange']:continue
 sa,la,ha=obj(a);sb,lb,hb=obj(b);lower=np.linalg.norm(np.maximum(0,np.maximum(la-hb,lb-ha)))
 if lower>.0003:dist=float(lower);method='AABB lower bound'
 else:
  ds=BRepExtrema_DistShapeShape(sa.wrapped,sb.wrapped);ds.Perform();dist=ds.Value();method='exact OCC distance'
 rec=dict(a=a,b=b,gap_mm=round(dist*1000,4),method=method)
 checked.append(rec)
 if dist>.0003:fail.append(rec)
if selected:
 old=[r for r in previous['checks'] if r['a'] not in selected and r['b'] not in selected]
 checked=old+checked
 fail=[r for r in checked if r['gap_mm']>.3]
fail.sort(key=lambda x:-x['gap_mm'])
out={'rigid_mounts_checked':len(checked),'gaps_over_0p3mm':fail,'unknown_supports':unknown,'checks':checked,'elapsed_s':time.time()-start,'scope':'Static nominal assembly. Fast AABB lower bound rejects remote surfaces; OCC confirms nearby contacts. This does not certify fastener preload or global collision freedom.'}
p=Path('dist/downloads/mount_checks.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='checks'},ensure_ascii=False,indent=2),flush=True)
