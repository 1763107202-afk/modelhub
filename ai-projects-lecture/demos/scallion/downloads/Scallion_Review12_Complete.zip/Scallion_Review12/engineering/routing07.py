"""Supported mains, local valve plumbing and explicit U-return service carriers.
The routing describes nominal geometry. Clearance results are separate evidence.
"""
import math,json,re
import numpy as np
import cadquery as cq

def rounded(points,radius=.020,arc_steps=8):
 pts=[np.array(p,float) for p in points];pts=[p for i,p in enumerate(pts) if i==0 or np.linalg.norm(p-pts[i-1])>1e-7]
 # Drop collinear intermediate vertices before setting tangent arcs.
 changed=True
 while changed and len(pts)>2:
  changed=False
  for i in range(1,len(pts)-1):
   u=pts[i]-pts[i-1];v=pts[i+1]-pts[i]
   if np.linalg.norm(np.cross(u,v))<1e-9 and np.dot(u,v)>0:pts.pop(i);changed=True;break
 out=[pts[0]];segments=[];start=pts[0];minimum=1e6
 for i in range(1,len(pts)-1):
  a,b,c=pts[i-1:i+2];u=(b-a)/np.linalg.norm(b-a);v=(c-b)/np.linalg.norm(c-b);co=np.clip(np.dot(u,v),-1,1);theta=math.acos(co)
  if theta<1e-6:continue
  tangent=math.tan(theta/2);cut=min(radius*tangent,(.9 if i==1 else .44)*np.linalg.norm(b-a),(.9 if i==len(pts)-2 else .44)*np.linalg.norm(c-b));r=cut/tangent;minimum=min(minimum,r)
  pin=b-u*cut;pout=b+v*cut;perp=(v-u*co)/math.sin(theta);centre=pin+perp*r;mid=centre+((pin-centre)+(pout-centre))/np.linalg.norm((pin-centre)+(pout-centre))*r
  if np.linalg.norm(pin-start)>1e-7:segments.append(['L',start.tolist(),pin.tolist()]);out.append(pin)
  segments.append(['A',pin.tolist(),mid.tolist(),pout.tolist()])
  for t in np.linspace(0,theta,arc_steps+1)[1:]:out.append(centre+(pin-centre)*math.cos(t)+u*r*math.sin(t))
  start=pout
 if np.linalg.norm(pts[-1]-start)>1e-7:segments.append(['L',start.tolist(),pts[-1].tolist()]);out.append(pts[-1])
 return np.asarray(out),segments,minimum

def u_points(a,b,u,v,length,radius=.060,steps=32):
 a,b,u,v=map(lambda p:np.array(p,float),(a,b,u,v));d=float(np.dot(b-a,u));arc=2*radius*steps*math.sin(math.pi/(2*steps));turn=(length+d-arc)/2
 ps=[a,a+turn*u]
 for t in np.linspace(-math.pi/2,math.pi/2,steps+1)[1:]:ps.append(a+(turn+radius*math.cos(t))*u+radius*(1+math.sin(t))*v)
 ps.append(b)
 return np.array(ps)

def route_points(rt,ports,worlds):
 def point(p):return (worlds[p['parent']]@np.r_[p['point'],1])[:3]
 if rt.get('path'):
  p=rt['path'];pts=np.array(p['points']);return (np.c_[pts,np.ones(len(pts))]@worlds[p['parent']].T)[:,:3]
 a,b=point(ports[rt['start']]),point(ports[rt['end']]);W=worlds[rt['basis']]
 if rt.get('guided'):return u_points(a,b,W[:3,:3]@rt['guided'].get('u_axis',[1,0,0]),W[:3,:3]@rt['guided'].get('v_axis',[0,1,0]),rt['length_m'],rt['guided']['radius'],rt['guided']['steps'])
 from service_routes import loop_points
 return loop_points(a,b,W[:3,:3]@rt['normal'],rt['length_m'])

def install(m,svc):
 k=m.k;ports=svc['ports'];routes=svc['routes'];internal=svc['internal_connections'];by={p['name']:p for p in m.PART};gb={g['name']:g for g in m.GROUP}
 def part(n):return next(p for p in m.PART if p['name']==n)
 def tip(p):return np.array(p['point'],float)
 def world(p):return (k.GM[p['parent']]@np.r_[p['point'],1])[:3]
 def in_parent(p,parent):return (np.linalg.inv(k.GM[parent])@np.r_[world(p),1])[:3]
 def tie(*ns):internal.append(list(ns))
 def delete(names):
  names=set(names);m.PART[:]=[p for p in m.PART if p['name'] not in names];m.MOUNTS[:]=[p for p in m.MOUNTS if p['part'] not in names]
 def newport(n,parent,pt,body,medium='air',normal=(0,1,0),ro=.004):
  pt=np.array(pt,float);v=np.array(normal,float);ports[n]=dict(name=n,parent=parent,point=pt.tolist(),body=body,medium=medium)
  m.ring('fit_'+n,pt-v*.020,pt,ro+.0025,max(.001,ro*.70),parent,'chrome',body)
  return n
 def moveport(n,pt,normal=None):
  p=ports[n];delta=np.array(pt)-tip(p);p['point']=list(pt);f=next((x for x in m.PART if x['name']=='fit_'+n),None)
  if f:
   if normal is None:
    for q in f['dims'][:2]:q[:]=(np.array(q)+delta).tolist()
   else:f['dims'][:2]=[(np.array(pt)-np.array(normal)*.020).tolist(),list(pt)]
 def route(n):return next(r for r in routes if r['name']==n)
 def common(a,b):
  chain=[];p=ports[a]['parent']
  while p:chain.append(p);p=gb[p]['parent']
  p=ports[b]['parent']
  while p not in chain:p=gb[p]['parent']
  return p
 def addroute(n,a,b,medium='air',ro=.004):
  r=dict(name=n,node='hose_'+n,start=a,end=b,medium=medium,outer_radius=ro,inner_radius=ro*.70,length_m=0,normal=[0,1,0],basis=common(a,b),samples=33)
  routes.append(r);m.p(r['node'],'service_tube',[[[0,0,0],[.01,0,0]],ro,ro*.70],parent=r['basis'],mat=medium,join='端接软管');return r
 def fixed(r,waypoints=None,parent=None,R=.020):
  parent=parent or common(r['start'],r['end']);A=in_parent(ports[r['start']],parent);B=in_parent(ports[r['end']],parent)
  controls=[A,*([] if waypoints is None else waypoints),B];ps,segs,minR=rounded(controls,R)
  p=part(r['node']);p.update(parent=parent,pos=[0,0,0],kind='service_tube',dims=[ps.tolist(),r['outer_radius'],r['inner_radius'],segs],support=ports[r['start']]['body'])
  r.update(length_m=float(np.linalg.norm(np.diff(ps,axis=0),axis=1).sum()),path=dict(parent=parent,points=ps.tolist()),minimum_design_bend_m=None if minR>100 else minR,basis=parent)
  r.pop('straight',None);return r
 # Synchronise the relocated rigid mains and stationary union support.
 for i in range(6):
  ports[f'A_RING_{i}']['point'][1]=.210;ports[f'A_STATION_{i}']['point'][1]=.210
 part('union_mast_cap')['pos']=[.70,1.642,.35];moveport('A_UNION_FEED',[.70,1.663,.35])
 part('slipring_rotor_extension')['dims'][0][1]=1.572
 # Shorter wash plumbing is below the main clamp plane.
 for n in ['A_KNIFE_HEAD','W_HEAD']:
  p=ports[n];q=tip(p);q[1]=.55;moveport(n,q)
 part('wash_air_header_cross')['dims'][0][1]=.522;part('wash_air_header_cross')['dims'][1][1]=.522
 for n,p in ports.items():
  if n.startswith(('W_MANIFOLD_','KNIFE_')):q=tip(p);q[1]=.530;moveport(n,q)
 # Fixed risers are outside the swept stage supports.
 for q in part('peel_fixed_pipe_stand')['dims'][:2]:q[2]=.50
 moveport('A_PEEL_FIXED',[1.20,.78,.50]);stand=m.beam('peel_riser_base_reach',[1.20,.415,.22],[1.20,.415,.50],.030,'station2','frame_1_0.22');m.set_support('peel_fixed_pipe_stand',stand)
 for z in [-.22,.22]:
  for q in part('wash_fixed_pipe_stand_'+str(z))['dims'][:2]:q[0]=1.65
 moveport('A_KNIFE_FIXED',[1.65,.78,-.22]);moveport('W_FIXED',[1.65,.78,.22])
 tray=part('wash_tray');tray['kind']='sector_tray';tray['dims']=[[[-.2135,-.125],[.3061,-.425],[.3061,.425],[-.2135,.125]],.22,.16,.024,.006]
 for z in [-.27,.27]:
  p=part('wash_tray_rim_z_'+str(z));s=math.copysign(1,z);p.update(kind='wall_line',dims=[[.2165,.549,s*.125],[.7361,.549,s*.425],.040,.004],pos=[0,0,0])
 for n,x,z in [('wash_tray_rim_x_0.15',.2165,.125),('wash_tray_rim_x_0.71',.7361,.425)]:part(n).update(kind='wall_line',dims=[[x,.549,-z],[x,.549,z],.040,.004],pos=[0,0,0])
 for z in [-.23,.23]:
  part('tray_stand_0.2_'+str(z))['pos']=[.300,.480,math.copysign(.130,z)]
  bridge=m.beam('tray_inner_support_'+str(z),[.300,.415,math.copysign(.22,z)],[.300,.415,math.copysign(.13,z)],.030,'station3','frame_2_'+str(math.copysign(.22,z)))
  m.set_support('tray_stand_0.2_'+str(z),bridge)
 # The root valve island stands clear of the loader's outboard covers.
 bank=part('valve_bank_root_station');delta=np.array([0,0,-.070]);bank['pos']=(np.array(bank['pos'])+delta).tolist()
 for n,p in ports.items():
  if p['body']==bank['name']:moveport(n,tip(p)+delta)
 for q in part('silencer_root_station')['dims'][:2]:q[:]=(np.array(q)+delta).tolist()
 # Guided lift ports stay outside its outer guide sleeve.
 bank=part('valve_bank_weigh_axis_slide');delta=np.array([.015,0,0]);bank['pos']=(np.array(bank['pos'])+delta).tolist()
 for n,p in ports.items():
  if p['body']==bank['name']:moveport(n,tip(p)+delta)
 for q in part('silencer_weigh_axis_slide')['dims'][:2]:q[:]=(np.array(q)+delta).tolist()
 # External pilot is an internal manifold gallery; remove the decorative loops.
 removed={r['node'] for r in routes if r['name'].startswith('external_pilot_')};routes[:]=[r for r in routes if r['node'] not in removed];delete(removed)
 # All gripper cylinder ports point below the frame, away from its installation plate.
 grip_parents=sorted({c['parent'] for c in m.CYL if 'grip' in c['parent']})
 for parent in grip_parents:
  cs=[c for c in m.CYL if c['parent']==parent]
  for c in cs:
   for j in [0,1]:
    p=part(c['name']+'_port_'+str(j))
    for q in p['dims'][:2]:q[1]=-abs(q[1])
    p['dims'][1][1]=-.045
    ports[c['name']+'_C'+str(j)]['point']=p['dims'][1].copy()
  bd='valve_bank_'+parent;bank=part(bd);old=np.array(bank['pos'])
  if re.match(r'^grip_\d+_\d+$',parent):
   i,l=map(int,parent.split('_')[1:]);r=[.33,.47][l];at=np.array([.57-r,.21+.07*l,.16])
   bracket=m.beam('valve_bracket_'+parent,[.620,1.04+at[1],.160],[.595,1.04+at[1],.160],.025,'carrier_'+str(i),'grip_spine_'+str(i))
  else:
   prefix='loader' if parent.startswith('loader') else 'unload';axis='load_axis' if prefix=='loader' else 'unload_axis';l=int(parent.split('_')[-1]);gx=[-.39,-.25][l];lat=.60
   at=np.array([-gx+.050,.220+.070*l,.95]);y=gb[parent]['pos'][1]+at[1];vz=.95-lat
   bridge=m.beam('valve_side_reach11_'+parent,[0,.255 if prefix=='unload' else .275,.210],[0,.255 if prefix=='unload' else .275,vz],.025,axis+'_slide',prefix+'_cross');foot=m.beam('valve_mast_'+parent,[0,.255 if prefix=='unload' else .275,vz],[0,y,vz],.025,axis+'_slide',bridge)
   bracket=m.beam('valve_bracket_'+parent,[0,y,vz],[.025,y,vz],.025,axis+'_slide',foot)
  delta=at-old;bank['pos']=at.tolist();m.set_support(bd,bracket)
  for n,p in ports.items():
   if p['body']==bd:moveport(n,tip(p)+delta)
  for n in ['silencer_'+parent,'reg_015MPa_'+parent]:
   p=part(n)
   if p['kind']=='axisring':
    for q in p['dims'][:2]:q[:]=(np.array(q)+delta).tolist()
   else:p['pos']=(np.array(p['pos'])+delta).tolist()
  # P enters from the rear, clear of the fixed carrier spine.
  moveport('V_P_'+parent,at+[0,0,.035],normal=[0,0,1])
  cylinder_routes=[r for r in routes if r['name'].startswith('cylinder_') and ports[r['end']]['parent']==parent]
  cylinder_routes.sort(key=lambda r:-tip(ports[r['end']])[2])
  for lane,r in enumerate(cylinder_routes):
   A=tip(ports[r['start']]);B=tip(ports[r['end']]);x=.075+.009*lane;z=.40+.010*lane;y=A[1]+.020
   fixed(r,[[A[0],y,A[2]],[A[0],y,z],[x,y,z],[x,-.050,z],[x,-.050,B[2]],[0,-.050,B[2]]],parent,R=.015)
 # The rotating union feeds a real six-port annular distributor above the hub.
 moveport('A_ROTOR_P',[.026,1.480,0])
 distributor=m.p('rotor_air_distributor','air_distribution_ring',[.055,.085,.012],(0,1.480,0),'carousel','air',support=None)
 for i in range(3):
  a=i*math.tau/3+math.pi/6;v=np.array([math.cos(a),0,math.sin(a)]);leg=m.beam('rotor_distributor_foot_'+str(i),v*.084+[0,1.472,0],v*.103+[0,1.472,0],.010,'carousel','rotor_hub');m.contact(leg,distributor);m.set_support(distributor,leg)
 inlet=newport('ROTOR_RING_IN','carousel',[.051,1.48,0],distributor,normal=[-1,0,0]);fixed(addroute('rotor_P_to_ring','A_ROTOR_P',inlet),parent='carousel')
 # Six arm manifolds, supplied along the arm tops. Twelve valves remain independent.
 for i in range(6):
  par='carrier_'+str(i);bd=m.box('arm_air_tee_'+str(i),(.020,.030,.020),(.57,1.32,.24),par,'air',support=None)
  br=m.beam('arm_air_tee_bracket_'+str(i),[.620,1.32,.180],[.570,1.32,.257],.016,par,'grip_spine_'+str(i));m.set_support(bd,br)
  top=newport('ARM_TOP_'+str(i),par,[.57,1.345,.24],bd,ro=.004)
  down=newport('ARM_DOWN_'+str(i),par,[.57,1.295,.24],bd,normal=[0,-1,0],ro=.004)
  tap=newport('ARM_TAP_'+str(i),par,[.57,1.32,.215],bd,normal=[0,0,-1],ro=.004);tie(top,down,tap)
  feed=newport('ROTOR_ARM_OUT_'+str(i),par,[.099,1.48,0],distributor,normal=[1,0,0]);tie(inlet,feed)
  r=addroute('rotor_arm_'+str(i),feed,top,ro=.004)
  # Transform radial arm guide points into the common carousel coordinate frame.
  controls=[]
  for q in [[.150,1.48,0],[.150,1.54,0],[.570,1.54,0],[.570,1.54,.240]]:
   controls.append((np.linalg.inv(k.GM['carousel'])@k.GM[par]@np.r_[q,1])[:3])
  fixed(r,controls,'carousel',R=.020)
  for l,src in [(1,tap),(0,down)]:
   r=route(f'supply_grip_{i}_{l}');r['start']=src
   B=in_parent(ports[r['end']],par)
   fixed(r,[[.57,B[1],.24]] if l==0 else None,par,R=.018)
 # A lower distribution header feeds four separate constant-length half-ring loops.
 header=m.ring('peel_lower_air_header',[-.72,-.04,-.15],[-.24,-.04,-.15],.006,.004,'peel_head','air',support=None)
 for x in [-.72,-.24]:
  br=m.beam('peel_header_bracket_'+str(x),[x,.0395,-.22],[x,-.04,-.15],.012,'peel_head','peel_head_cross_back');m.set_support(header,br)
 ports['A_PEEL_HEAD']['body']=header;moveport('A_PEEL_HEAD',[-.220,-.04,-.15],normal=[1,0,0]);m.set_support('fit_A_PEEL_HEAD',header)
 part('fit_A_PEEL_HEAD')['dims'][3]=.00405
 # U-return service carriers: neutral length is invariant over each full stroke.
 carriers=[]
 for l,x in enumerate([-.628,-.488]):
  for s in [-1,1]:
   par='nozzle_'+str(l)+'_'+str(s);xc=x-.025;suff=f'half_{l}_{s}'
   elbow=m.p('half_feed_elbow_'+suff,'fluid_pipe',[[[xc,.020,s*.10],[xc,.020,s*.052],[x,.020,s*.052],[x,0,s*.052]],.006,.004],parent=par,mat='air',support=f'peel_manifold_{l}_{s}',join='welded')
   endbody=m.p('half_feed_anchor_'+suff,'bored_z',[.020,.020,.020,.0061,0],(xc,.020,s*.10),par,'air',elbow)
   fixedbody=m.p('half_fixed_anchor_'+suff,'bored_z',[.020,.020,.020,.0061,0],(xc,-.04,s*.24),'peel_head','air',support=None)
   br=m.beam('half_anchor_stand_'+suff,[xc+.020,.0395,s*.22],[xc+.020,-.04,s*.24],.012,'peel_head','peel_head_cross' if s>0 else 'peel_head_cross_back')
   m.beam('half_anchor_shoe_'+suff,[xc+.020,-.04,s*.24],[xc+.010,-.04,s*.24],.012,'peel_head',br);m.set_support(fixedbody,'half_anchor_shoe_'+suff)
   src=newport('HALF_HEADER_'+suff,'peel_head',[xc,-.04,-.15+s*.020],header,normal=[0,0,s]);tie('A_PEEL_HEAD',src)
   inp=newport('HALF_A_IN_'+suff,'peel_head',[xc,-.04,s*.22],fixedbody,normal=[0,0,-s]);a=newport('HALF_A_'+suff,'peel_head',[xc,-.04,s*.26],fixedbody,normal=[0,0,s]);tie(inp,a)
   b=newport('HALF_B_'+suff,par,[xc,.020,s*.12],endbody,normal=[0,0,s]);tie(b,f'PEEL_{l}_{s}')
   fixed(addroute('half_fixed_feed_'+suff,src,inp),parent='peel_head')
   r=route(f'peel_half_{l}_{s}');R=.030;L=.14+math.pi*R+.060;r.update(start=a,end=b,basis='peel_head',length_m=L,guided=dict(radius=R,steps=32,u_axis=[0,0,s],v_axis=[0,1,0]),route_class='carrier')
   W=k.GM['peel_head'];ps=u_points(world(ports[a]),world(ports[b]),W[:3,:3]@[0,0,s],W[:3,1],L,R,32);local=(np.c_[ps,np.ones(len(ps))]@np.linalg.inv(W).T)[:,:3]
   mid=local[1]+np.array([0,R,s*R]);segs=[['L',local[0].tolist(),local[1].tolist()],['A',local[1].tolist(),mid.tolist(),local[-2].tolist()],['L',local[-2].tolist(),local[-1].tolist()]]
   part(r['node']).update(parent='peel_head',pos=[0,0,0],dims=[local.tolist(),.004,.0028,segs],support=fixedbody)
   carriers.append(dict(route=r['name'],axis=f'nozzle_{l}_{s}',minimum_radius_mm=30,OD_mm=8))
   # The custom elbow replaces the old unconnected external feed fitting.
   delete(['fit_'+f'PEEL_{l}_{s}'])
 def link(r,axis,z=.44):
  oldstart,oldend=r['start'],r['end'];a=next(a for a in m.AXES if a['name']==axis);S=a['stroke'];bx=.10 if axis=='peel_scan' else .15;Ax=.12+bx+S/2-(.050 if r['outer_radius']<.005 else 0);R=.060;L=S/2+math.pi*R+.100;flat=axis=='trim_axis';ya=.12 if flat else .10;yb=.12 if flat else .22;zb=z+.12 if flat else z
  medium=r['medium'];ro=r['outer_radius'];suff=r['name'];par=axis;slide=a['slide']
  af=m.plate('carrier_fixed_'+suff,(.080,.012,.050),(Ax,ya-.025,z),par,support=None)
  h=m.beam('carrier_fixed_foot_'+suff,[Ax,-.009,math.copysign(.125,z)],[Ax,-.009,z],.018,par,axis+'_base')
  st=m.beam('carrier_fixed_stand_'+suff,[Ax,-.009,z],[Ax,ya-.025,z],.018,par,h);m.set_support(af,st)
  bf=m.plate('carrier_moving_'+suff,(.080,.012,.050),(bx,yb-.025,zb),slide,support=None)
  st=m.beam('carrier_moving_stand_'+suff,[.08,.078,math.copysign(.100,z)],[bx,yb-.025,zb],.018,slide,axis+'_carriage');m.set_support(bf,st)
  pa=newport('CHAIN_A_'+suff,par,[Ax,ya,z],af,medium,ro=ro)
  pb=newport('CHAIN_B_'+suff,slide,[bx,yb,zb],bf,medium,ro=ro)
  vv=[0,0,1] if flat else [0,1,0]
  r.update(start=pa,end=pb,basis=par,length_m=L,guided=dict(radius=R,steps=32,u_axis=[1,0,0],v_axis=vv),route_class='carrier')
  A=world(ports[pa]);B=world(ports[pb]);W=k.GM[par];ps=u_points(A,B,W[:3,0],W[:3,:3]@vv,L,R,32);local=(np.c_[ps,np.ones(len(ps))]@np.linalg.inv(W).T)[:,:3]
  # Exact home sweep uses two tangent lines and a semicircular arc.
  mid=local[1]+np.array([R,0,0])+np.array(vv)*R;segs=[['L',local[0].tolist(),local[1].tolist()],['A',local[1].tolist(),mid.tolist(),local[-2].tolist()],['L',local[-2].tolist(),local[-1].tolist()]]
  p=part(r['node']);p.update(parent=par,pos=[0,0,0],dims=[local.tolist(),ro,ro*.70,segs],support=af)
  before=addroute('lead_fixed_'+suff,oldstart,pa,medium,ro);after=addroute('lead_moving_'+suff,pb,oldend,medium,ro)
  # Fixed feed is taken outside the frame perimeter; moving lead follows its mast.
  A0=in_parent(ports[oldstart],par);B0=tip(ports[pa]);far=a['L']+.25
  side=z+math.copysign(.100,z);inner=-.10-gb[par]['pos'][2]
  controls=[[A0[0],A0[1],inner],[far,A0[1],inner],[far,A0[1],side],[far,ya,side],[Ax,ya,side]]
  if axis=='peel_scan':controls=[[A0[0],A0[1],side],[far,A0[1],side],[far,ya,side],[Ax,ya,side]]
  fixed(before,controls,par,R=.030)
  E=in_parent(ports[oldend],slide);D=tip(ports[pb]);y=max(.32,E[1]+.060)
  if flat:fixed(after,[[D[0],.180,D[2]],[D[0],.180,.08],[.09,.180,.08],[.09,E[1],.08],[.09,E[1],0]],slide,R=.015)
  else:fixed(after,None if np.linalg.norm(E[[0,2]]-D[[0,2]])<1e-7 else [[D[0],y,z],[E[0],y,z],[E[0],y,E[2]+.050],[E[0],E[1],E[2]+.050]],slide,R=.020)
  carriers.append(dict(route=r['name'],axis=axis,minimum_radius_mm=60,OD_mm=ro*2000,side_z_m=z))
  return pb
 # Loader and unloader share one P trunk, then branch at the moving manifold.
 for prefix,axis in [('loader','load_axis'),('unload','unload_axis')]:
  r0=route('supply_'+prefix+'_grip_0');r1=route('supply_'+prefix+'_grip_1')
  # The primary flexible trunk terminates at one moving tee; two fixed-on-carriage branches follow.
  slide=axis+'_slide';z=.44 if prefix=='loader' else .85
  bd=m.box(prefix+'_air_splitter',(.060,.030,.040),(0,.30,z),slide,'air',support='carrier_moving_supply_'+prefix+'_grip_0')
  inp=newport(prefix+'_SPLIT_IN',slide,[0,.275,z],bd,normal=[0,-1,0]);o0=newport(prefix+'_SPLIT_0',slide,[-.020,.325,z],bd);o1=newport(prefix+'_SPLIT_1',slide,[.020,.325,z],bd);tie(inp,o0,o1)
  end0=r0['end'];r0['end']=inp;link(r0,axis,z)
  # Physical short vertical standoff joins the existing moving anchor to splitter.
  support=m.beam(prefix+'_splitter_stand',[.15,.201,z+.025],[0,.285,z+.025],.016,slide,'carrier_moving_supply_'+prefix+'_grip_0');m.set_support(bd,support)
  r=addroute('branch_'+prefix+'_grip_0',o0,end0);r1['start']=o1
  for rr in [r,r1]:
   E=in_parent(ports[rr['end']],slide);A=in_parent(ports[rr['start']],slide);y=.56
   fixed(rr,[[A[0],y,z],[E[0],y,z],[E[0],y,E[2]+.05],[E[0],E[1],E[2]+.05]],slide,R=.020)
 for n,ax,z in [('supply_trim_axis_slide','trim_axis',-.50),('supply_weigh_axis_slide','weigh_axis',-.40)]:link(route(n),ax,z)
 # Peeling has two successive carriers; no diagonal free hose stretches over both axes.
 for name,ro,z in [('supply_peel_head',.004,-.60),('peel_two_axis_loop',.006,-.625)]:
  r=route(name);end=r['end'];bd=m.box('peel_radial_split_'+name,(.035,.035,.035),(.30,.32,z),'peel_radial_slide','air',support='peel_carriage_extension')
  reach=m.beam('peel_split_reach_'+name,[.215,.290,-.13],[.30,.290,z],.020,'peel_radial_slide','peel_tower_-0.13')
  stay=m.beam('peel_split_stay_'+name,[.30,.290,z],[.30,.3025,z],.020,'peel_radial_slide',reach);m.set_support(bd,stay)
  mid=newport('PEEL_STAGE_'+name,'peel_radial_slide',[.30,.345,z],bd,ro=ro);r['end']=mid;link(r,'peel_radial',z)
  rr=addroute('vertical_'+name,mid,end,ro=ro);link(rr,'peel_scan',.32 if ro==.004 else .345)
 for name,z in [('airknife_moving_loop',.60),('water_moving_loop',.63)]:link(route(name),'wash_axis',z)
 # Cylinder A/B plumbing follows the free side of each installation frame.
 for r in routes:
  if not r['name'].startswith('cylinder_'):continue
  parent=ports[r['end']]['parent']
  if 'grip' in parent:continue
  A=tip(ports[r['start']]);B=tip(ports[r['end']])
  if parent=='root_station':
   rank=0 if B[2]>-.45 else 1;y=.635+.022*rank
   fixed(r,[[A[0],y,A[2]],[B[0],y,A[2]],[B[0],y,B[2]]],parent,R=.015)
  elif parent=='trim_axis_slide':
   rank=0 if B[2]>-.35 else 1;yy=-.242+.022*rank;zz=-.18-.020*rank
   fixed(r,[[A[0],.180,A[2]],[A[0],.180,zz],[A[0],yy,zz],[B[0],yy,zz],[B[0],yy,B[2]]],parent,R=.015)
  elif parent=='weigh_axis_slide':
   rank=0 if B[1]>.15 else 1;xx=.12+.012*rank
   fixed(r,[[A[0],.24+.012*rank,A[2]],[xx,.24+.012*rank,A[2]],[xx,.24+.012*rank,-.08],[xx,B[1],-.08],[B[0],B[1],-.08]],parent,R=.015)
  elif parent=='peel_head':
   cpart=part(ports[r['end']]['body'])
   for q in cpart['dims'][:2]:q[1]=.028-abs(q[1]-.028)
   ports[r['end']]['point']=cpart['dims'][1].copy();B=tip(ports[r['end']])
   peers=sorted([rr for rr in routes if rr['name'].startswith('cylinder_') and ports[rr['end']]['parent']==parent],key=lambda rr:rr['name']);lane=peers.index(r);bottom=-.120-.009*lane;zz=.34+.012*lane;y=.140+.012*lane
   fixed(r,[[A[0],y,A[2]],[A[0],y,zz],[-.18-.009*lane,y,zz],[-.18-.009*lane,bottom,zz],[B[0],bottom,zz],[B[0],bottom,B[2]]],parent,R=.015)
 # Fixed utility runs have a restrained route instead of oversized slack bubbles.
 fixed(route('dump_to_filter'),[[.44,1.085,-.12],[.44,1.20,-.12],[.25,1.20,-.12],[.25,1.05,-.105]],'utilities',R=.020)
 fixed(route('filter_to_control_ring'),[[1.25,1.05,.105],[1.25,1.13,.105],[1.40,1.13,.105],[1.40,.21,.105],[1.40,.21,-.20]],'station6',R=.030)
 r=route('ring_to_overhead');r['start']='A_RING_3'
 fixed(r,[[.80,.21,-.20],[.80,.21,.35],[.80,1.75,.35],[.70,1.75,.35]],'fixed',R=.035)
 fixed(route('union_flexible_inlet'),[[.70,1.76,.35],[.15,1.76,.10],[.15,1.53,.10],[.15,1.53,0]],'fixed',R=.035)
 fixed(route('filtered_process_to_underframe'),[[1.24,.79,.14],[1.24,.79,-.32],[1.24,.32,-.32],[.78,.32,-.32]],'station6',R=.030)
 fixed(route('clean_water_to_underframe'),[[1.35,.78,.40],[1.35,.78,.28],[1.35,.25,.28],[.78,.25,.28]],'station6',R=.035)
 fixed(route('supply_root_station'),[[1.30,.21,-.65],[1.30,.626,-.65],[1.269,.626,-.65],[1.269,.626,-.32]],'station1',R=.025)
 for x in [-.51,-.37]:
  p=part('wash_pipe_cross_'+str(x))
  for q in p['dims'][:2]:q[0]+=.030
 for x in [-.51,-.37]:
  for prefix,zvals,ro in [('air_knife_inlet_',[-.04,.04],.006),('wash_manifold_',[-.065,.065],.009)]:
   for z in zvals:
    name=prefix+str(x)+'_'+str(z);yy=.515 if ro==.006 else .490
    clamp=m.ring('wash_pipe_clamp_'+name,[x,yy-.010,z],[x,yy+.010,z],ro+.004,ro+.0001,'wash_axis_slide','steel',support=None)
    stem=m.beam('wash_pipe_bracket_'+name,[x+.030,.522,z],[x+.030,yy,z],.010,'wash_axis_slide','wash_pipe_cross_'+str(x)) if yy!=.522 else 'wash_pipe_cross_'+str(x)
    foot=m.beam('wash_pipe_shoe_'+name,[x+.030,yy,z],[x+ro+.004,yy,z],.010,'wash_axis_slide',stem);m.set_support(clamp,foot);m.set_support(name,clamp)
 for r in routes:
  if r['name'].startswith(('water_header_','airknife_-')):
   A=in_parent(ports[r['start']],'wash_axis_slide');B=in_parent(ports[r['end']],'wash_axis_slide')
   fixed(r,[[A[0],.560,A[2]],[B[0],.560,B[2]]],'wash_axis_slide',R=.015)
 fixed(route('tank_suction'),[[.07,.145,.36],[.07,.18,.36],[.12,.18,.36]],'utilities',R=.020)
 fixed(route('strainer_to_pump'),[[.08,.18,.29],[.08,.24,.29],[.19,.24,.29],[.19,.17,.29]],'utilities',R=.020)
 fixed(route('clean_min_flow_bypass'),[[.19,.30,.42],[.19,.60,.68],[.04,.60,.68],[.04,.35,.68]],'utilities',R=.025)
 fixed(route('potable_water_fill'),[[-.38,.76,.52],[-.14,.76,.52]],'utilities',R=.030)
 fixed(route('peel_fixed_riser'),[[.82,.32,-.40],[1.80,.32,-.40],[1.80,.80,.50],[1.20,.80,.50]],'station2',R=.030)
 fixed(route('airknife_fixed_riser'),[[.82,.32,-.40],[1.90,.32,-.40],[1.90,.82,-.40],[1.65,.82,-.40]],'station3',R=.030)
 fixed(route('wash_fixed_water_riser'),[[.82,.25,.40],[1.90,.25,.40],[1.90,.84,.40],[1.65,.84,.40]],'station3',R=.035)
 for y in [.60,1.10,1.55]:m.beam('union_air_riser_clip_'+str(y),[.715,y,.35],[.794,y,.35],.012,'fixed','union_overhead_mast')
 joints={j['child'] for j in m.JOINTS}
 def sig(parent):
  out=[]
  while parent:
   if parent in joints:out.append(parent)
   parent=gb[parent]['parent']
  return tuple(out)
 for r in routes:
  if 'path' in r or 'guided' in r:continue
  # Cylinder plumbing outside the grippers and the half-ring loops still use the
  # original fixed-length law; those genuinely changing endpoints remain flexible.
  A=ports[r['start']];B=ports[r['end']]
  if sig(A['parent'])==sig(B['parent']):
   fixed(r,R=.020)
  else:
   # Refresh home BREP after moving its ports, including genuinely flexing half rings.
   W=k.GM[r['basis']];ps=route_points(r,ports,k.GM);par=common(r['start'],r['end']);local=(np.c_[ps,np.ones(len(ps))]@np.linalg.inv(k.GM[par]).T)[:,:3]
   p=part(r['node']);p.update(parent=par,pos=[0,0,0],dims=[local.tolist(),r['outer_radius'],r['inner_radius']],support=A['body'])
 svc['carriers']=carriers
 svc['design']['routing_revision']='07: six arm P trunks; internal pilot galleries; eight-axis media carriers including the two peeling stages. Local A/B lines remain distinct because the cylinders are double acting.'
 svc['design']['limits']='名义布置与几何检查；轴用定长U形段R60mm，半环R30mm。载体附件为自制导向与端部支承；最终采购拖链、管材疲劳、流量/压损与整机连续碰撞未认证。'
 m.apply_home()
 return svc
