from pathlib import Path
import zipfile,json
R=Path(__file__).resolve().parents[1];O=R/'dist/downloads';dst=O/'Scallion_Review12_Complete.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in sorted(R.rglob('*')):
  rel=f.relative_to(R)
  if not f.is_file() or f.is_symlink():continue
  if any(p in {'.git','.openai','node_modules','__pycache__','.mesh_cache','.cad_cache','sw_exchange_12'} for p in rel.parts):continue
  if f==dst or f.suffix in {'.log','.step','.glb'}:continue
  z.write(f,'Scallion_Review12/'+str(rel))
with zipfile.ZipFile(dst) as z:
 assert z.testzip() is None
 assert 'Scallion_Review12/dist/index.html' in z.namelist()
 assert 'Scallion_Review12/dist/cell.glb.gz' in z.namelist()
 assert 'Scallion_Review12/dist/downloads/Scallion_SW_Assembly_12.zip' in z.namelist()
print('Complete ZIP',dst.stat().st_size)
