from pathlib import Path
import json,subprocess,hashlib,html,shutil,gzip
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads';e=html.escape
base=json.loads(subprocess.check_output(['git','show','03b46ff65575a9678d7f286f201986943aeacf17:engineering/review-cases.json'],cwd=R))
old=json.loads((R/'engineering/published08_full_cycle_screen.json').read_text())
pose_bytes=gzip.decompress((R/'engineering/evidence10/poses-release.json.gz').read_bytes());raw=json.loads(pose_bytes);screen=json.loads((R/'engineering/evidence10/screen-release.json').read_text());dense=json.loads((O/'exchange_clearance_checks_10.json').read_text())
assert not dense['candidates'] and dense['poses']==2051 and not screen['rigid_candidates']
resolved={'C01','C02','C03','C04','C06','C08','C10'}
actions={
'C01':'停车行程从650 mm增加至1600 mm，龙门架补齐相应支承。停车位在原料外；工作进给的残余问题另列C11。',
'C02':'取料与卸料夹改为两侧安装板、后部开口叉架和两侧短导向；加宽导向夹爪并给安装块留出开夹空间。',
'C03':'移除横穿入口的前侧横梁，保留连接后部支承的叉架。',
'C04':'供水横管下移到切口以下，增加侧面连接支承，并补长8根喷淋/风刀支架接到下移后的横管。',
'C06':'杯托立杆移至通道侧面，补齐到升降板和传感器的连接。承接座已进入CAD。',
'C08':'主夹改为贯通的开口框架；主夹、卸料夹按原有错层高度交接。',
'C10':'横贯导杆分成两侧短导向，中央保留114 mm名义导向间开口；夹爪仍有导向孔和缸杆连接。'}
for c in base['cases']:
 c['resolved']=c['id'] in resolved
 c.pop('overlap_mm3',None)
 # Match the original actuator state after the cut-before-transfer sequence changed.
 if c['id']=='C01':pose=raw['poses'][0]
 else:
  h=next((x for x in old['extra_candidates'] if x['extra']==c['parts'][0]['name'] and x['solid']==c['parts'][1]['name']),None)
  phase=c['phase'];candidates=[p for p in raw['poses'] if p['phase'] in (['root','load'] if c['id'] in ['C02','C10'] else [phase])]
  keys=['main_index','load_axis','unload_axis','peel_radial','peel_scan','wash_axis','weigh_axis','weigh_lift']
  pose=min(candidates,key=lambda p:sum(abs(p['q'].get(k,0)-h['q'].get(k,0)) for k in keys)) if h else candidates[0]
 c['t']=pose['t'];c['phase']=pose['phase']
 for ref in c['parts']:
  if 'trace' in ref:
   ex=next((x for x in pose['extras'] if x.get('trace')==ref['trace']),None)
   if ex:ref['path']=ex['path'];ref['trace']=ex['trace']
 if c['id']=='C03':c['parts'][1]['name']='peel_head_cross_back'
 if c['resolved']:
  c['problem']='原问题：'+c['problem'];c['action']=actions[c['id']];c['status']='已调整；密集离散样本未检出原阻挡';c['evidence']=f"0.1 s密集回归 · {dense['case_pose_counts'][c['id']]}个姿态"
 else:c['status']='未解决';c['evidence']='本轮联合筛查仍检出；需重构'
h=next(x for x in screen['extra_candidates'] if x['product'] and x['solid'].startswith('trim_counter_shoe_'))
p=next(p for p in raw['poses'] if abs(p['t']-h['t'])<1e-7);ex=next(x for x in p['extras'] if x['name']==h['extra'] and x['path']==h['extra_path'])
base['cases'].append(dict(id='C11',title='剪叶进给仍有叶片与反刃支承接触',t=h['t'],phase=h['phase'],parts=[dict(name=h['extra'],path=ex['path'],trace=ex['trace']),dict(name=h['solid'])],resolved=False,evidence='本轮带料网格相交候选',status='未解决',problem='剪叶架进入时，反刃下方支承仍会扫过未剪叶片。外移停车位没有解决工作进给通道。',action='需要重排剪叶刀、反刃和反力支承的进给方式，并与回转臂、阀岛一起校核；不能将这一接触按已完成切割处理。'))
base.update(revision='MECHANICAL10 / PROCESS10',status='7项原阻挡已调整并通过限定范围回归；4项仍未关闭',model_sha256=hashlib.sha256((D/'cell.glb').read_bytes() if (D/'cell.glb').exists() else gzip.decompress((D/'cell.glb.gz').read_bytes())).hexdigest(),poses=screen['poses'],source_pose_count=len(raw['poses']),mesh_pair_groups=len(screen['extra_candidates']),dense_poses=dense['poses'],resolved_ids=sorted(resolved),unresolved_ids=['C05','C07','C09','C11'],production_release=False,scope='七项原阻挡的密集离散回归 + 完整作业联合抽样；不是整机连续无干涉验收。')
base['cautions']=['C01只复核停车位，剪叶工作进给仍作为C11未关闭。','根切、剪叶刀具接触和软垫夹持接触单列；柔性物料形变与夹持力没有实料验收。','刚体筛查排除同刚体和声明配合，不能证明这些连接内部无干涉。','管路连通与长度已复核，但全程柔性管避碰、管夹和弯曲半径选型仍未完成。','包装、封口仍为未通过的网页示意机构；新版STEP包含夹具、支承和承接座，未包含完整包装机械。','未在SolidWorks中完成原生配合和运动验收，也未做真实浏览器GPU检查。']
for f in [R/'engineering/review-cases.json',O/'assembly_review_10.json']:f.write_text(json.dumps(base,ensure_ascii=False,indent=2))
screen['model_sha256']=base['model_sha256'];screen['pose_input_sha256']=hashlib.sha256(pose_bytes).hexdigest()
(O/'full_workflow_clearance_screen_10.json').write_text(json.dumps(screen,ensure_ascii=False,indent=2))
dense['model_sha256']=base['model_sha256'];(O/'exchange_clearance_checks_10.json').write_text(json.dumps(dense,ensure_ascii=False,indent=2))
rows=''.join(f'<tr><td>{e(c["id"])}<br>{c["t"]:.2f}s</td><td><b>{e(c["title"])}</b><p>{e(c["action"])}</p></td><td class="{"pass" if c["resolved"] else "open"}">{e(c["status"])}<small>{e(c["evidence"])}</small></td></tr>' for c in base['cases'])
notes=''.join('<li>'+e(x)+'</li>' for x in base['cautions'])
body=f'''<main><a href="index.html">← 返回完整作业与修复定位</a><div class="eyebrow">MECHANICAL REVISION 10</div><h1>交接通道与支承已实改。</h1><p class="lead">本轮把开口夹具、两侧短导向、清洗横管、称重立杆和承接座落实到共享CAD几何；取料夹先夹稳，再切根，消除切根后到夹取前的承接空档。</p><p class="status">7项原阻挡在限定范围回归中未检出；包装、封口与剪叶进给共4项仍未关闭。未达到整机工业级验收。</p><h2>检查证据</h2><p>七项阻挡组按最大0.1秒间隔，共2051个姿态做物料 / CAD回归，未检出这些组的原阻挡。整套作业另外抽查110个姿态，未检出额外的移动刚体候选；网页包装支架和剪叶进给的相交仍明确保留。两者都不是连续碰撞认证。</p><h2>逐项状态</h2><div class="scroll"><table><thead><tr><th>编号 / 时刻</th><th>结构调整或待办</th><th>结果</th></tr></thead><tbody>{rows}</tbody></table></div><h2>网页和SW对应同一修订</h2><p>承接座已纳入称重杯与全部成品杯的实体装配，夹具框架、夹爪、短导向和后部支承也进入STEP10。展示GLB与STEP均由同一套参数生成；STEP为毫米制装配交换文件，原生SW配合和运动需要在SolidWorks中继续建立。</p><p><a href="downloads/Scallion_SW_Assembly_10.zip">下载SW装配交换包10</a> · <a href="downloads/Scallion_GLB_10.zip">下载GLB模型10</a></p><h2>剩余重构</h2><p>包装与封口需要重新分配干区空间、真实动力、导向和进退路径；剪叶反力支承必须避开叶片，并与回转臂和阀岛联合布置。上述机构仍保留为未解决问题，不因动画完整而标为机械可行。</p><h2>验证范围</h2><ul>{notes}</ul><p><a href="downloads/assembly_review_10.json">本轮问题与状态</a> · <a href="downloads/exchange_clearance_checks_10.json">密集回归记录</a> · <a href="downloads/full_workflow_clearance_screen_10.json">完整作业筛查</a> · <a href="assembly-review-09.html">历史审查09</a></p><small>GLB SHA256：{base['model_sha256']}</small></main>'''
css='''*{box-sizing:border-box}body{margin:0;background:#10202c;color:#cbdce4;font:15px/1.85 system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:40px 24px 75px}a{color:#9edcbd}h1{font-size:clamp(28px,5vw,42px);color:#eef4f6;line-height:1.3}h2{font-size:22px;color:#dbece5;margin-top:34px}.eyebrow{font-size:11px;letter-spacing:2px;color:#86a8bb;margin-top:30px}.lead{font-size:18px}.status{border-left:3px solid #daa06f;background:#3c3028;padding:15px 20px;color:#ffe1bd}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;vertical-align:top;padding:14px;border-bottom:1px solid #35505f}th{background:#193240;color:#a4cfba}td:first-child{min-width:85px}td:nth-child(2){min-width:300px}td:nth-child(3){min-width:220px}td p{margin:8px 0;color:#b3c9d4}.pass{color:#89d5ad}.open{color:#f1b77f}small{display:block;font-size:11px;color:#8ea9b6;overflow-wrap:anywhere;margin-top:8px}li{margin:9px 0}'''
(D/'assembly-review-10.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>青葱工坊 · 结构修订10</title><style>'+css+'</style>'+body+'</html>')
d=json.loads((D/'mechanics.json').read_text());d['verification']=dict(status_zh=base['status']+'；整机连续避碰与SW实机未验收。',production_release=False,assembly_review='downloads/assembly_review_10.json');(D/'mechanics.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
print(base['status'])
