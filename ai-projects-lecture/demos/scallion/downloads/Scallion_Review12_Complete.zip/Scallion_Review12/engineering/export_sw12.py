"""Verify a round-tripped STEP product tree, then package the SW assembly exchange."""
from pathlib import Path
import json,csv,zipfile,hashlib,shutil
import numpy as np
import cadquery as cq
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence,TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.IFSelect import IFSelect_RetDone
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads'
step=O/'SCALLION_CELL_concept_mm.step'
doc=TDocStd_Document(TCollection_ExtendedString('SW_STEP_CHECK'))
reader=STEPCAFControl_Reader();reader.SetNameMode(True);reader.SetColorMode(True)
assert reader.ReadFile(str(step))==IFSelect_RetDone
assert reader.Transfer(doc)
tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());roots=TDF_LabelSequence();tool.GetFreeShapes(roots)
def name(label):
 attr=TDataStd_Name()
 return attr.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(),attr) else ''
nodes=[];leaves=[]
def walk(label,path=(),depth=0):
 ref=TDF_Label();target=label
 if tool.IsReference_s(label):tool.GetReferredShape_s(label,ref);target=ref
 n=(name(target) if tool.IsAssembly_s(target) else name(label)) or name(target);path=path+(n,)
 if tool.IsAssembly_s(target):
  comps=TDF_LabelSequence();tool.GetComponents_s(target,comps,False)
  nodes.append(dict(name=n,depth=depth,children=comps.Length(),path='/'.join(path)))
  for i in range(1,comps.Length()+1):walk(comps.Value(i),path,depth+1)
 else:
  s=cq.Shape.cast(tool.GetShape_s(target));leaves.append(dict(name=n,depth=depth,solids=len(s.Solids()),path='/'.join(path)))
for i in range(1,roots.Length()+1):walk(roots.Value(i))
manifest=json.loads((R/'engineering/scene_manifest.json').read_text());cad=[p for p in manifest['parts'] if p['cad']]
expected={p['name'].replace('.','p').replace('-','m') for p in cad}
assert len(leaves)==len(cad),(len(leaves),len(cad))
actual={p['name'] for p in leaves};assert expected==actual,(list(expected-actual)[:5],list(actual-expected)[:5])
assert max(x['depth'] for x in leaves)>=6
assert {'station1','station2','station3','station4','station5','station6','carousel','load_axis','peel_scan'}.issubset({n['name'] for n in nodes})
assert 'AUTOMOTIVE_DESIGN' in step.read_text()[:1000]
check=dict(step_schema='AP214 AUTOMOTIVE_DESIGN',unit='mm',root_products=roots.Length(),assembly_nodes=len(nodes),leaf_component_occurrences=len(leaves),solid_occurrences=sum(l['solids'] for l in leaves),max_product_depth=max(l['depth'] for l in leaves),all_component_names_preserved=True,sha256=hashlib.sha256(step.read_bytes()).hexdigest(),solidworks_runtime_tested=False,scope='STEPCAF product-tree reimport. Native SOLIDWORKS features/mates are not represented or tested.',assembly_tree=nodes)
(O/'sw_assembly_checks.json').write_text(json.dumps(check,ensure_ascii=False,indent=2))
S=R/'sw_exchange_12';S.mkdir(exist_ok=True)
shutil.copy2(step,S/'SCALLION_ASSEMBLY_12_AP214_MM.step')
with (S/'COMPONENT_TREE.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['name','depth','solids','path']);w.writeheader();w.writerows(leaves)
data=json.loads((D/'mechanics.json').read_text())
with (S/'SW_MATE_PLAN.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['joint','type','parent','moving_subassembly','axis_in_parent','minimum_mm_or_rad','maximum_mm_or_rad','home_mm_or_rad','screw_lead_mm','drive_relation','note'])
 for j in data['joints']:
  scale=1000 if j['type']=='prismatic' else 1
  w.writerow([j['name'],j['type'],j['parent'],j['child'],json.dumps(j['axis']),j['limits'][0]*scale,j['limits'][1]*scale,j.get('home',0)*scale,5 if j['name'] in {a['name'] for a in data['linear_axes']} else 3 if (j['name']=='trim_counter_shift' or '_jaw11_' in j['name']) else '',j.get('relation',''), '导入位置固定；在SW中建立导向/限位/丝杠关系。轴向在父组件局部坐标中。'])
with (S/'MEDIA_PORTS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['port','medium','parent_component','local_x_mm','local_y_mm','local_z_mm','connected_body_STEP'])
 for n,p in data['services']['ports'].items():w.writerow([n,p['medium'],p['parent'],*[v*1000 for v in p['point']],p['body'].replace('.','p').replace('-','m')])
with (S/'HOSE_CUT_LENGTHS_NOMINAL.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['hose','medium','from_port','to_port','neutral_length_mm','OD_mm','ID_mm','note'])
 for p in data['services']['routes']:w.writerow([p['name'],p['medium'],p['start'],p['end'],round(p['length_m']*1000,2),p['outer_radius']*2000,p['inner_radius']*2000,'中性线名义长度；未含接头插入/切管余量，不可直接作为下料指令'])
guide='''# 青葱工坊 11 · SolidWorks 装配导入包

## 交付是什么

`SCALLION_ASSEMBLY_12_AP214_MM.step` 是毫米制 BREP 实体装配，保留机架、工位、移动组件和命名零件的产品层级与颜色。零件外形为本轮名义机械设计及简化采购件。

STEP 已经通过独立 STEPCAF 重新读取，核对组件名称、叶组件数量、实体数量与产品树深度；结果见 `sw_assembly_checks.json`。本环境没有 SolidWorks，未声称生成或验收原生 SLDASM/SLDPRT。

## 在 SolidWorks 中打开

1. 将整个文件夹解压到一个新目录。打开 STEP 前关闭同名旧文档，避免意外引用旧部件。
2. 文件 → 打开，类型选择 STEP AP203/214/242；选中本包的 STEP 后进入“选项”。
3. **Assembly Structure Mapping → Default (As per the file)**，单位选 **File specified unit**。不要选择 Import assembly as multiple body part，否则子装配会被合成多实体零件。
4. 导入后检查树中 `fixed / station1…station6 / carousel / …`，展开 `load_axis` 或 `peel_scan` 查看其安装件、移动组件与零件。确认尺寸单位为 mm，整机包络与地面坐标见 geometry_verification.json。外围护架直径约7.34m，本版没有保持原始紧凑外形。
5. 采用带 3D Interconnect 链接的导入方式时，在常规导入选项中将手动断链输出设为 **Create external files**；对导入节点执行 **Break Link**（中性格式在部分版本显示 **Dissolve Feature**）。若出现“对所有组件执行”，按整机范围处理。断链会失去对源 STEP 的更新关联。
6. 保存顶层装配为 `.SLDASM`，连同引用的零件/子装配一起保存。仅另存顶层不能证明所有引用部件都已外部化。若仍有方括号虚拟子装配，右键 **Save Assembly (in External File)**，选择 **Save the subassembly and any virtual child components to an external file**。

不同版本菜单翻译有差别。2023 SP2起导入选项调整；2024 SP2起清除 Enable 3D Interconnect 仍使用最新转换技术，因此不要将“关闭它”理解为回退旧转换器。

## 在 SW 中继续做运动

导入位置是静态归位装配。STEP不携带 SolidWorks 原生配合、丝杠配合、伺服驱动或原始参数化历史。

`SW_MATE_PLAN.csv` 记录本版运动副的父/子组件、局部轴向、行程、归位值。单位列：直线mm，旋转rad。先固定机架，再对相应移动子装配建立导向、同轴、限位等配合；九条径向/扫描丝杠轴的导程为5mm/rev。成袋/横封的左右旋丝杠和反刃退让丝杠名义导程为3mm/rev，旋转从动关系见CSV。不要同时固定移动件又要求其运动。子装配需要独立求解时应在SW中设置相应柔性/配合行为。

`MEDIA_PORTS.csv` 给出气/水/排水端口与所连刚体；`HOSE_CUT_LENGTHS_NOMINAL.csv` 给出名义中性线长度。软管在STEP中为归位形状，SW中如需随动，应依端口重新建立柔性Routing；CSV长度不是生产下料指令。

## 本版布局变化

主夹半径由330/470mm增至830/970mm；成袋、称重、横封各占一站。外围护架直径约7.34m，须按场地重新确认占地。水箱、泵、阀移至清洗站外侧，清水直接进入本工位，取消原先绕行其他三站的清水主管。原始3.24装配不是本版参数化重建设计的同一份CAD。

## 气与水

- 气：可锁隔离排气→过滤调压→0.5MPa控制母路。中心旋转接头C1供旋转夹具，C2封堵备用；夹具0.15MPa主气为候选设定，阀采用0.5MPa外先导，本地消声排气。固定剥皮/风刀走无润滑独立工艺气支路。阀体和气源处理均为名义布置，最终型号、空气品质和残压释放需落实。
- 水：空气间隙补水→约50L清水箱→入口隔离/过滤→泵→清洁侧旁路分叉→止回→压力/喷头支路流量→常闭水阀→活动喷头。低液位停泵；清洁旁路回清水箱。
- 污水：带坡度接水盘→可拆截渣片→DN32名义下排→现场污水口。污水不回清水箱。泵、流量、压损、阀流通能力、旁路最小连续流量、卫生与试料性能未定型。

## 官方导入依据

- STEP层级映射：https://help.solidworks.com/2025/english/SolidWorks/sldworks/t_reading_step_iges_acis_sw.htm?id=18.17.8
- 外部文件与断链选项：https://help.solidworks.com/2026/english/SolidWorks/sldworks/hidd_options_import_general.htm?id=18.1
- 2023导入改进：https://files.solidworks.com/Supportfiles/Whats_new/2023/English/whatsnew.pdf
- 虚拟子装配外部化：https://help.solidworks.com/2025/english/SolidWorks/sldworks/HIDD_SAVE_AS_VIRTUAL_COMP.htm?id=7.5.4.5
- 2024 SP2转换器变化：https://help.solidworks.com/2024/Chinese-Simplified/WhatsNew/c_opening_third_party_cad_files.htm

本轮新增反刃250mm侧向退让、成袋与横封机构。二者采用自制左右旋TR12×3丝杠、双导杆、双端支承与伺服驱动；包装/称重/横封各占一站。膜材为展示几何，张力、温压和真实加工能力尚未确认。检查结果见 assembly_review_11.json。\n\n未完成项：原生SW运动验收；管间/与机械件的连续碰撞、弯曲半径采购确认、拖链/管夹明细、真实PLC和电气驱动、实物加工/食品接触验证；热封工艺参数、膜张力控制和电气走线尚未冻结。
'''
(S/'SW_IMPORT_README_中文.md').write_text(guide)
for n in ['sw_assembly_checks.json','service_checks.json','geometry_verification.json','delivery_checks.json','mount_checks.json','assembly_review_11.json','motion_checks.json']:
 if (O/n).exists():shutil.copy2(O/n,S/n)
review=(D/'assembly-review-11.html').read_text().replace('<meta charset="utf-8">','<meta charset="utf-8"><base href="https://scallion-mechanical-lab.supergenet16.chatgpt.site/">',1)
(S/'ENGINEERING_REVIEW.html').write_text(review)
out=O/'Scallion_SW_Assembly_12.zip'
temporary=out.with_suffix('.building.zip')
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in S.iterdir():
  if '_06' not in p.name:z.write(p,'Scallion_SW_Assembly_11/'+p.name)
with zipfile.ZipFile(temporary) as z:assert z.testzip() is None
temporary.replace(out)
print(json.dumps({k:v for k,v in check.items() if k!='assembly_tree'},ensure_ascii=False,indent=2));print('Package bytes',out.stat().st_size)
