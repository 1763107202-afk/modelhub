"""Mechanical design refinement. Nominal dimensions are SI metres.
Bought cylinders, drives and valves are installation envelopes with explicit requirements.
"""
import math,json
import numpy as np
import cadquery as cq

PORTS={};LINES=[];DRIVES=[];JOINTS=[]
def make_shape(kind,d):
 V=cq.Vector
 if kind=='drilled':
  w,h,z,holes=d;s=cq.Workplane('XY').box(w,h,z).val()
  for x,zz,r in holes:s=s.cut(cq.Solid.makeCylinder(r,h+.004,V(x,-h/2-.002,zz),V(0,1,0)))
 elif kind=='knife':
  w,h,z=d;pts=[V(-w/2,-h/2,-z/2),V(w/2,-h/2,-z/2),V(w/2,-h/2,z/2),V(0,-h/2,z*.15),V(-w/2,-h/2,z/2),V(-w/2,-h/2,-z/2)]
  s=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts),[],V(0,h,0))
  for x in [-w*.28,w*.28]:s=s.cut(cq.Solid.makeCylinder(.0032,h+.004,V(x,-h/2-.002,-z*.28),V(0,1,0)))
  s=s.cut(cq.Solid.makeCylinder(.00301,h+.004,V(0,-h/2-.002,-.026),V(0,1,0)))
 elif kind=='keyshaft':
  r,h,seats=d;s=cq.Solid.makeCylinder(r,h,V(0,-h/2,0),V(0,1,0))
  for yy,ll in seats:s=s.cut(cq.Workplane('XY').box(.008,ll,.012).val().translate((r,yy,0)))
 elif kind=='keyed_hub':
  ri,ro,h=d;s=cq.Solid.makeCylinder(ro,h,V(0,-h/2,0),V(0,1,0)).cut(cq.Solid.makeCylinder(ri,h+.002,V(0,-h/2-.001,0),V(0,1,0)))
  s=s.cut(cq.Workplane('XY').box(.008,h+.002,.012).val().translate((.020,0,0)))
 elif kind=='drained_disk':
  r,h,x,z,rh=d;s=cq.Solid.makeCylinder(r,h,V(0,-h/2,0),V(0,1,0)).cut(cq.Solid.makeCylinder(rh,h+.004,V(x,-h/2-.002,z),V(0,1,0)))
  s=s.rotate((0,0,0),(0,0,1),-math.degrees(math.atan(.03)))
 elif kind in ['ellipse_rim','ellipse_bottom']:
  rx,rz,h=d[:3];outer=cq.Workplane('XZ').ellipse(rx,rz).val().translate((0,-h/2,0))
  inner=[cq.Workplane('XZ').ellipse(rx-.004,rz-.004).val().translate((0,-h/2,0))] if kind=='ellipse_rim' else []
  s=cq.Solid.extrudeLinear(outer,inner,V(0,h,0))
  if kind=='ellipse_bottom':
   s=s.rotate((0,0,0),(0,0,1),-math.degrees(math.atan(.03)))
   s=s.cut(cq.Solid.makeCylinder(.020,.040,V(.180,-.020,0),V(0,1,0)))
 elif kind=='coupling':
  rb,rt,ro,h=d;s=cq.Solid.makeCylinder(ro,h,V(0,-h/2,0),V(0,1,0))
  s=s.cut(cq.Solid.makeCylinder(rb,h/2+.002,V(0,-h/2-.001,0),V(0,1,0))).cut(cq.Solid.makeCylinder(rt,h/2+.002,V(0,-.001,0),V(0,1,0)))
  s=s.cut(cq.Workplane('XY').box(.014,h+.003,.012).val().translate((.020,0,0)))
 elif kind=='fluid_pipe':
  points,ro,ri=d;outer=[];inner=[]
  for a,b in zip(points,points[1:]):
   a,b=V(*a),V(*b);v=b-a
   if v.Length<1e-7:continue
   outer.append(cq.Solid.makeCylinder(ro,v.Length,a,v.normalized()));inner.append(cq.Solid.makeCylinder(ri,v.Length+.0004,a-v.normalized()*.0002,v.normalized()))
  for p in points[1:-1]:
   outer.append(cq.Solid.makeSphere(ro,V(*p),angleDegrees1=-90,angleDegrees2=90));inner.append(cq.Solid.makeSphere(ri,V(*p),angleDegrees1=-90,angleDegrees2=90))
  so=outer[0]
  for sh in outer[1:]:so=so.fuse(sh)
  si=inner[0]
  for sh in inner[1:]:si=si.fuse(sh)
  s=so.cut(si)
 else:raise ValueError(kind)
 return s

def deepen(env):
 P,G,M=env['PARTS'],env['GROUPS'],env['MATS'];part,group,box,cyl,ring,rod,ball,foot,bolts,plant=[env[k] for k in ['part','group','box','cyl','ring','rod','ball','foot','bolts','scallion']]
 def gp(name):return next(x for x in G if x['name']==name)
 def remove(prefix):P[:]=[p for p in P if not p['name'].startswith(prefix)]
 def cyla(name,a,b,r,parent='fixed',mat='steel',st=0):return rod(name,a,b,r,parent=parent,mat=mat,station=st)
 def tube(name,dims,pos,parent='fixed',st=0,mat='steel'):return part(name,'tube',[*dims,.0025],pos,parent=parent,station=st,mat=mat)
 def plate(name,w,z,pos,holes,parent='fixed',st=0,h=.008):return part(name,'drilled',[w,h,z,holes],pos,parent=parent,station=st)
 def beam(name,a,b,r=.012,parent='fixed',st=0):return rod(name,a,b,r,parent=parent,station=st)
 def joint(name,path,detail):JOINTS.append({'assembly':name,'load_path':path,'connection':detail})
 M.update({'water':{'color':'#37a6b6','metal':.05,'rough':.3,'density':1100},'drain':{'color':'#947759','metal':.2,'rough':.5,'density':1350},'wire':{'color':'#c39a49','metal':.1,'rough':.5,'density':1300},'fluid':{'color':'#81c7d2','metal':0,'rough':.2,'alpha':.35,'density':0}})
 # Products are explicit raw and finished variants; no leaf-bearing remnant above the cutter.
 original=plant
 for g in list(G):
  if g['label'].startswith('大葱占位'):
   name=g['name'];g['label']='原料φ26 / L780；成品定长520 mm（形态占位）'
   for suffix in ['leaf','root']:
    old=[p for p in P if p['parent']==name and p['name'].startswith(name+'_'+suffix+'_')]
    extra=group(name+'_raw_'+suffix,name,station=g['station'],label='切除的上部叶片' if suffix=='leaf' else '切除的根须')
    for p in old:p['parent']=extra
   for p in P:
    if p['name']==name+'_neck':p['dims']=[.0115,.0105,.08];p['pos'][1]=.48
 # Main clamp is BELOW the 1.080 m leaf-cutting plane, clear of the shortened peel scan.
 for g in G:
  if g['name'].startswith('clamp_'):g['pos'][1]=1.035
 for p in P:
  n=p['name']
  if n.startswith('clamp_bridge_'):p['pos'][1]=1.030
  if n.startswith('spine_'):p['dims']=[.03,.46,.03,.002];p['pos'][1]=1.225
  if n.startswith(('arm_RHS_','offset_tie_')):p['pos'][1]=1.455
  if n.startswith('arm_mount_'):p['pos'][1]=1.480
  if n.startswith('passive_clamp_link_'):p['dims']=[list((p['dims'][0][0]+.045,1.060,.180)),list((p['dims'][1][0]+.045,1.470,.180)),.003]
  if n.startswith('passive_cam_'):p['pos'][1]=1.480
  if n.startswith(('loader_pick_','unload_hand_')):p['pos'][1]=.985
  if n.startswith('pack_eject_hand'):p['pos'][1]=.985
  if n.startswith('magazine_clip_back_'):p['pos'][1]=1.12;p['dims'][1]=.24
  if n.startswith('magazine_clip_') and not n.startswith('magazine_clip_back_'):p['pos'][1]=1.035
  if n=='feeder_upper_skirt':p['pos'][1]=1.00;p['dims'][2]=.30
  if n=='magazine_shaft':p['dims'][0]=.0175
  if n.startswith('scan_ballscrew'):p['dims'][1][1]=.955
  if n.startswith('opener16_rod_'):p['pos'][1]=1.550
 gp('peel_scan')['label']='370 mm白茎扫描，喷头先开环再径向退出320 mm'
 # Real bearing envelope: NSK 6208, d40 x D80 x B18. Internal race geometry is schematic.
 remove(('bearing_housing_','bearing_outer_','bearing_ball_','main_shaft_d40','spring_cap_','arm_mount_'))
 part('main_shaft_40_with_keyseats','keyshaft',[.02,1.015,[[-.4925,.03],[.4625,.05]]],(0,.9275,0),parent='carousel')
 cyl('gear_output_stub32',.016,.030,(0,.405,0),parent='drive')
 part('stepped_keyed_coupling_32_40','coupling',[.01605,.02005,.038,.060],(0,.420,0),parent='drive')
 box('coupling_key12x8x30',.008,.030,.012,(.020,.435,0),parent='carousel')
 ring('main_load_column',.084,.090,.840,(0,.830,0),parent='drive')
 for i,y in enumerate([.500,.750]):
  ring('6208_housing_'+str(i),.04001,.056,.040,(0,y,0),parent='drive')
  ring('6208_outer_race_'+str(i),.035,.040,.018,(0,y,0),parent='drive',mat='dark')
  ring('6208_inner_race_'+str(i),.02001,.025,.018,(0,y,0),parent='carousel')
  for j in range(10):ball(f'6208_ball_schematic_{i}_{j}',.005,(.030*math.cos(j*math.tau/10),y,.030*math.sin(j*math.tau/10)),parent='drive')
  ring('bearing_support_flange_'+str(i),.021,.096,.012,(0,y-.026,0),parent='drive')
  ring('bearing_cover_'+str(i),.0205,.057,.006,(0,y+.023,0),parent='drive')
  bolts('bearing_M8_'+str(i),.048,y+.031,4,parent='drive',size=.004)
 ring('shaft_locating_shoulder',.020,.024,.008,(0,.487,0),parent='carousel')
 ring('shaft_locknut_M40',.020,.029,.008,(0,.518,0),parent='carousel')
 part('hub_keyed_boss40','keyed_hub',[.02003,.055,.060],(0,1.395,0),parent='carousel')
 box('hub_key12x8x50',.008,.050,.012,(.020,1.390,0),parent='carousel')
 ring('base_column_flange',.021,.18,.012,(0,.406,0),parent='drive')
 for k in range(6):
  a=k*math.tau/6;fg=group('frame_radial_'+str(k),'fixed',yaw=-k*60)
  tube('foundation_RHS50_'+str(k),(.64,.05,.05),(.42,.375,0),parent=fg)
  tube('foundation_foot_post_'+str(k),(.04,.258,.04),(.68,.221,0),parent=fg)
  plate('foot_thread_insert_'+str(k),.055,.055,(.68,.088,0),[[0,0,.010]],parent=fg,h=.008)
  plate('rotor_arm_saddle_'+str(k),.09,.07,(.225,1.431,0),[[-.028,-.021,.0033],[.028,-.021,.0033],[-.028,.021,.0033],[.028,.021,.0033]],parent='carrier_'+str(k),st=k+1,h=.008)
  plate('rotor_arm_saddle_top_'+str(k),.09,.07,(.225,1.479,0),[[-.028,-.021,.0033],[.028,-.021,.0033],[-.028,.021,.0033],[.028,.021,.0033]],parent='carrier_'+str(k),st=k+1,h=.008)
  for j,(xx,zz) in enumerate([[-.028,-.021],[.028,-.021],[-.028,.021],[.028,.021]]):
   cyl(f'rotor_arm_saddle_bolt_M6_{k}_{j}',.003,.070,(.225+xx,1.459,zz),parent='carrier_'+str(k),station=k+1,mat='dark')
   ring(f'rotor_arm_saddle_washer_{k}_{j}',.0032,.007,.0015,(.225+xx,1.484,zz),parent='carrier_'+str(k),station=k+1)
 joint('主转位轴系','750 W伺服 → 80:1减速器 → 32/40阶梯联轴器 → φ40主轴 → 键连接轮毂 → 六根矩形管悬臂','两只6208，中心距250 mm；下端定位、上端外圈浮动。键12×8，下联轴器30 mm、上轮毂50 mm有效长。轴承内形仅示意。')
 joint('承载机架','轮毂/轴承支反力 → 承载立柱 → 底法兰 → 六根50×50×2.5型管 → 脚柱 → 调平脚','底法兰焊/螺接，悬臂带M6鞍座与定位面；焊缝等级、螺栓预紧和公差图尚待设计。')
 # Passive jaw opening: 60 mm axial cam travel opens 42 mm on each side.
 for k in range(6):
  for l in range(2):
   cg=f'clamp_{k}_{l}'
   box(f'constant_force_spring_cartridge_{k}_{l}',.045,.040,.025,(0,.010,.15),parent=cg,station=k+1,mat='green')
   for s in [-1,1]:ball(f'cam_follower_{k}_{l}_{s}',.005,(.015,.025,s*.027),parent=cg,station=k+1,mat='dark')
   r=[.48,.62][l]
   rod(f'passive_cam_top_offset_{k}_{l}',(r,1.470,.075),(r+.045,1.470,.180),.003,parent='carrier_'+str(k),station=k+1)
   rod(f'passive_cam_lower_offset_{k}_{l}',(r,1.060,.075),(r+.045,1.060,.180),.003,parent='carrier_'+str(k),station=k+1)
 joint('弹簧保夹与开夹','2×16 N恒力弹簧 → 滑动夹爪；工位φ16气缸 → 60 mm推杆 → 双斜面滚轮凸轮 → 夹爪各开42 mm','φ16气缸推力按效率0.7计算，凸轮等效斜率0.7、摩擦系数余量1.5。恒力弹簧和凸轮是待锁定采购/加工规格，湿态摩擦须试验。')
 # Feed rotor carries suspended roots ABOVE the knife; bottom roots have a clear drop route.
 remove(('magazine_bottom','magazine_root_cup_','loader_fork_','air_service_hose_'))
 ring('magazine_support_ring_above_root',.145,.36,.008,(0,.720,0),parent='magazine')
 for k in range(12):
  for l,r in enumerate([.18,.32]):
   ring(f'magazine_lower_open_guide_{k}_{l}',.030,.035,.018,(r,.720,0),start=55,angle=250,parent='magazine_sector_'+str(k),station=1,mat='pad')
 gp('feeder')['label']='自动装料 / 悬根式24位双圈缓冲盘'
 gp('magazine')['label']='出料0° / 自动装料90° / 定点切根180°'
 group('feed_drive','feeder',station=1)
 cyl('feed_index_reducer_60',.065,.10,(0,.35,0),parent='feed_drive',mat='dark')
 cyl('feed_servo_400W',.038,.12,(0,.24,0),parent='feed_drive',mat='black')
 ring('feed_bearing_lower_6207',.01751,.036,.017,(0,.43,0),parent='feed_drive')
 ring('feed_bearing_upper_6207',.01751,.036,.017,(0,.65,0),parent='feed_drive')
 tube('feed_column_support',(.08,.28,.08),(0,.55,0),parent='feed_drive')
 part('feed_service_deck_with_root_drop','ring_cutout',[.04,.39,.006,.140,.25,180],(0,.425,0),parent='feeder')
 for p in P:
  if p['name']=='feeder_base':p['dims'][3:]=[220,280]
 group('root_station','feeder',yaw=-180,station=1,label='盘下切根：停稳→近根支承→切断→退刀→整座退出')
 group('root_retract','root_station',pos=(.34,0,0),station=1)
 for z in [-.10,.10]:
  box('root_radial_rail_'+str(z),.54,.024,.020,(.48,.455,z),parent='root_station',station=1,mat='dark')
 tube('root_cut_support_post',(.04,.353,.04),(.67,.2665,0),parent='root_station',st=1)
 plate('root_cutter_slide_base',.34,.25,(.25,.485,0),[[-.14,-.10,.0043],[.14,-.10,.0043],[-.14,.10,.0043],[.14,.10,.0043],[-.07,0,.040],[.07,0,.040]],parent='root_retract',st=1)
 group('root_knife','root_retract',pos=(0,0,-.09),station=1)
 for l,r in enumerate([.18,.32]):
  part('root_knife_3mm_'+str(l),'knife',[.08,.003,.07],(r,.560,0),parent='root_knife',station=1)
  box('root_blade_clamp_'+str(l),.075,.012,.024,(r,.5525,-.02),parent='root_knife',station=1)
  box('root_counterknife_'+str(l),.075,.012,.040,(r,.5524,.045),parent='root_retract',station=1,mat='dark')
  ring('root_V_support_'+str(l),.022,.035,.045,(r,.625,0),start=25,angle=130,parent='root_retract',station=1,mat='pad')
  for xx in [-.0224,.0224]:cyl('root_blade_M6_'+str(l)+str(xx),.003,.020,(r+xx,.560,-.0196),parent='root_knife',station=1,mat='dark')
  cyl('root_location_dowel_'+str(l),.003,.018,(r,.556,-.026),parent='root_knife',station=1,mat='dark')
 cyla('root_cyl80_barrel',(.25,.49,-.35),(.25,.49,-.15),.046,parent='root_retract',mat='blue',st=1)
 cyla('root_cyl80_rod',(.25,.49,-.15),(.25,.49,-.06),.010,parent='root_retract',st=1)
 box('root_force_sensor_5kN',.04,.032,.035,(.25,.49,-.075),parent='root_knife',station=1,mat='dark')
 box('root_common_knife_bridge',.22,.016,.10,(.25,.5445,-.07),parent='root_knife',station=1)
 box('root_knife_clevis',.035,.065,.035,(.25,.521,-.075),parent='root_knife',station=1)
 ring('root_waste_bin',.117,.122,.25,(.25,.235,0),parent='root_station',station=1,mat='green')
 cyl('root_waste_bottom',.122,.006,(.25,.108,0),parent='root_station',station=1)
 ring('root_hopper',.115,.14,.040,(.25,.405,0),parent='root_station',station=1)
 for z in [-.41,.41]:box('root_knife_side_guard_'+str(z),.80,.24,.004,(.45,.56,z),parent='root_station',station=1,mat='glass')
 box('root_knife_outer_guard',.004,.24,.82,(.85,.56,0),parent='root_station',station=1,mat='glass')
 joint('定点切根','φ80×160气缸 → 5 kN测力元件 → 双刀共用滑座 → 3 mm V刃刀片；反力经固定反刃与近根V托回到同一刀架','双刀总切割阻力800 N是设计上限，非实测。反刃间隙名义0.10 mm；刀座两根导轨、M6压条与定位销。整座径向退出340 mm后才允许供料盘分度。')
 # S3: pre-grip the waste leaves, cut at 520 mm finished length, move whole offcuts outward.
 group('top_retract','station3',pos=(.36,0,0),station=3,label='定长剪叶与冲洗头整体退出360 mm')
 group('top_knife','top_retract',pos=(0,0,-.09),station=3)
 for z in [-.22,.22]:tube('top_cut_open_frame_'+str(z),(.50,.025,.03),(.60,1.085,z),parent='top_retract',st=3)
 tube('top_cut_outer_crossmember',(.025,.025,.46),(.85,1.085,0),parent='top_retract',st=3)
 for l,r in enumerate([.48,.62]):
  part('leaf_knife_3mm_'+str(l),'knife',[.11,.003,.07],(r,1.080,0),parent='top_knife',station=3)
  box('leaf_counterknife_'+str(l),.11,.012,.04,(r,1.0724,.045),parent='top_retract',station=3,mat='dark')
  for dx in [-.0308,.0308]:cyl('leaf_blade_M6_'+str(l)+str(dx),.003,.018,(r+dx,1.080,-.0196),parent='top_knife',station=3)
  cyl('leaf_blade_dowel_'+str(l),.003,.018,(r,1.076,-.026),parent='top_knife',station=3,mat='dark')
 cyla('top_cyl63_barrel',(.55,1.02,-.35),(.55,1.02,-.15),.037,parent='top_retract',mat='blue',st=3)
 cyla('top_cyl63_rod',(.55,1.02,-.15),(.55,1.02,-.06),.008,parent='top_retract',st=3)
 box('top_common_knife_bridge',.28,.012,.05,(.55,1.0725,-.020),parent='top_knife',station=3)
 box('top_knife_clevis',.035,.055,.035,(.55,1.047,-.075),parent='top_knife',station=3)
 group('leaf_pick','station3',station=3,label='先夹住切除段，再剪断、抬升60 mm、外送400 mm')
 for l,r in enumerate([.48,.62]):
  box('leaf_waste_grip_'+str(l),.07,.05,.03,(r,1.160,-.065),parent='leaf_pick',station=3,mat='green')
  for z in [-.060,.060]:box('leaf_waste_jaw_'+str(l)+str(z),.065,.050,.010,(r,1.160,z),parent='leaf_pick',station=3,mat='pad')
  leaf=plant('leaf_offcut_'+str(l),(r,1.080,0),'leaf_pick',station=3)
  # Offcut only: short leaf segments. Never display a full stem in the discarded fraction.
  P[:]=[p for p in P if not (p['parent']==leaf and p['name'].startswith(('leaf_offcut_'+str(l)+'_stem','leaf_offcut_'+str(l)+'_neck','leaf_offcut_'+str(l)+'_root')))]
  for p in P:
   if p['parent']==leaf and p['kind']=='taperrod':
    p['dims'][0][1]=.01;p['dims'][1][1]=.25
 for z in [-.19,.19]:tube('top_head_radial_beam_'+str(z),(.62,.04,.035),(.91,1.58,z),parent='station3',st=3)
 for r in [.48,.62]:tube('top_head_drop_link_'+str(r),(.025,.50,.025),(r,1.33,-.18),parent='top_retract',st=3)
 ring('leaf_waste_bin',.17,.176,.62,(.97,.70,0),parent='station3',station=3,mat='green')
 ring('leaf_waste_hopper_lip',.165,.195,.020,(.97,1.02,0),parent='station3',station=3)
 cyl('leaf_bin_bottom',.176,.008,(.97,.386,0),parent='station3',station=3)
 joint('定长剪叶','主夹爪保留在1.035 m → 上部废叶夹接住 → φ63×160双刀剪切于1.080 m → 废叶夹抬升60 mm并径向外送400 mm → 大口径废叶桶','成品基线长520 mm，刀面与主夹持组件名义间隙≥25 mm。上刀架、废叶夹和喷淋头都必须退出主站扫掠区。')
 # Fresh-water spray, detachable catch tray and separate gravity waste line.
 part('rinse_catch_tray','ellipse_rim',[.21,.17,.040],(.55,.455,0),parent='station3',station=3)
 part('rinse_tray_sloped_bottom','ellipse_bottom',[.21,.17,.004],(.55,.439,0),parent='station3',station=3)
 part('rinse_removable_strainer','drilled',[.10,.004,.08,[[x,z,.003] for x in [-.04,-.02,0,.02,.04] for z in [-.025,0,.025]]],(.70,.444,0),parent='station3',station=3,mat='dark')
 for l,r in enumerate([.48,.62]):
  for z in [-.07,.07]:
   cyla('water_nozzle_'+str(l)+str(z),(r,.89,z),(r,.89,z*.7),.006,parent='top_retract',mat='water',st=3)
 # Automatic upstream feeder. Bulk orientation is retained; manual insertion into slots is eliminated.
 group('bulk_feed','fixed',station=1,label='整批根端同向来料 → 薄层摊开 → 双料回送 → 双夹翻立')
 box('spread_belt_food_grade',.83,.018,1.40,(-1.81,.560,1.34),parent='bulk_feed',station=1,mat='pad')
 for x in [-2.25,-1.37]:tube('belt_longitudinal_frame_'+str(x),(.04,.08,1.53),(x,.50,1.33),parent='bulk_feed',st=1)
 for z in [.64,2.04]:
  cyla('belt_roller_'+str(z),(-2.24,.525,z),(-1.38,.525,z),.035,parent='bulk_feed',mat='dark',st=1)
  for x in [-2.20,-1.42]:tube('belt_leg_'+str(z)+str(x),(.035,.43,.035),(x,.27,z),parent='bulk_feed',st=1)
 for n in range(10):box('stem_metering_flight_'+str(n),.30,.018,.012,(-1.53,.581,.67+n*.14),parent='bulk_feed',station=1,mat='green')
 box('root_end_guide',.018,.10,1.40,(-1.36,.62,1.33),parent='bulk_feed',station=1,mat='steel')
 box('soft_combing_crossbeam',.80,.06,.055,(-1.82,.74,1.57),parent='bulk_feed',station=1,mat='dark')
 for n in range(12):box('soft_comb_finger_'+str(n),.012,.09,.018,(-2.17+n*.06,.68,1.57),parent='bulk_feed',station=1,mat='pad')
 for j,z in enumerate([1.08,1.22,1.36,1.50,1.64,1.78]):
  nm=plant('belt_raw_'+str(j),(-1.40,.600,z),'bulk_feed',station=1);gp(nm)['roll']=90
 box('double_feed_profile_sensor',.10,.07,.045,(-1.58,.82,1.05),parent='bulk_feed',station=1,mat='blue')
 box('double_feed_return_flap',.30,.015,.11,(-1.53,.585,1.12),parent='bulk_feed',station=1,mat='green')
 box('bulk_supply_landing_tray',.83,.004,.32,(-1.81,.580,2.20),parent='bulk_feed',station=1)
 box('bulk_supply_rear_guard',.83,.18,.004,(-1.81,.67,2.36),parent='bulk_feed',station=1)
 for x in [-2.225,-1.395]:box('bulk_supply_side_guard_'+str(x),.004,.18,.32,(x,.67,2.20),parent='bulk_feed',station=1)
 for x in [-2.17,-1.46]:tube('bulk_supply_support_'+str(x),(.03,.48,.03),(x,.33,2.27),parent='bulk_feed',st=1)
 box('belt_200W_drive',.14,.12,.14,(-2.32,.49,1.97),parent='bulk_feed',station=1,mat='black')
 group('upender_slide','fixed',station=1,label='翻立后X补偿200 mm / Z插入500 mm，先接料再松夹')
 group('upender_roll','upender_slide',pos=(-1.30,.50,0),station=1,label='φ25双支承轴 / 400 W+50:1 / 90°翻立')
 for l,z in enumerate([.68,.82]):
  rod('upender_arm_'+str(l),(0,0,z-.06),(-.35,.10,z-.06),.011,parent='upender_roll',station=1)
  box('upender_force_gripper_'+str(l),.055,.045,.10,(-.35,.10,z),parent='upender_roll',station=1,mat='green')
  nm=plant('upender_product_'+str(l),(-.10,.10,z),'upender_roll',station=1);gp(nm)['roll']=90
 cyla('upender_shaft25',(0,0,.56),(0,0,.96),.0125,parent='upender_roll',st=1)
 for z in [.58,.94]:
  box('upender_bearing_block_'+str(z),.075,.075,.035,(-1.30,.50,z),parent='upender_slide',station=1,mat='dark')
 cyla('upender_400W_50to1',(-1.30,.50,.97),(-1.30,.50,1.12),.055,parent='upender_slide',mat='black',st=1)
 for x in [-1.28,-1.10]:box('upender_Z_rail_'+str(x),.025,.025,.78,(x,.42,.55),parent='bulk_feed',station=1,mat='dark')
 box('upender_X_compensation_200mm',.32,.06,.12,(-1.30,.39,.76),parent='upender_slide',station=1,mat='green')
 cyla('upender_Z_screw16',(-1.18,.39,.12),(-1.18,.39,.95),.008,parent='bulk_feed',st=1,mat='dark')
 box('upender_Z_400W',.08,.10,.10,(-1.18,.39,1.02),parent='bulk_feed',station=1,mat='black')
 box('upender_X_200W',.08,.10,.10,(-1.09,.39,.76),parent='upender_slide',station=1,mat='black')
 cyla('upender_lift25x40',(-1.30,.34,.55),(-1.30,.46,.55),.020,parent='upender_slide',st=1,mat='blue')
 # Feed clamps are passive: fixed cam openers at 90° fill and 0° outlet do not rotate hoses.
 for k in range(12):
  for l,r in enumerate([.18,.32]):
   box(f'feed_spring_cartridge_{k}_{l}',.034,.04,.025,(r,1.060,.07),parent='magazine_sector_'+str(k),station=1,mat='green')
 for a in [0,90]:
  fg=group('feed_opener_'+str(a),'feeder',yaw=-a,station=1)
  for r in [.18,.32]:cyl('feed_opener16_'+str(a)+str(r),.012,.10,(r,1.49,.07),parent=fg,station=1,mat='blue')
 joint('供料盘被动夹持','恒力弹簧夹保持悬根 → 固定90°装料开夹器 / 固定0°取料开夹器 → 下层开口导向限制摆动','装料夹持确认与根盘高度检测双重满足后才松开翻立夹。单根重力靠弹簧夹承受，根端开口导向不能代替保夹。')
 # Explicit supports and drive envelopes for the added cutter and waste handling axes.
 for name,parent,xa,xb,y,z,power in [('root_radial','root_station',.22,.77,.435,.15,200),('top_radial','station3',.42,1.12,1.58,.22,200)]:
  cyla(name+'_screw16',(xa,y,z),(xb,y,z),.008,parent=parent,st=1 if name.startswith('root') else 3,mat='dark')
  box(name+'_servo',.08,.10,.10,(xb+.05,y,z),parent=parent,station=1 if name.startswith('root') else 3,mat='black')
  DRIVES.append({'id':name,'power_W':power,'transmission':'16×5滚珠丝杠 / 双导轨 / 端位传感','minimum':'有效行程340 mm（切根）/360 mm（剪叶），额定推力≥300 N'})
 cyla('leaf_lift25x60',(.55,1.20,-.13),(.55,1.36,-.13),.020,parent='leaf_pick',st=3,mat='blue')
 cyla('leaf_transfer32x400',(.50,1.53,-.15),(1.10,1.53,-.15),.026,parent='station3',st=3,mat='blue')
 for z in [-.15,.15]:box('leaf_transfer_guide_'+str(z),.64,.02,.02,(.78,1.47,z),parent='station3',station=3,mat='dark')
 # Roots must react into the stationary counterknife support rather than the 32 N food grip.
 for l,r in enumerate([.18,.32]):
  box('root_near_cut_clamp_'+str(l),.065,.040,.014,(r,.605,-.040),parent='root_retract',station=1,mat='pad')
  cyla('root_hold25_'+str(l),(r,.605,-.15),(r,.605,-.06),.019,parent='root_retract',st=1,mat='blue')
 joint('自动供料与翻立','整批同向投料 → 同步托叶带/根端计量带 → 柔性梳分薄层 → 双料轮廓检测/回送 → 两根夹持 → 90°翻立 → X补偿200 mm、Z送入500 mm → 转盘弹簧夹保夹','双夹每拍2根，计量节距140 mm。原料须拆捆、单株分离、根端大致同向；缠叶、双料、根盘定位失败进入回退或停机处置。识别和分料成功率待实料验证。')
 # Main linear axes now have explicit screw/belt drives, support bearings and nuts.
 for nm,p0,p1,station,power in [
  ('loading',(-1.36,.455,-.14),(-.60,.455,-.14),1,200),
  ('weigh',(.48,.445,.15),(1.12,.445,.15),4,200),
  ('unloading',(.50,.455,-.17),(1.60,.455,-.17),5,400)]:
  pa='station'+str(station) if nm!='loading' else 'fixed'
  cyla(nm+'_screw16',p0,p1,.008,parent=pa,mat='dark',st=station)
  for i,p in enumerate([p0,p1]):box(nm+'_BKBF_'+str(i),.045,.05,.048,p,parent=pa,station=station)
  box(nm+'_servo_'+str(power)+'W',.07,.10,.09,(p1[0]+.055,p1[1],p1[2]),parent=pa,station=station,mat='black')
  DRIVES.append({'id':nm,'power_W':power,'transmission':'16×5滚珠丝杠 / BK-BF端支承 / 行程按装配','minimum':'额定轴向推力≥300 N，防水罩覆盖湿区，螺母座与移动框架螺接'})
 DRIVES[:0]=[{'id':'M1 主站','power_W':750,'transmission':'80:1减速 + φ40键轴 + 6208双支承','minimum':'减速器额定输出≥120 N·m，峰值≥240 N·m'}, {'id':'M2 供料盘','power_W':400,'transmission':'60:1减速 + φ35轴 + 6207双支承','minimum':'输出额定≥40 N·m，厂家惯量比/热容量待复核'}, {'id':'M3 翻立','power_W':400,'transmission':'50:1减速 + φ25双轴承轴','minimum':'输出额定≥45 N·m；末端两爪各32 N总法向力'}, {'id':'M4 薄层计量','power_W':200,'transmission':'封闭减速电机 + 同步根端/托叶带','minimum':'带速基线0.035 m/s，双料检测与回送互锁'}]
 DRIVES.extend([{'id':'翻立X/Z轴','power_W':600,'transmission':'X200 W/Z400 W，16×5丝杠，Y气动校高40 mm','minimum':'X200/Z500 mm，托根检测；行程原点与硬限位'}, {'id':'去皮扫描/径向','power_W':400,'transmission':'各200 W，16×5丝杠，竖直行程370 mm、径向320 mm','minimum':'四个半环用φ20×80气缸独立端位检测'}, {'id':'成束移出/缓存','power_W':400,'transmission':'200 W横移，200 W缓存分度','minimum':'束带采购头独立供电预算500 W，确认接口后接入'}, {'id':'清水泵','power_W':370,'transmission':'采购泵工作点10 L/min @40 m','minimum':'低液位、压力、流量联锁；不以关死阀最大扬程选型'}, {'id':'空压机','power_W':11000,'transmission':'外置0.8 MPa / FAD≥1.3 m³/min采购包','minimum':'含合规100 L储气罐、干燥过滤、排凝，额定流量依厂家曲线'}])
 # Utility sources are purchased packages, not self-designed pressure vessels.
 group('air_source','fixed',pos=(-.85,0,-1.72),station=0,label='外置空压机、100 L合规储气罐与后处理')
 cyla('receiver100L_shell',(-.37,.34,0),(.37,.34,0),.18,parent='air_source',mat='blue')
 for x in [-.37,.37]:ball('receiver_dome_'+str(x),.18,(x,.34,0),parent='air_source',mat='blue')
 for x in [-.30,.30]:box('receiver_saddle_'+str(x),.10,.16,.31,(x,.14,0),parent='air_source')
 box('compressor_11kW_package',.45,.33,.29,(-.13,.68,0),parent='air_source',mat='dark')
 box('dryer_package',.20,.34,.24,(.46,.65,0),parent='air_source',mat='green')
 cyl('receiver_safety_valve',.014,.08,(.20,.56,0),parent='air_source',mat='orange')
 cyl('receiver_auto_drain',.012,.07,(.25,.12,0),parent='air_source',mat='dark')
 group('water_source','fixed',pos=(1.68,0,-.73),label='生活饮用水接入口 → 空气间隙 → 60 L有效清水箱 → 泵')
 ring('fresh_tank_75L_gross',.197,.20,.60,(0,.47,0),parent='water_source')
 cyl('fresh_tank_water_60L',.195,.48,(0,.41,0),parent='water_source',mat='fluid',cad=False)
 cyl('fresh_tank_bottom',.20,.005,(0,.169,0),parent='water_source')
 ring('fresh_tank_lid',.025,.204,.008,(0,.774,0),parent='water_source')
 cyl('fresh_fill_receiver',.027,.045,(0,.802,0),parent='water_source',mat='water')
 box('water_pump_370W',.19,.17,.24,(.28,.27,-.03),parent='water_source',mat='green')
 for y in [.31,.69]:box('tank_level_switch_'+str(y),.035,.04,.04,(.20,y,0),parent='water_source',mat='blue')
 for x in [-.14,.14]:tube('water_skid_leg_'+str(x),(.03,.16,.03),(x,.095,0),parent='water_source')
 group('flow_air','fixed',label='蓝：压缩空气，固定支路+移动端软管预留')
 group('flow_water','fixed',label='青：清水一次通过；不接污水回流')
 group('flow_drain','fixed',label='棕：冲洗废水/溢流/排凝，重力排至现场接口')
 group('flow_power','fixed',label='金：供电干线与动力驱动示意，非施工接线图')
 def port(id,pos,kind,desc):
  PORTS[id]={'id':id,'pos':list(pos),'kind':kind,'description':desc}
  ball('port_'+id,.009,pos,parent='flow_'+('air' if kind=='air' else 'water' if kind=='water' else 'drain' if kind=='drain' else 'power'),mat='blue' if kind=='air' else 'water' if kind=='water' else 'drain' if kind=='drain' else 'wire')
 def route(id,a,b,kind,via=(),di=.008,do=.012,note=''):
  pts=[PORTS[a]['pos']]+[list(p) for p in via]+[PORTS[b]['pos']]
  par='flow_'+kind;mat={'air':'blue','water':'water','drain':'drain','power':'wire'}[kind]
  part(id,'fluid_pipe',[pts,do/2,di/2],parent=par,mat=mat)
  LINES.append({'id':id,'from':a,'to':b,'medium':kind,'inside_mm':di*1000,'outside_mm':do*1000,'points':pts,'note':note})
 def block(id,pos,label,mat='dark'):
  box(id,.075,.055,.07,pos,mat=mat);return pos
 port('AIR_SOURCE',(-.35,.65,-1.72),'air','经后处理的外置0.8 MPa气源，FAD采购要求≥1.3 m³/min')
 port('AIR_FILTER',(-.88,1.12,-.84),'air','截止、过滤排水、监测、卸压总成')
 port('AIR_REG_PEEL',(-.80,1.12,-.84),'air','去皮独立调压0.45 MPa，允许试验0.35–0.60 MPa')
 port('AIR_REG_ACT',(-.72,1.12,-.84),'air','执行器独立调压0.50 MPa')
 route('A001_DN25','AIR_SOURCE','AIR_FILTER','air',[(-.35,.20,-1.3),(-.88,.20,-1.3)],.021,.027)
 route('A002','AIR_FILTER','AIR_REG_PEEL','air',di=.012,do=.018)
 route('A003','AIR_FILTER','AIR_REG_ACT','air',via=[(-.88,1.2,-.84),(-.72,1.2,-.84)],di=.012,do=.018)
 consumers=[('ROOT_VALVE',(-2.02,.48,-.13),'φ80切根阀组；刀架活动段采用柔性回环'),('TOP_VALVE',(.60,1.04,-.92),'φ63剪叶阀组'),('PEEL_VALVE',(-.48,.78,-.72),'两路8孔喷环阀'),('CLAMP_VALVES',(.93,1.65,.2),'各固定工位开夹阀组'),('RINSE_BLOW',(.45,.92,-.78),'剪叶冲洗后短时吹水阀')]
 for id,pos,desc in consumers:
  block(id,pos,desc,mat='blue');port(id,pos,'air',desc)
  source='AIR_REG_PEEL' if id=='PEEL_VALVE' else 'AIR_REG_ACT'
  route('A_'+id,source,id,'air',via=[(PORTS[source]['pos'][0],.20,-.95),(pos[0],.20,-.95)],di=.010 if id=='PEEL_VALVE' else .008,do=.016 if id=='PEEL_VALVE' else .012,note='在移动轴处配置拖链/软管余量；此路径为装配静态布置')
 for l,r in enumerate([.48,.62]):
  theta=math.radians(240);pos=(r*math.cos(theta),.78,r*math.sin(theta));id='PEEL_HEAD_'+str(l);port(id,pos,'air','喷环入口，孔径1 mm×8')
  route('A_HEAD_'+str(l),'PEEL_VALVE',id,'air',via=[(-.42,.85,-.73)],di=.008,do=.012)
 for id,pos,desc in [('AUTO_GRIP',(-1.5,.85,.75),'翻立双夹φ20、校高φ25与供料盘固定开夹'),('LEAF_HANDLING',(.65,1.40,-.92),'废叶双夹、φ25抬升、φ32外送'),('PEEL_MOTION',(-.60,.90,-.80),'四个φ20×80喷环开合气缸'),('TRANSFER_GRIP',(.9,.98,.30),'上料/卸料/成束转运夹和称重升降气缸')]:
  port(id,pos,'air',desc);route('A_'+id,'AIR_REG_ACT',id,'air',via=[(-.72,.20,-.95),(pos[0],.20,-.95)],di=.008,do=.012,note='阀组在静止支架，移动轴末端用食品区适配软管与拖链')
 port('MAINS_WATER',(2.20,1.12,-.73),'water','现场饮用水接口；供水条件待现场确认')
 port('FILL_VALVE',(1.92,.98,-.73),'water','常闭补水阀+手阀+过滤器')
 port('AIRGAP_OUT',(1.68,.856,-.73),'water','自由出水口，距箱顶接水口30 mm空气间隙')
 port('FRESH_TANK',(1.68,.826,-.73),'water','接水口，空气间隙按当地要求最终确认')
 port('PUMP_IN',(1.88,.25,-.73),'water','低液位联锁的清水泵吸入口')
 port('PUMP_OUT',(1.99,.30,-.73),'water','采购工况点10 L/min @40 m；370 W候选')
 port('WATER_REG',(1.30,.90,-.73),'water','压力表、过滤器、常闭喷淋阀及流量监测')
 route('W001','MAINS_WATER','FILL_VALVE','water',di=.013,do=.019)
 route('W002','FILL_VALVE','AIRGAP_OUT','water',di=.013,do=.019)
 LINES.append({'id':'W_AIRGAP_30','from':'AIRGAP_OUT','to':'FRESH_TANK','medium':'water','type':'airgap','gap_mm':30,'note':'设计空气间隙，非刚性管连接'})
 route('W003','FRESH_TANK','PUMP_IN','water',via=[(1.68,.20,-.73)],di=.019,do=.025,note='箱内清水经底出水口；示意线从水箱节点引出')
 route('W004','PUMP_IN','PUMP_OUT','water',di=.013,do=.019,note='通过采购泵内部叶轮流道')
 route('W005','PUMP_OUT','WATER_REG','water',via=[(1.99,.20,-1.05),(1.30,.20,-1.05)],di=.013,do=.019)
 for l,r in enumerate([.48,.62]):
  theta=math.radians(300);id='RINSE_HEAD_'+str(l);pos=(r*math.cos(theta),.89,r*math.sin(theta));port(id,pos,'water','两喷头×1.5 L/min @0.3 MPa，每通道3 L/min')
  route('W_HEAD_'+str(l),'WATER_REG',id,'water',via=[(.72,.75,-.73)],di=.010,do=.014)
 port('WATER_RELIEF',(1.92,.36,-.73),'water','0.45 MPa旁通，仅泵后未接触产品的清水可返回清水箱')
 route('W006_BYPASS','PUMP_OUT','WATER_RELIEF','water',di=.013,do=.019)
 route('W007_CLEAN_RETURN','WATER_RELIEF','FRESH_TANK','water',di=.013,do=.019)
 port('DIRTY_TRAY',(.365,.425,-.6321985448),'drain','S3椭圆集水盘420×340 mm，先截留叶片/固体再排水')
 part('tray_drain_spigot','fluid_pipe',[[[.365,.435,-.6321985448],[.365,.425,-.6321985448]],.024,.020],parent='flow_drain',mat='drain')
 port('DRAIN_SITE',(2.25,.13,-1.18),'drain','现场排水接入口；末端留空气隔断/地漏按现场设计')
 port('TANK_OVERFLOW',(1.87,.745,-.73),'drain','清水箱溢流，不接回供水管')
 port('RECEIVER_DRAIN',(-.60,.10,-1.72),'drain','后处理排凝单独收集，按含油情况处理，不直接回用')
 route('D001_DN40','DIRTY_TRAY','DRAIN_SITE','drain',via=[(.70,.21,-.90),(1.95,.17,-1.18)],di=.040,do=.048)
 route('D002_OVERFLOW','TANK_OVERFLOW','DRAIN_SITE','drain',via=[(2.12,.30,-.90)],di=.025,do=.032)
 # Condensate is explicitly separate from food-contact rinse water.
 port('CONDENSATE_COLLECTION',(-.50,.06,-1.96),'drain','独立排凝收集接口')
 route('D003_CONDENSATE','RECEIVER_DRAIN','CONDENSATE_COLLECTION','drain',di=.008,do=.012)
 port('POWER_IN',(1.15,.18,.55),'power','380 V /50 Hz三相五线现场接口，电气接入预算20 kW，非保护器件选型')
 port('CONTROL_PANEL',(1.00,.63,.52),'power','总隔离、保护、伺服驱动、24 VDC、PE与安全控制端子安装空间')
 block('control_cabinet',(1.00,.63,.52),'控制柜',mat='dark')
 route('E001','POWER_IN','CONTROL_PANEL','power',di=.018,do=.025)
 for id,pos in [('MAIN_DRIVE',(0,.20,0)),('FEED_DRIVE',(-1.4,.24,0)),('UPENDER_DRIVE',(-1.30,.50,1.08)),('BELT_DRIVE',(-2.32,.49,1.97)),('PUMP_DRIVE',(1.96,.27,-.76)),('COMPRESSOR_DRIVE',(-.98,.68,-1.72)),('LOAD_AXIS',(-.55,.455,-.14)),('WEIGH_AXIS',(1.175,.445,.15)),('UNLOAD_AXIS',(.20,.455,1.30)),('ROOT_AXIS',(-2.22,.435,-.15)),('TOP_AXIS',(.61,1.58,-1.02)),('UPENDER_XZ',(-1.18,.39,1.02)),('PEEL_AXES',(-.60,.99,-.75)),('EXTRACTION',(-.51,.40,-.88)),('BANDING_PACKAGE',(.75,1.10,1.30)),('OUTFEED_TRANSFER',(1.50,.48,1.45)),('OUTFEED_INDEX',(.9,.48,2.15))]:
  port(id,pos,'power','驱动和PE连接示意；保护、线径、端子号须电气详设')
  route('E_'+id,'CONTROL_PANEL',id,'power',via=[(1.0,.10,.52),(pos[0],.10,.52)],di=.008,do=.012)
 # Newly created raw products get the same independent root / upper-leaf display groups.
 for g in list(G):
  name=g['name']
  if name.startswith(('belt_raw_','upender_product_')) and g['label'].startswith('大葱占位'):
   for suffix in ['leaf','root']:
    extra=group(name+'_raw_'+suffix,name,station=1)
    for p in P:
     if p['parent']==name and p['name'].startswith(name+'_'+suffix+'_'):p['parent']=extra
  if g['label'].startswith(('原料φ26','大葱占位')) and not name.startswith('leaf_offcut_'):
   for p in P:
    if p['name']==name+'_stem':p['dims']=[.014,.0115,.40];p['pos'][1]=.20
    if p['name']==name+'_neck':p['dims']=[.0115,.010,.12];p['pos'][1]=.46
 (env['DIST']/'systems.json').write_text(json.dumps({'ports':PORTS,'lines':LINES,'drives':DRIVES,'joints':JOINTS},ensure_ascii=False,indent=2),encoding='utf-8')
