"""Named media ports, connected routes and constant-length flexible service loops.
Nominal layout, not a supplier routing/fitting release. SI metres throughout.
"""
import json, math
import numpy as np
import cadquery as cq

def loop_points(a,b,normal,length,count=33):
 a,b,n=map(lambda v:np.asarray(v,float),(a,b,normal));d=b-a
 n=n-d*np.dot(n,d)/max(np.dot(d,d),1e-12)
 if np.linalg.norm(n)<1e-7:n=np.cross(d,[0,0,1] if abs(d[2])<.8*np.linalg.norm(d) else [0,1,0])
 n/=np.linalg.norm(n);u=np.linspace(0,1,count)[:,None]
 def points(h):return a+(b-a)*u+4*u*(1-u)*n*h
 def arc(q):return float(np.linalg.norm(np.diff(q,axis=0),axis=1).sum())
 lo,hi=0.,max(length,1.)
 for _ in range(42):
  mid=(lo+hi)/2
  if arc(points(mid))<length:lo=mid
  else:hi=mid
 return points((lo+hi)/2)

def install(m):
 k=m.k;P=m.PART;G=m.GROUP;ports={};routes=[];internal=[];mount_start=len(m.MOUNTS)
 k.MATS.update(air=dict(color='#187dff',metal=.04,rough=.4,density=1150),drain=dict(color='#f59435',metal=.1,rough=.4,density=1150),water=dict(color='#00bfc5',metal=.08,rough=.3,density=1150),wire=dict(color='#dca6ff',metal=0,rough=.5,density=1150))
 old=k.shape_for
 def shape(t,d):
  if t=='air_knife_shell':
   side=d[0];s=cq.Workplane('XY').box(.018,.24,.015).val().cut(cq.Workplane('XY').box(.014,.236,.011).val())
   s=s.cut(cq.Workplane('XY').box(.0015,.20,.008).val().translate((0,0,-side*.006)))
   return s.cut(cq.Solid.makeCylinder(.004,.006,cq.Vector(0,.117,0),cq.Vector(0,1,0)))
  if t=='wash_pipe_hollow':
   x,z=d;s=m.axis_cylinder([x,.20,z],[x,.53,z],.009).cut(m.axis_cylinder([x,.199,z],[x,.531,z],.006))
   for y in [.20,.33,.46]:s=s.cut(m.axis_cylinder([x,y,z],[x,y,z-math.copysign(.02,z)],.002))
   return s
  if t=='peel_manifold_hollow':
   ri,ro,h,start,angle=d;s=old('ring',d).cut(old('ring',[ri+.0015,ro-.0015,h-.003,start+3,angle-6]))
   for j in range(4):
    a=math.radians(start+(j+.5)*45);v=np.array([math.cos(a),0,math.sin(a)])
    s=s.cut(m.axis_cylinder(v*.055+np.array([0,.001,0]),v*.039+np.array([0,-.004,0]),.001))
   s=s.cut(m.axis_cylinder([0,0,math.copysign(.055,1 if start==0 else -1)],[0,0,math.copysign(.047,1 if start==0 else -1)],.003))
   # A half millimetre split between the two closing faces.
   s=s.cut(cq.Workplane('XY').box(.13,.025,.0005).val())
   return s
  if t!='service_tube':return old(t,d)
  key=json.dumps([t,d])
  if key in k.CQ_CACHE:return k.CQ_CACHE[key]
  pts,ro,ri=d[:3];vs=[cq.Vector(*p) for p in pts]
  # The sampled neutral line is quadratic: a three-control-point Bezier is exact
  # and avoids a high-degree interpolation curve with dozens of CAD knots.
  if len(d)>3:
   edges=[]
   for seg in d[3]:
    v=[cq.Vector(*p) for p in seg[1:]]
    edges.append(cq.Edge.makeLine(*v) if seg[0]=='L' else cq.Edge.makeThreePointArc(*v))
   path=cq.Wire.assembleEdges(edges)
  else:
   control=vs[len(vs)//2]*2-(vs[0]+vs[-1])*.5
   edge=cq.Edge.makeLine(vs[0],vs[-1]) if (control-(vs[0]+vs[-1])*.5).Length<1e-8 else cq.Edge.makeBezier([vs[0],control,vs[-1]])
   path=cq.Wire.assembleEdges([edge])
  tangent=vs[1]-vs[0];plane=cq.Plane(vs[0],normal=tangent)
  s=cq.Workplane(plane).circle(ro).circle(ri).sweep(path,isFrenet=True).val()
  if not s.isValid():raise ValueError('Invalid service tube')
  k.CQ_CACHE[key]=s;return s
 k.shape_for=shape
 def part(n):return next(p for p in P if p['name']==n)
 def ref(parent,point):return dict(parent=parent,point=list(point))
 def world(r):return (k.GM[r['parent']]@np.r_[r['point'],1])[:3]
 def port(n,parent,point,body,medium='air',normal=(0,1,0),radius=.004,existing=False):
  point=np.array(point,float);v=np.array(normal,float);v/=np.linalg.norm(v)
  if not existing:m.ring('fit_'+n,point-v*.020,point,radius+.0025,max(.001,radius-.001),parent,'chrome',body)
  ports[n]=dict(name=n,**ref(parent,point),body=body,medium=medium)
  return n
 def tie(*ns):internal.append(list(ns))
 def route(n,a,b,medium='air',ro=.004,extra=.07,normal=(0,1,0),basis='fixed',length=None):
  ident='hose_'+n
  ancestors=[];par=ports[a]['parent']
  while par:
   ancestors.append(par);par=next(g['parent'] for g in G if g['name']==par)
  par=ports[b]['parent']
  while par not in ancestors:par=next(g['parent'] for g in G if g['name']==par)
  par='service_routes' if par=='fixed' else par
  if basis=='fixed' and par!='service_routes':basis=par
  A,B=world(ports[a]),world(ports[b]);N=k.GM[basis][:3,:3]@normal
  L=length or float(np.linalg.norm(B-A)+extra)
  pts=loop_points(A,B,N,L)
  local=(np.c_[pts,np.ones(len(pts))]@np.linalg.inv(k.GM[par]).T)[:,:3] if par in k.GM else pts
  m.p(ident,'service_tube',[local.tolist(),ro,ro*.70],parent=par,mat=medium,join='flexible_route')
  routes.append(dict(name=n,node=ident,start=a,end=b,medium=medium,outer_radius=ro,inner_radius=ro*.70,length_m=L,normal=list(normal),basis=basis,samples=33))
  return n
 def body(n,parent,at,ds,support,mat='air'):
  return m.box(n,ds,at,parent,mat,support)
 def equip_port(n,bd,parent,at,medium='air',normal=(0,1,0),radius=.004):return port(n,parent,at,bd,medium,normal,radius)
 # Remove obsolete sealed decorative risers. The ring becomes real hollow pipe.
 obsolete={p['name'] for p in P if p['name'].startswith('air_riser_')}
 P[:]=[p for p in P if p['name'] not in obsolete]
 m.MOUNTS[:]=[x for x in m.MOUNTS if x['part'] not in obsolete]
 for p in P:
  if p['name'].startswith(('air_fixed_run_','air_ring_link_')):
   p['kind']='axisring';p['dims'].append(.006);p['mat']='air'
  if p['name'].startswith('wash_nozzle_'):
   p['kind']='axisring';p['dims'].append(.002);p['dims'][0][2]-=math.copysign(.008,p['dims'][0][2])
  if p['name'].startswith('wash_manifold_'):p['kind']='wash_pipe_hollow';p['dims']=[p['dims'][0][0],p['dims'][0][2]]
  if p['name'].startswith('air_knife_inlet_'):p['kind']='axisring';p['dims'].append(.004)
  elif p['name'].startswith('air_knife_'):p['kind']='air_knife_shell';p['dims']=[math.copysign(1,p['pos'][2])]
  if p['name'].startswith('peel_manifold_'):p['kind']='peel_manifold_hollow'
 m.g('service_routes','fixed',label='气、水、排水与柔性管段')
 m.apply_home()
 # Plant connection and lockable dump valve mounted on the utility panel.
 body('air_inlet_bracket','utilities',(.40,1.05,-.12),(.20,.020,.045),'utility_backplate','steel')
 body('air_lockout_dump','utilities',(.42,1.085,-.12),(.050,.050,.050),'air_inlet_bracket')
 m.box('air_lockout_handle',(.065,.012,.018),(.42,1.116,-.12),'utilities','red','air_lockout_dump')
 equip_port('AIR_IN','air_lockout_dump','utilities',(.455,1.085,-.12),normal=(1,0,0),radius=.008)
 equip_port('A_AFTER_DUMP','air_lockout_dump','utilities',(.39,1.085,-.12),normal=(-1,0,0),radius=.008)
 equip_port('A_FILTER_IN','FRL_manifold','utilities',(.30,1.05,-.105),normal=(1,0,0),radius=.008)
 equip_port('A_FILTER_OUT','FRL_manifold','utilities',(.19,1.05,.105),normal=(-1,0,0),radius=.008)
 tie('AIR_IN','A_AFTER_DUMP');tie('A_FILTER_IN','A_FILTER_OUT')
 route('dump_to_filter','A_AFTER_DUMP','A_FILTER_IN',ro=.008,extra=.001)
 m.box('process_filter_standoff',(.048,.08,.06),(.3135,.82,.14),'utilities','steel','utility_backplate')
 body('clean_process_filter','utilities',(.24,.82,.14),(.10,.13,.09),'process_filter_standoff')
 equip_port('A_PROCESS_IN','clean_process_filter','utilities',(.185,.85,.14),normal=(-1,0,0),radius=.008)
 equip_port('A_PROCESS_OUT','clean_process_filter','utilities',(.185,.79,.14),normal=(-1,0,0),radius=.008)
 tie('A_PROCESS_IN','A_PROCESS_OUT');route('filtered_process_branch','A_FILTER_OUT','A_PROCESS_IN',ro=.008,extra=.07)
 # Existing control ring: explicit topology with station tee ports.
 for i in range(6):
  par='station'+str(i+1)
  port(f'A_RING_{i}',par,(.78,.46,-.20),'air_fixed_run_'+str(i),radius=.008,normal=(-1,0,0),existing=True)
  port(f'A_STATION_{i}',par,(1.30,.46,-.20),'air_fixed_run_'+str(i),radius=.008,normal=(1,0,0),existing=True)
  tie(f'A_RING_{i}',f'A_STATION_{i}',f'A_RING_{(i+1)%6}')
 route('filter_to_control_ring','A_FILTER_OUT','A_STATION_5',ro=.008,extra=.12)
 # Central rotary supply follows an overhead mast then a relaxed flexible connection.
 m.plate('union_mast_cap',(.036,.004,.036),(.80,1.642,0),'fixed',support='union_overhead_mast')
 port('A_UNION_FEED','fixed',(.80,1.64,0),'union_mast_cap',radius=.006)
 port('A_UNION_P','rotary_union',(.075,0,0),'union_fixed_air_in',radius=.006,normal=(1,0,0),existing=True)
 route('ring_to_overhead','A_RING_0','A_UNION_FEED',ro=.006,extra=.22,normal=(0,0,1))
 route('union_flexible_inlet','A_UNION_FEED','A_UNION_P',ro=.006,extra=.14,normal=(0,0,1))
 port('A_ROTOR_P','carousel',(.026,1.47,0),'union_rotor_stub',radius=.006,normal=(1,0,0))
 tie('A_UNION_P','A_ROTOR_P')
 m.ring('union_channel2_blank',[-.054,0,0],[-.066,0,0],.009,.0008,'rotary_union','dark','union_stator')
 # Electrical slip-ring is an explicit custom interface envelope, outside the air channels.
 m.ring('slipring_rotor_extension',[0,1.56,0],[0,1.59,0],.022,.01901,'carousel','steel','union_rotor_stub')
 m.ring('valve_control_slipring',[0,1.575,0],[0,1.615,0],.043,.02201,'carousel','dark','slipring_rotor_extension')
 m.beam('slipring_fixed_restraint',[.048,1.60,0],[.13,1.64,0],.012,'fixed','union_overhead_beam')
 # Valve groups are mounted on the same rigid bodies as their cylinder barrels.
 by_parent={}
 for c in m.CYL:by_parent.setdefault(c['parent'],[]).append(c)
 for ix,(parent,cyls) in enumerate(by_parent.items()):
  base=next((p for p in P if p['parent']==parent and p['name'].endswith('_frame')),None)
  if base:at=np.array([.035,.055,0]);support=base['name']
  elif parent=='root_station':at=np.array([1.20,.511,-.25]);support='root_fixed_plate'
  elif parent=='peel_head':at=np.array([-.28,.079,.22]);support='peel_head_cross'
  elif parent=='weigh_axis_slide':at=np.array([.065,.102,.075]);support='weigh_axis_carriage'
  else:
   support=next((p['name'] for p in P if p['parent']==parent and p['name'].endswith('_carriage')),cyls[0]['name']+'_barrel')
   sp=part(support);at=np.array(sp['pos'])+np.array([0,.025,0])
  bd=body('valve_bank_'+parent,parent,at,(.050,.040,max(.040,.028*len(cyls))),support)
  src='A_ROTOR_P' if parent.startswith('grip_') else 'A_STATION_'+str(0 if parent.startswith(('loader','root','trim')) else 1 if parent=='peel_head' else 3 if parent.startswith('weigh') else 4)
  port('V_P_'+parent,parent,at+[.029,0,0],bd,normal=(1,0,0),radius=.004)
  route('supply_'+parent,src,'V_P_'+parent,ro=.004,extra=(.025 if parent=='root_station' else .20 if not parent.startswith('grip_') else .06),normal=(0,-1 if parent.startswith('grip_') else 1,0),length=(1.15 if parent=='peel_head' else 1.8 if parent=='trim_axis_slide' else 1.35 if parent.startswith(('loader_','unload_')) else None))
  # Local exhaust means no cumulative backpressure through the rotary union.
  m.ring('silencer_'+parent,at+[0,.02,0],at+[0,.045,0],.008,.004,parent,'orange',bd)
  if 'grip' in parent:
   body('reg_015MPa_'+parent,parent,at+[-.034,0,0],(.018,.032,.028),bd,'dark')
   # 0.5 MPa external pilot; 0.15 MPa main circuit after local regulation.
   px=port('V_X_'+parent,parent,at+[.029,-.012,.014],bd,normal=(1,0,0),radius=.002)
   tie('V_P_'+parent,px)
   route('external_pilot_'+parent,'V_P_'+parent,px,ro=.002,extra=.001,normal=(1,0,0),basis=parent)
  for ci,c in enumerate(cyls):
   for j in [0,1]:
    q=part(c['name']+'_port_'+str(j));end=np.array(q['dims'][1]);u=end-np.array(q['dims'][0]);u/=np.linalg.norm(u)
    dest=port(c['name']+'_C'+str(j),parent,end,q['name'],normal=u,radius=.003,existing=True)
    start=port(c['name']+'_V'+str(j),parent,at+[-.012+j*.024,.022,(ci-(len(cyls)-1)/2)*.025],bd,radius=.003)
    tie('V_P_'+parent,start)
    route('cylinder_'+c['name']+'_'+str(j),start,dest,ro=.003,extra=.055,normal=(1,1,0),basis=parent)
 # Stationary, non-lubricated high-flow process-air branch: peeling and air knives.
 m.beam('peel_fixed_pipe_stand',[1.20,.43,.22],[1.20,.79,.22],.025,'station2','frame_1_0.22')
 port('A_PEEL_FIXED','station2',(1.20,.78,.22),'peel_fixed_pipe_stand',radius=.008)
 port('A_PEEL_HEAD','peel_head',(-.30,.075,-.22),'peel_head_cross_back',radius=.008)
 route('peel_two_axis_loop','A_PEEL_FIXED','A_PEEL_HEAD',ro=.006,length=.95,normal=(0,0,1))
 for l,x in enumerate([-.628,-.488]):
  for s in [-1,1]:
   dest=port(f'PEEL_{l}_{s}',f'nozzle_{l}_{s}',[x,0,s*.052],f'peel_manifold_{l}_{s}',normal=(0,0,s),radius=.004)
   route(f'peel_half_{l}_{s}','A_PEEL_HEAD',dest,ro=.004,extra=.22,normal=(0,.5,s),basis='peel_head')
 for z in [-.22,.22]:m.beam('wash_fixed_pipe_stand_'+str(z),[1.20,.43,z],[1.20,.79,z],.025,'station3','frame_2_'+str(z))
 port('A_KNIFE_FIXED','station3',(1.20,.78,-.22),'wash_fixed_pipe_stand_-0.22',radius=.008)
 m.beam('wash_air_header_cross',[-.16,.692,.14],[-.16,.692,-.14],.020,'wash_axis_slide','wash_head_arm_-0.51')
 port('A_KNIFE_HEAD','wash_axis_slide',(-.16,.72,-.14),'wash_air_header_cross',radius=.008)
 route('airknife_moving_loop','A_KNIFE_FIXED','A_KNIFE_HEAD',ro=.008,length=.85,normal=(0,0,-1))
 for x in [-.51,-.37]:
  for z in [-.04,.04]:
   dest=port(f'KNIFE_{x}_{z}','wash_axis_slide',[x,.692,z],'air_knife_inlet_'+str(x)+'_'+str(z),radius=.004)
   route(f'airknife_{x}_{z}','A_KNIFE_HEAD',dest,ro=.004,extra=.05,normal=(0,1,0),basis='wash_axis_slide')
 # Clean-water skid, mounted beside the clean tank. Air-gap fill and low-level switch.
 m.plate('water_pump_skid',(.26,.035,.30),(.19,.08,.52),'utilities',support='tank_skid')
 body('water_pump_motor','utilities',(.19,.1675,.54),(.12,.14,.16),'water_pump_skid','dark')
 m.ring('water_pump_volute',[.19,.17,.47],[.19,.17,.40],.064,.014,'utilities','water','water_pump_motor')
 m.beam('water_strainer_bracket',[.12,.0975,.43],[.12,.18,.32],.018,'utilities','water_pump_skid')
 body('water_strainer','utilities',(.12,.18,.32),(.06,.09,.06),'water_strainer_bracket','water')
 m.rod('tank_low_level_switch',[-.14,.16,.722],[-.14,.16,.735],.016,'utilities','dark','water_tank')
 m.rod('tank_level_probe',[-.14,.16,.69],[-.14,.16,.735],.006,'utilities','chrome','water_tank')
 m.beam('water_valve_panel',[.32,.0975,.40],[.32,.70,.40],.030,'utilities','water_pump_skid')
 body('water_valve_train','utilities',(.28,.62,.40),(.10,.12,.12),'water_valve_panel','water')
 # Discrete serviceable items, rather than one anonymous valve box.
 m.ring('water_suction_isolator',[.12,.18,.35],[.12,.18,.40],.023,.012,'utilities','water','water_strainer')
 m.box('water_isolator_handle',(.050,.010,.014),(.12,.207,.375),'utilities','red','water_suction_isolator')
 m.beam('water_train_brace',[.20,.38,.40],[.32,.38,.40],.018,'utilities','water_valve_panel')
 m.ring('water_check_valve',[.20,.35,.40],[.20,.41,.40],.023,.010,'utilities','water','water_train_brace')
 m.beam('water_gauge_bracket',[.32,.46,.40],[.20,.46,.40],.015,'utilities','water_valve_panel')
 m.rod('water_pressure_gauge',[.20,.46,.38],[.20,.46,.36],.027,'utilities','white','water_gauge_tap')
 m.ring('water_pressure_tee',[.20,.41,.40],[.20,.49,.40],.014,.010,'utilities','water','water_gauge_bracket')
 m.ring('water_gauge_tap',[.20,.46,.40],[.20,.46,.38],.008,.004,'utilities','water','water_pressure_tee')
 m.box('water_flow_sensor',(.075,.060,.045),(.25,.56,.40),'utilities','dark','water_valve_train')
 m.box('water_NC_solenoid',(.060,.045,.060),(.25,.69,.40),'utilities','dark','water_valve_train')
 m.ring('tank_cover',[-.14,.480,.52],[-.14,.484,.52],.210,.045,'utilities','steel','water_tank')
 m.ring('tank_vent',[-.29,.484,.52],[-.29,.519,.52],.011,.007,'utilities','steel','tank_cover')
 m.ring('clean_bypass_adjuster',[.04,.35,.61],[.04,.41,.61],.014,.006,'utilities','water','water_tank')
 equip_port('W_FILL','hose_potable_water_fill','utilities',(-.14,.56,.52),'water',radius=.010)
 equip_port('W_TANK_OUT','water_tank','utilities',(.07,.145,.52),'water',normal=(1,0,0),radius=.012)
 equip_port('W_STRAIN_IN','water_strainer','utilities',(.12,.18,.35),'water',normal=(0,0,1),radius=.012)
 equip_port('W_STRAIN_OUT','water_strainer','utilities',(.12,.18,.29),'water',normal=(0,0,-1),radius=.012)
 equip_port('W_PUMP_IN','water_pump_volute','utilities',(.19,.17,.40),'water',normal=(0,0,-1),radius=.012)
 equip_port('W_PUMP_OUT','water_pump_volute','utilities',(.19,.24,.42),'water',radius=.010)
 equip_port('W_SUCTION_IN','water_suction_isolator','utilities',(.12,.18,.40),'water',normal=(0,0,1),radius=.012)
 equip_port('W_CHECK_IN','water_check_valve','utilities',(.20,.35,.40),'water',normal=(0,-1,0),radius=.010)
 equip_port('W_CHECK_OUT','water_check_valve','utilities',(.20,.41,.40),'water',radius=.010)
 equip_port('W_PRESSURE_OUT','water_pressure_tee','utilities',(.20,.49,.40),'water',radius=.010)
 equip_port('W_FLOW_IN','water_flow_sensor','utilities',(.25,.53,.40),'water',normal=(0,-1,0),radius=.010)
 equip_port('W_FLOW_OUT','water_flow_sensor','utilities',(.25,.59,.40),'water',radius=.010)
 equip_port('W_VALVE_IN','water_NC_solenoid','utilities',(.25,.6675,.40),'water',normal=(0,-1,0),radius=.010)
 equip_port('W_VALVE_OUT','water_NC_solenoid','utilities',(.25,.7125,.40),'water',radius=.010)
 equip_port('W_BYPASS_IN','clean_bypass_adjuster','utilities',(.04,.35,.61),'water',normal=(0,-1,0),radius=.006)
 equip_port('W_BYPASS_OUT','clean_bypass_adjuster','utilities',(.04,.41,.61),'water',radius=.006)
 equip_port('W_RETURN','water_tank','utilities',(.04,.43,.61),'water',normal=(1,0,0),radius=.006)
 equip_port('W_FIXED','wash_fixed_pipe_stand_0.22','station3',(1.20,.78,.22),'water',radius=.010)
 equip_port('W_HEAD','wash_head_arm_-0.37','wash_axis_slide',(-.16,.72,.14),'water',radius=.008)
 tie('W_TANK_OUT','W_FILL','W_RETURN');tie('W_SUCTION_IN','W_STRAIN_IN','W_STRAIN_OUT');tie('W_PUMP_IN','W_PUMP_OUT');tie('W_CHECK_IN','W_CHECK_OUT','W_PRESSURE_OUT');tie('W_FLOW_IN','W_FLOW_OUT');tie('W_VALVE_IN','W_VALVE_OUT');tie('W_BYPASS_IN','W_BYPASS_OUT')
 for n,a,b,ro,ex in [('tank_suction','W_TANK_OUT','W_SUCTION_IN',.012,.005),('strainer_to_pump','W_STRAIN_OUT','W_PUMP_IN',.012,.005),('pump_to_check','W_PUMP_OUT','W_CHECK_IN',.010,.001),('pressure_to_flow','W_PRESSURE_OUT','W_FLOW_IN',.010,.0001),('flow_to_valve','W_FLOW_OUT','W_VALVE_IN',.010,.0001),('clean_min_flow_bypass','W_PUMP_OUT','W_BYPASS_IN',.006,.03),('bypass_return','W_BYPASS_OUT','W_RETURN',.006,.00001)]:route(n,a,b,'water',ro,ex,normal=(0,0,1))
 route('water_moving_loop','W_FIXED','W_HEAD','water',.008,length=.850,normal=(0,0,1))
 for x in [-.51,-.37]:
  for z in [-.065,.065]:
   dest=port(f'W_MANIFOLD_{x}_{z}','wash_axis_slide',[x,.70,z],'wash_manifold_'+str(x)+'_'+str(z),'water',radius=.006)
   route(f'water_header_{x}_{z}','W_HEAD',dest,'water',.006,.06,basis='wash_axis_slide')
 # Fill pipe ends above tank rim: air gap is deliberate, not an unconnected machine part.
 m.beam('water_fill_post',[-.38,.10,.52],[-.38,.68,.52],.020,'utilities','tank_skid')
 port('W_SITE_IN','utilities',[-.38,.68,.52],'water_fill_post','water',radius=.010,normal=(-1,0,0))
 route('potable_water_fill','W_SITE_IN','W_FILL','water',.010,.08,normal=(0,1,0),basis='utilities')
 # Tray has fall towards a real bored outlet. DN32 drain drops, never returns to clean tank.
 tray=part('wash_tray');tray['kind']='sloped_tray';tray['dims']=[.56,.54,.006,.024,.22,.16,.018];tray['pos'][1]=.509;tray['mat']='steel'
 for x in [.15,.71]:m.box('wash_tray_rim_x_'+str(x),(.004,.04,.54),(x,.549,0),'station3','steel','wash_tray')
 for z in [-.27,.27]:m.box('wash_tray_rim_z_'+str(z),(.56,.04,.004),(.43,.549,z),'station3','steel','wash_tray')
 for side in [-1,1]:
  pedestal=m.box('flap_supported_pedestal_'+str(side),(.08,.022,.08),(.70,.525,side*.26),'station3','steel','tray_stand_0.66_'+str(side*.23))
  m.set_support('flap_hinge_base_'+str(side),pedestal)
 m.plate('drain_removable_strainer',(.062,.004,.062),(.65,.511,.16),'station3',holes=[[x,z,.0025] for x in [-.022,-.011,0,.011,.022] for z in [-.022,-.011,0,.011,.022]],support='wash_tray')
 port('D_TRAY','station3',[.65,.506,.16],'wash_tray','drain',normal=(0,-1,0),radius=.018)
 m.beam('drain_lower_support',[.65,.43,.22],[.65,.15,.16],.025,'station3','frame_2_0.22')
 m.foot('waste_out_anchor',1.62,.16,'station3',top=.08)
 port('D_FLOOR','station3',[.65,.15,.16],'drain_lower_support','drain',normal=(0,-1,0),radius=.018)
 port('D_SITE_OUT','station3',[1.62,.06,.16],'waste_out_anchor_M20','drain',normal=(1,0,0),radius=.018)
 route('tray_downpipe','D_TRAY','D_FLOOR','drain',.018,.015,normal=(1,0,0),basis='station3')
 # Monotonically descending quadratic centreline, sized DN32 nominal bore.
 a,b=world(ports['D_FLOOR']),world(ports['D_SITE_OUT']);pts=np.linspace(a,b,17)
 m.p('hose_waste_to_site','service_tube',[pts.tolist(),.018,.016],parent='service_routes',mat='drain',join='gravity_drain')
 routes.append(dict(name='waste_to_site',node='hose_waste_to_site',start='D_FLOOR',end='D_SITE_OUT',medium='drain',outer_radius=.018,inner_radius=.016,length_m=float(np.linalg.norm(b-a)),normal=[1,0,0],basis='station3',samples=33,straight=True))
 tie('D_FLOOR','D_TRAY')
 # Fixed mains stay below the working envelope and are carried by the frame.
 # This is separate from the 0.5MPa actuator ring at Y=0.46.
 for i in range(6):
  par='station'+str(i+1)
  m.beam('process_pipe_hanger_'+str(i),[.78,.43,-.22],[.78,.32,-.20],.014,par,'frame_'+str(i)+'_-0.22')
  port('P_MAIN_'+str(i),par,[.78,.32,-.20],'process_pipe_hanger_'+str(i),radius=.008)
 for i in range(6):
  a,b=world(ports['P_MAIN_'+str(i)]),world(ports['P_MAIN_'+str((i+1)%6)])
  m.ring('process_air_main_'+str(i),a,b,.008,.006,'services','air','process_pipe_hanger_'+str(i))
  tie('P_MAIN_'+str(i),'P_MAIN_'+str((i+1)%6))
 route('filtered_process_to_underframe','A_PROCESS_OUT','P_MAIN_5',ro=.008,extra=.02)
 route('peel_fixed_riser','P_MAIN_1','A_PEEL_FIXED',ro=.008,extra=.01,basis='station2')
 route('airknife_fixed_riser','P_MAIN_2','A_KNIFE_FIXED',ro=.008,extra=.01,basis='station3')
 for i in [5,0,1,2]:
  par='station'+str(i+1)
  m.beam('water_pipe_hanger_'+str(i),[.78,.43,.22],[.78,.25,.20],.014,par,'frame_'+str(i)+'_0.22')
  port('W_MAIN_'+str(i),par,[.78,.25,.20],'water_pipe_hanger_'+str(i),'water',radius=.010)
 for i,j in [(5,0),(0,1),(1,2)]:
  a,b=world(ports['W_MAIN_'+str(i)]),world(ports['W_MAIN_'+str(j)])
  m.ring('clean_water_main_'+str(i),a,b,.010,.008,'services','water','water_pipe_hanger_'+str(i))
  tie('W_MAIN_'+str(i),'W_MAIN_'+str(j))
 route('clean_water_to_underframe','W_VALVE_OUT','W_MAIN_5','water',.010,.01)
 route('wash_fixed_water_riser','W_MAIN_2','W_FIXED','water',.010,.01,basis='station3')
 # Ports are mechanically attached to existing bodies. Hoses are supported at both fittings.
 for rt in routes:
  pa=ports[rt['start']];p=part(rt['node']);p['support']=pa['body'];p['connection']='两端接头约束 / 柔性管段' if not rt.get('straight') else '重力排水 / 连续坡降'
  p['medium']=rt['medium']
 m.apply_home()
 result=dict(ports=ports,routes=routes,internal_connections=internal,design=dict(air_in_MPa=.6,actuator_MPa=.5,grip_MPa=.15,rotary_channels='C1: P供气；C2:封堵备用。阀组本地消声排气；低压夹具外先导来自0.5MPa。',water_tank_litre=round(math.pi*.205**2*(.38-.004)*1000,1),water='清水空气间隙补水；低液位停泵；过滤、泵、止回、压力/流量、常闭阀；清洁侧最小流量回水。污水不回用。',limits='名义管径与阀体包络；软管按定长中性线变形，尚未进行管间自碰撞/压力损失/流量选型。'))
 from routing07 import install as refine_routes
 return refine_routes(m,result)
