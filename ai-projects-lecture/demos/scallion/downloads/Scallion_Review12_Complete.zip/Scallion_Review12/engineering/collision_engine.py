"""Motion-aware mesh broadphase. A contact is a candidate, not CAD penetration depth.
FCL BVH models are surfaces. Confirm suspect solids with OpenCascade separately.
"""
import os,sys,json,hashlib,time,math,tempfile,inspect,gc
from pathlib import Path
import numpy as np
if os.environ.get('SCALLION_EXTRA_DEPS'):sys.path.insert(0,os.environ['SCALLION_EXTRA_DEPS'])
import fcl
import machine as m
from infeed12 import install as infeed12
from refine12 import install as refine12
infeed12(m)
refine12(m)
from scipy.spatial.transform import Rotation

CACHE=Path(os.environ.get('SCALLION_MESH_CACHE',str(m.ROOT/'engineering/.mesh_cache')));CACHE.mkdir(parents=True,exist_ok=True)
G={g['name']:g for g in m.GROUP};J={j['child']:j for j in m.JOINTS}
def ancestry(n):
 out=[]
 while n:out.append(n);n=G[n]['parent']
 return out
def signature(p):return tuple(n for n in ancestry(p['parent']) if n in J)
def world(q):
 out={}
 for g in m.GROUP:
  ob=dict(g);j=J.get(g['name']);R=np.eye(4)
  if j:
   value=q.get(j['name'],j.get('home',0))
   if j['type']=='prismatic':ob['pos']=(np.array(j.get('offset',[0,0,0]))+np.array(j['axis'])*value).tolist()
   else:R[:3,:3]=Rotation.from_rotvec(np.array(j['axis'])*value).as_matrix()
  out[g['name']]=(out[g['parent']] if g['parent'] else np.eye(4))@m.k.mat4(ob)@R
 return out
def shape_code(fn,seen=None):
 seen=set() if seen is None else seen
 if id(fn) in seen:return ''
 seen.add(id(fn))
 try:s=inspect.getsource(fn)
 except (TypeError,OSError):s=str(type(fn))
 for cell in getattr(fn,'__closure__',None) or []:
  try:
   value=cell.cell_contents
   if callable(value):s+=shape_code(value,seen)
  except ValueError:pass
 return s
SHAPE_HASH=hashlib.sha256((shape_code(m.k.shape_for)+inspect.getsource(m.axis_cylinder)).encode()).hexdigest()
def mesh(p):
 key=hashlib.sha256(json.dumps([SHAPE_HASH,p['kind'],p['dims']]).encode()).hexdigest();path=CACHE/(key+'.npz')
 if path.exists():
  try:
   with np.load(path) as a:return key,a['v'],a['t']
  except (EOFError,ValueError,OSError):pass
 s=m.k.shape_for(p['kind'],p['dims']);vs,ts=s.tessellate(.00020,.18)
 v=np.array([q.toTuple() for q in vs],dtype=np.float64);t=np.array(ts,dtype=np.int32)
 with tempfile.NamedTemporaryFile(dir=CACHE,suffix='.npz',delete=False) as tmp:tmpname=tmp.name
 np.savez_compressed(tmpname,v=v,t=t);os.replace(tmpname,path);return key,v,t
def tkey(M):return tuple(np.asarray(M[:3,:]).reshape(-1).round(8))

class Engine:
 def __init__(self):
  self.parts=[p for p in m.PART if p['cad'] and p['kind']!='service_tube'];self.by={p['name']:p for p in self.parts}
  self.allowed={frozenset((r['part'],r['support'])) for r in m.MOUNTS}
  self.allowed|={frozenset((r['a'],r['b'])) for r in m.CONTACTS}
  self.sigs={p['name']:signature(p) for p in self.parts};self.geoms={};self.geokeys={};self.objs={};self.pgeom={};self.bounds={};self.local={p['name']:m.k.mat4(p) for p in self.parts}
  for i,p in enumerate(self.parts):
   key,v,t=mesh(p)
   if key not in self.geoms:
    geom=fcl.BVHModel();geom.beginModel(len(v),len(t));geom.addSubModel(v,t);geom.endModel();self.geoms[key]=geom;self.geokeys[id(geom)]=key
   self.bounds[p['name']]=(v.min(axis=0),v.max(axis=0));self.pgeom[p['name']]=key;self.objs[p['name']]=fcl.CollisionObject(self.geoms[key])
   if i%400==0:print('geometry',i,flush=True)
  m.k.CQ_CACHE.clear();gc.collect()
  self.manager=fcl.DynamicAABBTreeCollisionManager();self.manager.registerObjects(list(self.objs.values()));self.manager.setup();self.req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True)
 def pose(self,q):
  w=world(q);self.transforms={};self.geo_world={};self.world_sigs={}
  for p in self.parts:
   n=p['name'];M=w[p['parent']]@self.local[n];self.transforms[n]=M;tk=tkey(M)
   self.geo_world.setdefault((self.pgeom[n],tk),[]).append(n);self.world_sigs.setdefault(tk,set()).add(self.sigs[n])
   self.objs[n].setTransform(fcl.Transform(M[:3,:3],M[:3,3]))
  self.manager.update()
 def contacts_full_reference(self):
  found=set();calls=0
  selected=set(os.environ.get('PARTS','').split(','))-{''}
  names=[p['name'] for p in self.parts];lows=[];highs=[]
  for n in names:
   lo,hi=self.bounds[n];M=self.transforms[n];c=M[:3,:3]@((lo+hi)/2)+M[:3,3];r=np.abs(M[:3,:3])@((hi-lo)/2)
   lows.append(c-r);highs.append(c+r)
  lows=np.array(lows);highs=np.array(highs)
  for i,n in enumerate(names):
   jxs=np.flatnonzero(np.all(lows[i]<=highs[i+1:]+1e-7,axis=1)&np.all(highs[i]>=lows[i+1:]-1e-7,axis=1))+i+1
   for j in jxs:
    other=names[j]
    if selected and n not in selected and other not in selected:continue
    if self.sigs[n]==self.sigs[other] or frozenset((n,other)) in self.allowed:continue
    res=fcl.CollisionResult();calls+=1;fcl.collide(self.objs[n],self.objs[other],self.req,res)
    if res.is_collision:found.add(tuple(sorted((n,other))))
  return found,calls

 def contacts(self):
  # Identical rigid transforms preserve contacts; recompute every pair involving
  # a moved body. This is equivalent to the all-pairs method, not a pair filter.
  current={n:tkey(M) for n,M in self.transforms.items()}
  previous=getattr(self,'previous_transforms',{})
  changed={n for n in current if current[n]!=previous.get(n)}
  found={p for p in getattr(self,'previous_pairs',set()) if not changed.intersection(p)};calls=0
  selected=set(os.environ.get('PARTS','').split(','))-{''}
  names=list(self.objs);lows=[];highs=[]
  for n in names:
   lo,hi=self.bounds[n];M=self.transforms[n];c=M[:3,:3]@((lo+hi)/2)+M[:3,3];r=np.abs(M[:3,:3])@((hi-lo)/2)
   lows.append(c-r);highs.append(c+r)
  lows=np.array(lows);highs=np.array(highs)
  for i,n in enumerate(names):
   if n in changed:
    js=np.flatnonzero(np.all(lows[i]<=highs+1e-7,axis=1)&np.all(highs[i]>=lows-1e-7,axis=1))
    for j in js:
     other=names[j]
     if other==n or (other in changed and j<i):continue
     if selected and n not in selected and other not in selected:continue
     if self.sigs[n]==self.sigs[other] or frozenset((n,other)) in self.allowed:continue
     res=fcl.CollisionResult();calls+=1;fcl.collide(self.objs[n],self.objs[other],self.req,res)
     if res.is_collision:found.add(tuple(sorted((n,other))))
  self.previous_transforms=current;self.previous_pairs=found.copy()
  return found,calls

if __name__=='__main__':
 root=Path('/workspace/scratch/23396c524f3a/interference07');poses=json.loads((root/'poses.json').read_text());engine=Engine();hits={};calls=0;t0=time.time()
 selected=os.environ.get('PROGRAM');poses=[p for p in poses if not selected or p['program']==selected]
 for i,p in enumerate(poses):
  engine.pose(p['q']);pairs,n=engine.contacts();calls+=n
  for a,b in pairs:
   key=a+'|'+b
   if key not in hits:hits[key]=dict(a=a,b=b,program=p['program'],t=p['t'],q=p['q'],occurrences=0)
   hits[key]['occurrences']+=1
  if i%10==0:print('pose',i,p['program'],'unique candidates',len(hits),'narrow',calls,flush=True)
  if os.environ.get('LIMIT') and i+1>=int(os.environ['LIMIT']):break
 out=dict(poses=i+1,rigid_components=len(engine.parts),narrow_phase_calls=calls,contact_candidates=list(hits.values()),elapsed_s=time.time()-t0,scope='Moving rigid bodies against all other bodies. Same rigid body and explicitly declared mating connections are excluded. Mesh surface contacts require CAD confirmation. Flexible routes are checked separately.')
 (root/os.environ.get('OUTPUT',('rigid_candidates_'+(selected or 'all')+'.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2));print('DONE',out['poses'],'candidate pairs',len(hits),'seconds',round(out['elapsed_s'],2),flush=True)
