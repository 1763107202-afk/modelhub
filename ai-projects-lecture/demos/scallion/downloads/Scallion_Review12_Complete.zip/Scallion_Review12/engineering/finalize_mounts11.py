"""Remove retired links and recheck the four changed blades against supports."""
import os,json,runpy
from pathlib import Path
import machine as m
R=Path(__file__).resolve().parents[1];os.chdir(R);P=R/'dist/downloads/mount_checks.json'
by={p['name']:p for p in m.PART}
assert not [x for x in m.MOUNTS if x['part'] not in by or x['support'] not in by]
active={(x['part'],x['support']) for x in m.MOUNTS if x['type'] in ['rigid','bolted','flange'] and by[x['part']]['cad'] and by[x['support']]['cad']}
previous=json.loads(P.read_text());previous['checks']=[x for x in previous['checks'] if (x['a'],x['b']) in active]
P.write_text(json.dumps(previous,ensure_ascii=False,indent=2))
os.environ['PARTS']='root_blade_1.03,root_blade_1.17,trim_blade_0,trim_blade_1'
runpy.run_path(str(R/'engineering/check_mounts.py'),run_name='__main__')
result=json.loads(P.read_text());checked={(x['a'],x['b']) for x in result['checks']}
assert active==checked,(active-checked,checked-active)
assert not result['gaps_over_0p3mm'] and not result['unknown_supports']
result['active_unique_mount_pairs']=len(active);result['all_active_rigid_mounts_covered']=True
P.write_text(json.dumps(result,ensure_ascii=False,indent=2))
