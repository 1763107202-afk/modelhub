"""Conservative capsule sweep of hose centrelines against all rigid CAD meshes.
Reports candidates without turning surface penetration depth into a solid metric.
"""
import json,sys,time,os
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from collision_engine import Engine,world,fcl
import machine as m
from routing07 import route_points

root=Path('/workspace/scratch/23396c524f3a/interference07');e=Engine();ports=m.SERVICES['ports'];routes=m.SERVICES['routes'];names=list(e.objs);hits={};calls=0;t0=time.time()
poses=json.loads((root/'poses.json').read_text());limit=int(os.environ.get('LIMIT','1'));poses=poses[:limit]
req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True)
for pi,state in enumerate(poses):
 e.pose(state['q']);W=world(state['q']);lo=[];hi=[]
 for n in names:
  a,b=e.bounds[n];M=e.transforms[n];c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2);lo.append(c-r);hi.append(c+r)
 lo=np.array(lo);hi=np.array(hi)
 for rt in routes:
  ps=route_points(rt,ports,W);ro=rt['outer_radius'];ignored={ports[n]['body'] for n in [rt['start'],rt['end']]}|{'fit_'+rt['start'],'fit_'+rt['end']}
  for si,(a,b) in enumerate(zip(ps,ps[1:])):
   d=b-a;L=float(np.linalg.norm(d))
   if L<1e-8:continue
   low=np.minimum(a,b)-ro;high=np.maximum(a,b)+ro;candidates=np.flatnonzero(np.all(low<=hi,axis=1)&np.all(high>=lo,axis=1))
   u=d/L;v=np.cross([0,0,1],u);c=np.dot([0,0,1],u)
   R=np.eye(3) if c>.999999 else Rotation.from_rotvec(v/np.linalg.norm(v)*np.arccos(np.clip(c,-1,1))).as_matrix() if c>-.999999 else np.diag([1,-1,-1])
   cap=fcl.CollisionObject(fcl.Capsule(ro,L),fcl.Transform(R,(a+b)/2))
   for j in candidates:
    n=names[j]
    if n in ignored:continue
    key=rt['name']+'|'+n
    if key in hits:continue
    res=fcl.CollisionResult();fcl.collide(cap,e.objs[n],req,res);calls+=1
    if res.is_collision:hits[key]=dict(route=rt['name'],solid=n,program=state['program'],t=state['t'],segment=si,q=state['q'])
 print('pose',pi,'route/rigid candidates',len(hits),'narrow',calls,flush=True)
out=dict(poses=len(poses),routes=len(routes),rigid_bodies=len(names),capsule_contacts=list(hits.values()),narrow_phase_calls=calls,elapsed_s=time.time()-t0,scope='Capsules cover each sampled hose chord including outer radius; fitting/end-body attachment is excluded. This is a candidate screen, not a supplier fatigue or continuous clearance certificate.')
(root/'flexible_candidates.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('DONE',len(hits),flush=True)
