"""Recheck the modified mount families after the full revision-11 mount screen."""
import os,json,runpy
from pathlib import Path
import machine as m
root=Path(__file__).resolve().parents[1];os.chdir(root)
previous=json.loads((root/'dist/downloads/mount_checks.json').read_text())
by={p['name']:p for p in m.PART}
active={(x['part'],x['support']) for x in m.MOUNTS if x['type'] in ['rigid','bolted','flange'] and x['part'] in by and x['support'] in by and by[x['part']]['cad'] and by[x['support']]['cad']}
previous['checks']=[x for x in previous['checks'] if (x['a'],x['b']) in active]
(root/'dist/downloads/mount_checks.json').write_text(json.dumps(previous,ensure_ascii=False,indent=2))
prefixes=('wrap','seal','counter','film_','slipring','valve_control','base_panel')
selected={p['name'] for p in m.PART if p['name'].startswith(prefixes)}
done={(x['a'],x['b']) for x in previous['checks']}
for a,b in active-done:selected.update([a,b])
for r in previous['gaps_over_0p3mm']:selected.update([r['a'],r['b']])
print('Rechecking modified mount families:',len(selected),flush=True)
os.environ['PARTS']=','.join(sorted(selected))
runpy.run_path(str(root/'engineering/check_mounts.py'),run_name='__main__')
