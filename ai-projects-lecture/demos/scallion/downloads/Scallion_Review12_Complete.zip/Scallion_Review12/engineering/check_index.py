import json,math,time
import numpy as np
import cadquery as cq
from pathlib import Path
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.gp import gp_Trsf
def placement(M):
 t=gp_Trsf();t.SetValues(*[float(v) for v in M[:3,:].reshape(-1)]);return cq.Location(t)
import machine as m
k=m.k;groups={g['name']:g for g in m.GROUP}
def under(g,n):
 while g:
  if g==n:return True
  g=groups[g]['parent']
 return False
shapes={};corners={}
for p in m.PART:
 if not p['cad'] or p['kind']=='service_tube':continue
 sh=k.shape_for(p['kind'],p['dims']);shapes[p['name']]=sh;bb=sh.BoundingBox();corners[p['name']]=np.array([[x,y,z,1] for x in [bb.xmin,bb.xmax] for y in [bb.ymin,bb.ymax] for z in [bb.zmin,bb.zmax]])
# Include carrier structure and clamps, excluding central intentional shaft/bearing fits.
moving=[p for p in m.PART if p['cad'] and p['kind']!='service_tube' and any(under(p['parent'],'carrier_'+str(i)) for i in range(6))]
# Fixed source and stage transforms; water flaps latched in their open position.
world={}
for g in m.GROUP:
 gg=dict(g)
 if g['name'].startswith('wash_flap_'):gg['yaw']=int(g['name'].split('_')[-1])*90
 world[g['name']]=(world[g['parent']] if g['parent'] else np.eye(4))@k.mat4(gg)
def bounds(p,M):
 v=corners[p['name']]@M.T;return v[:,:3].min(axis=0),v[:,:3].max(axis=0)
fixed=[];lo=[];hi=[];fm=[]
for p in m.PART:
 if not p['cad'] or p['kind']=='service_tube' or under(p['parent'],'carousel'):continue
 M=world[p['parent']]@k.mat4(p);l,h=bounds(p,M)
 if h[1]<.94 or l[1]>1.50:continue
 fixed.append(p);lo.append(l);hi.append(h);fm.append(M)
lo=np.array(lo);hi=np.array(hi);bad=[];tested=0;start=time.time()
for a in np.linspace(0,-math.pi/3,25):
 ca,sa=math.cos(a),math.sin(a);R=np.array([[ca,0,sa,0],[0,1,0,0],[-sa,0,ca,0],[0,0,0,1]])
 for p in moving:
  M=R@k.GM[p['parent']]@k.mat4(p);l,h=bounds(p,M)
  overlap=np.minimum(h,hi)-np.maximum(l,lo);candidates=np.where(np.all(overlap>.00005,axis=1))[0]
  if len(candidates)==0:continue
  A=shapes[p['name']].moved(placement(M))
  for j in candidates:
   tested+=1;B=shapes[fixed[j]['name']].moved(placement(fm[j]))
   common=BRepAlgoAPI_Common(A.wrapped,B.wrapped);common.Build()
   try:volume=cq.Shape(common.Shape()).Volume() if common.IsDone() else float('nan')
   except StopIteration:volume=0.0
   if volume>1e-10:bad.append({'angle_deg':float(a*180/math.pi),'rotor':p['name'],'fixed':fixed[j]['name'],'overlap_mm3':volume*1e9})
 print('angle',round(a*180/math.pi,2),'candidates',tested,'interferences',len(bad),flush=True)
res={'poses':25,'moving_bodies':len(moving),'fixed_bodies':len(fixed),'exact_volume_pairs':tested,'interferences':bad,'elapsed_s':time.time()-start,'scope':'25 sampled poses of EMPTY 60-degree index with tools fully retracted and wash flaps latched open. Intentional central shaft/bearing fits and flexible service tubes excluded. All added rigid valve and fitting hardware included. Flexible tube collision remains unverified. This is not continuous collision checking or a loaded process-cycle validation.'}
Path('dist/downloads/index_rigid_clearance_06.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False))
