"""Inspect actual web additions/material together with nominal CAD rigid bodies.
FCL intersections are candidates. Does not discard a pair merely for sharing a body.
"""
import os,sys,json,time
from pathlib import Path
import numpy as np
from collision_engine import Engine,world,fcl
src=Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/scratch/23396c524f3a/full-clearance-09.json')
raw=json.loads(src.read_text());engine=Engine();geometries={}
for n,g in raw['geometries'].items():
 v=np.array(g['v'],float).reshape(-1,3);t=np.array(g['t'],np.int32).reshape(-1,3);geom=fcl.BVHModel();geom.beginModel(len(v),len(t));geom.addSubModel(v,t);geom.endModel();geometries[n]=(geom,v.min(0),v.max(0))
req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True);hits={};rigid_hits={};calls=0;names=list(engine.objs);start=time.time();selected=os.environ.get('PHASE')
poses=[p for p in raw['poses'] if not selected or p['phase']==selected]
if os.environ.get('STRIDE'):poses=poses[::int(os.environ['STRIDE'])]
for pi,state in enumerate(poses):
 engine.pose(state['q']);lo=[];hi=[]
 for n in names:
  a,b=engine.bounds[n];M=engine.transforms[n];c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2);lo.append(c-r);hi.append(c+r)
 lo=np.array(lo);hi=np.array(hi)
 if os.environ.get('RIGID'):
  pairs,c=engine.contacts();calls+=c
  for a,b in pairs:rigid_hits.setdefault(a+'|'+b,dict(a=a,b=b,t=state['t'],phase=state['phase'],q=state['q']))
 for extra in state['extras']:
  geom,a,b=geometries[extra['geometry']];M=np.array(extra['M']).reshape(4,4).T;c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2)
  candidates=np.flatnonzero(np.all(c-r<=hi+1e-7,axis=1)&np.all(c+r>=lo-1e-7,axis=1));obj=fcl.CollisionObject(geom,fcl.Transform(M[:3,:3],M[:3,3]))
  for j in candidates:
   n=names[j];key=str(extra.get('path',extra['name']))+'|'+n
   if key in hits:continue
   res=fcl.CollisionResult();calls+=1;fcl.collide(obj,engine.objs[n],req,res)
   if res.is_collision:hits[key]=dict(extra=extra['name'],extra_path=extra.get('path'),extra_trace=extra.get('trace'),solid=n,t=state['t'],phase=state['phase'],product=extra['product'],q=state['q'],extra_M=extra['M'])
 if pi%30==0:
  print('pose',pi,'extra pairs',len(hits),'rigid pairs',len(rigid_hits),flush=True)
  src.with_name(src.stem+'-partial.json').write_text(json.dumps(dict(pose=pi,extra=list(hits.values()),rigid=list(rigid_hits.values())),indent=2))
result=dict(poses=len(poses),extra_candidates=list(hits.values()),rigid_candidates=list(rigid_hits.values()),calls=calls,seconds=time.time()-start,scope='Discrete mesh-surface intersection screen using actual displayed material/demo meshes and CAD rigid bodies. Surface contact/intentional tool contact requires review; containment-only and continuous motion are not certified.')
out=Path(os.environ.get('OUTPUT',str(src.with_name(src.stem+'-results'+('-'+selected if selected else '')+'.json'))));out.write_text(json.dumps(result,ensure_ascii=False,indent=2));print('DONE',len(hits),len(rigid_hits),out,flush=True)
