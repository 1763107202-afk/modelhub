"""Update only the pose hierarchy of a prior GLB for material path preflight.

This temporary file is never a deliverable: the collision engine reads current
CAD directly. Only the unchanged tracked-vegetable meshes are used from here.
"""
import json,struct,copy
from pathlib import Path
from scipy.spatial.transform import Rotation
import machine as m
root=Path(__file__).resolve().parents[1];raw=(root/'dist/cell.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0]
g=json.loads(raw[20:20+n]);binary=raw[28+n:];old={x['name']:x for x in g['nodes']};nodes=[];ids={}
for x in m.GROUP:
 ids[x['name']]=len(nodes);node=dict(name=x['name'],matrix=m.k.mat4(x).T.reshape(-1).tolist(),children=[],extras=dict(node_name=x['name'],label=x['label']))
 nodes.append(node)
 if x['parent']:nodes[ids[x['parent']]]['children'].append(ids[x['name']])
for p in m.PART:
 if p['name'] not in old or 'mesh' not in old[p['name']]:continue
 node=copy.deepcopy(old[p['name']]);node['translation']=p['pos'];node['rotation']=Rotation.from_matrix(m.k.mat4(p)[:3,:3]).as_quat().tolist()
 nodes[ids[p['parent']]]['children'].append(len(nodes));nodes.append(node)
g['nodes']=nodes;g['scenes']=[{'nodes':[ids[x['name']] for x in m.GROUP if not x['parent']]}]
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*(-len(js)%4)
out=struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary
target=root/'engineering/evidence11';target.mkdir(exist_ok=True);(target/'probe.glb').write_bytes(out)
