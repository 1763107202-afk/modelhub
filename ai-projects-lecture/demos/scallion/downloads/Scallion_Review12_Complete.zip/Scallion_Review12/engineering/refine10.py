"""Revision 10: continuous radial exchange openings and supported process paths.
All dimensions are nominal SI geometry. Packaging is still an open subsystem.
"""
import math,json
import cadquery as cq

def install(m):
 k=m.k;by={p['name']:p for p in m.PART};groups={g['name']:g for g in m.GROUP};old=k.shape_for
 def shape(t,d):
  key=json.dumps([t,d])
  if key in k.CQ_CACHE:return k.CQ_CACHE[key]
  if t=='open_grip_frame10':
   pieces=[]
   for sign in [-1,1]:
    s=cq.Workplane('XY').box(.110,.008,.045).val().translate((0,.031,sign*.130))
    for x in [-.043,.043]:s=s.cut(m.axis_cylinder([x,.020,sign*.125],[x,.045,sign*.125],.0032))
    pieces.append(s)
   s=cq.Compound.makeCompound(pieces)
  elif t=='split_grip_guide10':
   x=d[0];s=cq.Compound.makeCompound([m.axis_cylinder([x,0,sign*.057],[x,0,sign*.145],.004) for sign in [-1,1]])
  elif t=='guided_jaw10':
   sign=d[0];s=cq.Workplane('XY').box(.090,.026,.055).val().translate((0,0,sign*.0185))
   for x in [-.036,.036]:s=s.cut(m.axis_cylinder([x,0,-.100],[x,0,.100],.0041))
  else:return old(t,d)
  assert s.isValid(),t;k.CQ_CACHE[key]=s;return s
 k.shape_for=shape
 for parent in sorted({c['parent'] for c in m.CYL if 'grip' in c['parent']}):
  by[parent+'_frame'].update(kind='open_grip_frame10',dims=[],pos=[0,0,0])
  for x in [-.036,.036]:by[parent+'_guide_'+str(x)].update(kind='split_grip_guide10',dims=[x])
  for sign in [-1,1]:
   by[parent+'_jaw_body_'+str(sign)].update(kind='guided_jaw10',dims=[sign])
   inner=.0112 if parent.startswith('grip_') else .0120;outer=.0215
   pad=by[parent+'_PU_'+str(sign)];pad['dims']=[.045,.024,outer-inner,.0004];pad['pos'][2]=sign*((inner+outer)/2-.030)
 for i in range(6):
  parent='carrier_'+str(i);yy=1.071
  pos=m.beam(f'grip_open_positive_{i}',[.250,yy,.130],[.470,yy,.130],.012,parent,f'grip_tab_{i}_0')
  rear=m.beam(f'grip_open_back_{i}',[.250,yy,.130],[.250,yy,-.130],.012,parent,pos)
  neg=m.beam(f'grip_open_negative_{i}',[.250,yy,-.130],[.470,yy,-.130],.012,parent,rear)
  for l in range(2):m.contact(neg,f'grip_{i}_{l}_frame');m.contact(pos,f'grip_{i}_{l}_frame')
 for prefix,axis in [('loader','load_axis'),('unload','unload_axis')]:
  parent=axis+'_slide';yy=groups[prefix+'_grip_0']['pos'][1]+.031;zz=groups[prefix+'_grip_0']['pos'][2]
  for l in range(2):
   tab=by[prefix+f'_grip_tab_{l}'];tab['dims'][2]=.050;tab['pos'][2]+=.005
  pos=m.beam(prefix+'_open_positive',[.060,yy,zz+.130],[-.390,yy,zz+.130],.012,parent,prefix+'_grip_tab_0')
  rear=m.beam(prefix+'_open_back',[.060,yy,zz+.130],[.060,yy,zz-.130],.012,parent,pos)
  neg=m.beam(prefix+'_open_negative',[.060,yy,zz-.130],[-.390,yy,zz-.130],.012,parent,rear)
  for l in range(2):m.contact(neg,prefix+f'_grip_{l}_frame');m.contact(pos,prefix+f'_grip_{l}_frame')
 for i in range(12):
  for l in range(2):by[f'feed_clip_{i}_{l}']['dims'][3:]=[i*30+70,220]
 removed={'peel_head_end_-0.7'}
 m.PART[:]=[p for p in m.PART if p['name'] not in removed];m.MOUNTS[:]=[p for p in m.MOUNTS if p['part'] not in removed and p['support'] not in removed]
 m.set_support('peel_head_cross_back','peel_head_end_0.1')
 for x in [-.51,-.37]:
  n='wash_pipe_cross_'+str(x)
  for q in by[n]['dims'][:2]:q[1]=.200
  stay=m.beam('wash_lower_cross_stay_'+str(x),[x+.03,.522,.140],[x+.03,.200,.140],.012,'wash_axis_slide','wash_head_arm_'+str(x));m.set_support(n,stay)
 for x in [-.51,-.37]:
  for n in ['weigh_drop_','weigh_reach_']:
   for q in by[n+str(x)]['dims'][:2]:q[2]=.080
  link=m.beam('weigh_cell_rear_link_'+str(x),[x+.12,.105,.080],[x+.12,.105,.014],.012,'weigh_lift','weigh_drop_'+str(x));m.set_support('loadcell_'+str(x),link)
 elbow=m.beam('weigh_reach_rear_elbow',[0,.255,.030],[0,.255,.080],.025,'weigh_lift','weigh_lift_plate')
 for x in [-.51,-.37]:m.set_support('weigh_reach_'+str(x),elbow)
 # The remaining leaf/shear reaction-shoe contact during entry stays open.
 for l,x in enumerate([-.51,-.37]):
  cup=by['weigh_cup_'+str(x)];px,py,pz=cup['pos']
  post=m.rod('weigh_insert_'+str(l),[px,py+.004,pz],[px,py+.114,pz],.008,'weigh_lift','steel',cup['name'])
  m.ring('weigh_insert_top_'+str(l),[px,py+.110,pz],[px,py+.114,pz],.014,.001,'weigh_lift','pad',post)
 for i in range(12):
  for l in range(2):
   cup=by[f'out_cup_{i}_{l}'];px,py,pz=cup['pos']
   post=m.rod(f'out_insert_{i}_{l}',[px,py+.004,pz],[px,py+.075,pz],.008,'outfeed_rotor','steel',cup['name'])
   m.ring(f'out_insert_top_{i}_{l}',[px,py+.071,pz],[px,py+.075,pz],.014,.001,'outfeed_rotor','pad',post)
 for z in [-.24,.24]:by['trim_gantry_beam_'+str(z)].update(dims=[2.300,.050,.050,.003],pos=[1.535,2.225,math.copysign(1.25,z)])
 br=m.tube('trim_top_cross_2.35',(.050,.050,2.55),(2.35,2.250,0),'station1','trim_gantry_beam_-0.24')
 for z in [.30,.145]:
  n='trim_axis_extended_hanger_'+str(z)
  hanger=m.beam(n,[2.35,1.950,z],[2.35,2.225,z],.020,'station1',br)
  tab=m.plate(n+'_tab',(.080,.012,.240 if z==.30 else .080),(2.35,1.956,.20 if z==.30 else .13),'station1',support=hanger);m.contact(tab,'trim_axis_base')

def after_services(m):
 by={p['name']:p for p in m.PART}
 # routing07 creates these brackets while installing the services. Extend them
 # to the relocated crossbar here, after they exist, retaining the port end.
 for p in m.PART:
  if p['name'].startswith('wash_pipe_bracket_'):p['dims'][0][1]=.200
 n='carrier_fixed_foot_supply_trim_axis_slide';Ax=by[n]['dims'][0][0]
 by[n]['dims'][:2]=[[Ax,.22,.18],[Ax,.22,-.50]]
 by['carrier_fixed_stand_supply_trim_axis_slide']['dims'][0]=[Ax,.22,-.50]
 shoe=m.beam('trim_carrier_high_shoe',[Ax,.012,.125],[Ax,.012,.18],.014,'trim_axis','trim_axis_base')
 stay=m.beam('trim_carrier_high_stay',[Ax,.012,.18],[Ax,.22,.18],.014,'trim_axis',shoe);m.set_support(n,stay)
