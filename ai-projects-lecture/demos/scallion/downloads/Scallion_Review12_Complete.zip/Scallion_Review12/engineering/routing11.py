"""Final supply routing after relocation of the dry process stations."""
import numpy as np
from routing07 import rounded,route_points

def install(m):
    svc=m.SERVICES;ports=svc['ports'];routes=svc['routes'];by={p['name']:p for p in m.PART};m.apply_home();W=m.k.GM
    def pt(n,parent):return (np.linalg.inv(W[parent])@W[ports[n]['parent']]@np.r_[ports[n]['point'],1])[:3]
    def fixed(name,controls,parent,R=.030):
        r=next(x for x in routes if x['name']==name)
        ps,segs,mr=rounded([pt(r['start'],parent),*controls,pt(r['end'],parent)],R)
        r.update(path=dict(parent=parent,points=ps.tolist()),basis=parent,length_m=float(np.linalg.norm(np.diff(ps,axis=0),axis=1).sum()),minimum_design_bend_m=None if mr>100 else mr)
        by[r['node']].update(parent=parent,pos=[0,0,0],dims=[ps.tolist(),r['outer_radius'],r['inner_radius'],segs],support=ports[r['start']]['body'])
    by['slipring_fixed_restraint']['dims'][:2]=[[.048,1.60,0],[.065,1.64,0]]
    m.set_support('slipring_fixed_restraint','union_restraint_bracket')
    by['valve_control_slipring']['parent']='fixed';m.set_support('valve_control_slipring','slipring_fixed_restraint');m.contact('valve_control_slipring','slipring_rotor_extension')
    # New carrier-mounted services inherit the 500mm radial change applied to
    # existing mechanical parts before installation of the utility system.
    for p in m.PART:
        if p['name'] not in m._pre_services_parts11 and p['parent'].startswith('carrier_') and p['kind']!='service_tube' and not p['name'].startswith('fit_ROTOR_ARM_OUT_'):p['pos'][0]+=.5
    for n,p in ports.items():
        if n.startswith(('ARM_TOP_','ARM_DOWN_','ARM_TAP_')):p['point'][0]+=.5
    for i in range(6):
        a=ports['A_RING_'+str(i)];b=ports['A_RING_'+str((i+1)%6)]
        by['air_ring_link_'+str(i+1)]['dims'][:2]=[(W[a['parent']]@np.r_[a['point'],1])[:3].tolist(),(W[b['parent']]@np.r_[b['point'],1])[:3].tolist()]
        fixed('rotor_arm_'+str(i),[[.150,1.480,0],[.150,1.540,0],[1.070,1.540,0],[1.070,1.540,.240]],'carrier_'+str(i),.020)
        for l in [0,1]:
            name='supply_grip_'+str(i)+'_'+str(l);r=next(x for x in routes if x['name']==name);A=pt(r['start'],'carrier_'+str(i));B=pt(r['end'],'carrier_'+str(i))
            fixed(name,[[A[0],B[1],A[2]]],'carrier_'+str(i),.018)
    # The output carrier runs under the seal-axis base before rising outboard.
    n='carrier_moving_stand_supply_unload_grip_0';by[n]['dims'][:2]=[[.08,.360,.10],[.15,.360,.85]]
    rise=m.beam('unload_carrier_inner_rise11',[.08,.078,.10],[.08,.360,.10],.018,'unload_axis_slide','unload_axis_carriage');m.set_support(n,rise)
    drop=m.beam('unload_carrier_outer_drop11',[.15,.360,.85],[.15,.189,.85],.018,'unload_axis_slide',n);m.set_support('carrier_moving_supply_unload_grip_0',drop)
    # Separate splitter escapes remove the former 5mm S-bends; each flexible
    # pressure branch now has at least a nominal 25mm designed bend.
    for prefix,slide in [('loader','load_axis_slide'),('unload','unload_axis_slide')]:
        for lane,name in enumerate(['branch_'+prefix+'_grip_0','supply_'+prefix+'_grip_1']):
            r=next(x for x in routes if x['name']==name);A=pt(r['start'],slide);B=pt(r['end'],slide);side=-1 if lane==0 else 1
            ex=side*.080;zz=A[2]+side*.100;y=.650+.050*lane;endx=B[0]+.100+.040*lane;endz=B[2]+.120+.020*lane
            fixed(name,[[A[0],A[1]+.030,A[2]],[ex,A[1]+.030,A[2]],[ex,A[1]+.030,zz],[ex,y,zz],[endx,y,zz],[endx,y,endz],[endx,B[1],endz],[B[0],B[1],endz]],slide,.025)
    # Only the wash station consumes clean water. Remove the obsolete long run
    # around the other three stations; feed the wash branch beside the water skid.
    remove={f'clean_water_main_{i}' for i in [5,0,1]}|{f'water_pipe_hanger_{i}' for i in [5,0,1]}|{f'fit_W_MAIN_{i}' for i in [5,0,1]}
    m.PART[:]=[p for p in m.PART if p['name'] not in remove];m.MOUNTS[:]=[x for x in m.MOUNTS if x['part'] not in remove and x['support'] not in remove]
    removed_ports={f'W_MAIN_{i}' for i in [5,0,1]}
    for n in removed_ports:ports.pop(n,None)
    svc['internal_connections'][:]=[ns for ns in svc['internal_connections'] if not removed_ports.intersection(ns)]
    # The central union and cable restraint share the new overhead support.
    cap=by['union_mast_cap'];cap.update(parent='fixed',kind='drilled',dims=[.080,.030,.080,[[0,0,.0081]]],pos=[2.5,2.865,.85])
    p=ports['A_UNION_FEED'];p.update(parent='fixed',point=[2.5,2.86,.85],body='fit_A_UNION_FEED')
    f=by['fit_A_UNION_FEED'];f.update(parent='fixed',pos=[0,0,0],dims=[[2.5,2.86,.85],[2.5,2.94,.85],.008,.0041],support='union_mast_cap')
    m.set_support('fit_A_UNION_FEED','union_mast_cap','threaded')
    ports['A_UNION_FEED_OUT11']=dict(name='A_UNION_FEED_OUT11',parent='fixed',point=[2.5,2.94,.85],body='fit_A_UNION_FEED',medium='air')
    svc['internal_connections'].append(['A_UNION_FEED','A_UNION_FEED_OUT11'])
    next(r for r in routes if r['name']=='union_flexible_inlet')['start']='A_UNION_FEED_OUT11'
    ports['A_UNION_P']['point']=[0,0,.075]
    by['union_fixed_air_in']['dims'][:2]=[[0,0,.054],[0,0,.075]]
    for n in ['union_air_riser_clip_0.6','union_air_riser_clip_1.1','union_air_riser_clip_1.55']:
        if n in by:
            p=by[n];y=float(n.rsplit('_',1)[-1]);p.update(dims=[[2.475,y,.85],[2.510,y,.85],.012,.002],support='union_overhead_mast')
            m.set_support(n,'union_overhead_mast')
    fixed('ring_to_overhead',[[2.5,.21,.85]],'fixed',.035)
    fixed('union_flexible_inlet',[[2.5,3.02,.85],[0,3.02,.18],[0,1.53,.18]],'fixed',.035)
    # New utility position needs a new station-fixed lead, not an obsolete path snapshot.
    for n,dest,height,outer in [('filter_to_control_ring','A_RING_2',1.13,-.75),('filtered_process_to_underframe','P_MAIN_2',.79,-.90),('clean_water_to_underframe','W_MAIN_2',.80,.90)]:
        r=next(x for x in routes if x['name']==n);r['end']=dest;a=pt(r['start'],'station3');b=pt(r['end'],'station3')
        fixed(n,[[a[0],height,a[2]],[a[0],height,outer],[a[0],b[1],outer],[b[0],b[1],outer]],'station3')
    for n,parent in [('lead_fixed_supply_weigh_axis_slide','station5'),('lead_fixed_supply_unload_grip_0','station6')]:
        r=next((x for x in routes if x['name']==n),None)
        if not r:continue
        r['start']='A_STATION_'+('4' if parent=='station5' else '5')
        a=pt(r['start'],parent);b=pt(r['end'],parent)
        fixed(n,[[1.9,a[1],-.85],[1.9,.80,-.85],[b[0],.80,-.85]],parent)
    svc['design']['routing_revision']='11: relocated dry stations; independent electric forming/seal drives; central union inlet retained inside stationary restraint radius.'
