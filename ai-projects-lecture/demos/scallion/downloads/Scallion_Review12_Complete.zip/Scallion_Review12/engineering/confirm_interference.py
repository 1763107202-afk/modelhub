"""Confirm sampled surface candidates with OCC, retaining the sampling limits."""
import json,time
from pathlib import Path
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.gp import gp_Trsf
import machine as m
from collision_engine import world
ROOT=Path('/workspace/scratch/23396c524f3a/interference07');OUT=Path('dist/downloads');by={p['name']:p for p in m.PART};routes={r['name']:r for r in m.SERVICES['routes']};cache={}
def local(n):
 if n not in cache:
  p=by[n];cache[n]=m.k.shape_for(p['kind'],p['dims'])
 return cache[n]
def shape(n,W):
 p=by[n];M=W[p['parent']]@m.k.mat4(p);t=gp_Trsf();t.SetValues(*[float(v) for v in M[:3,:].reshape(-1)]);return local(n).moved(cq.Location(t))
def overlap(A,B):
 c=BRepAlgoAPI_Common(A.wrapped,B.wrapped);c.Build()
 if not c.IsDone():return None
 try:return max(0,cq.Shape(c.Shape()).Volume()*1e9)
 except StopIteration:return 0
rig=json.loads((ROOT/'final_rigid.json').read_text());flex=json.loads((ROOT/'flexible_candidates.json').read_text());rigid=[];hoses=[]
for i,r in enumerate(rig['contact_candidates']):
 W=world(r['q']);v=overlap(shape(r['a'],W),shape(r['b'],W));rigid.append(dict(**r,first_candidate_pose_CAD_overlap_mm3=v));print('rigid',i,r['a'],r['b'],v,flush=True)
W=world({})
for i,r in enumerate(flex['capsule_contacts']):
 v=overlap(shape(routes[r['route']]['node'],W),shape(r['solid'],W));hoses.append(dict(**r,home_CAD_overlap_mm3=v));print('hose',i,r['route'],r['solid'],v,flush=True)
result=dict(revision='07',rigid_poses=rig['poses'],rigid_components=rig['rigid_components'],rigid_narrow_phase_calls=rig['narrow_phase_calls'],rigid_surface_candidate_pairs=len(rigid),rigid_positive_volume_at_first_candidate=sum((r['first_candidate_pose_CAD_overlap_mm3'] or 0)>.1 for r in rigid),rigid_candidates=rigid,flexible_poses=flex['poses'],flexible_routes=flex['routes'],flexible_candidate_pairs=len(hoses),flexible_positive_home_volume_pairs=sum((r['home_CAD_overlap_mm3'] or 0)>.1 for r in hoses),flexible_candidates=hoses,production_release=False,continuous_collision_certified=False,scope='369 discrete rigid poses in ten isolated programs. Same rigid-body geometry and declared mates excluded; no containment-only or between-sample guarantee. Each unique candidate is confirmed only at its first candidate pose. Flexible capsules and exact BREP check cover the HOME pose only; hose/hose and full flexible-motion clearance remain open. Positive volumes are reported, not suppressed. Nominal weld/pipe junction overlaps have not been separated from unintended collisions.')
(OUT/'interference_review_07.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('DONE',result['rigid_positive_volume_at_first_candidate'],result['flexible_positive_home_volume_pairs'],flush=True)
