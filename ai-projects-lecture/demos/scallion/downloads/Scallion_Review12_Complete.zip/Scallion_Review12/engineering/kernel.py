"""Parametric concept assembly. Metres internally; STEP in millimetres.
Analytical design envelope, not a fabrication release or a reconstruction of 3.24(1).SLDASM.
"""
from pathlib import Path
import json, math, hashlib, struct, time
import numpy as np
import cadquery as cq
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'; OUT=DIST/'downloads'; OUT.mkdir(exist_ok=True,parents=True)
TAU=math.tau
MATS={
 'steel':{'color':'#bdc9cb','metal':.78,'rough':.28,'density':7930},
 'aluminum':{'color':'#c3cdd0','metal':.7,'rough':.32,'density':2700},
 'dark':{'color':'#30484b','metal':.55,'rough':.38,'density':7850},
 'green':{'color':'#19766a','metal':.35,'rough':.3,'density':2700},
 'black':{'color':'#223136','metal':.18,'rough':.52,'density':1200},
 'pad':{'color':'#e5e4cc','metal':0,'rough':.8,'density':1150},
 'glass':{'color':'#c5dedb','metal':0,'rough':.1,'alpha':.16,'density':1200},
 'blue':{'color':'#258eaf','metal':.18,'rough':.32,'density':1150},
 'orange':{'color':'#d5924b','metal':.25,'rough':.38,'density':1100},
 'white':{'color':'#f0efcf','metal':0,'rough':.65,'density':0},
 'leaf':{'color':'#4d8c3e','metal':0,'rough':.7,'density':0},
 'root':{'color':'#c4a77c','metal':0,'rough':.95,'density':0},
 'paper':{'color':'#e6ce91','metal':0,'rough':.8,'density':0},
 'red':{'color':'#cb5a42','metal':.15,'rough':.4,'density':1200},
}
GROUPS=[]; PARTS=[]; CACHE={}; CQ_CACHE={}; PART_NAMES=set()
def group(name,parent=None,pos=(0,0,0),yaw=0,station=0,label=None):
 g={'name':name,'parent':parent,'pos':list(pos),'yaw':yaw,'station':station,'label':label or name};GROUPS.append(g);return name
def part(name,kind,dims,pos=(0,0,0),mat='steel',parent='fixed',yaw=0,station=0,cad=True):
 if name in PART_NAMES:
  name=name+'_'+str(len(PARTS))
 PART_NAMES.add(name)
 PARTS.append({'name':name,'kind':kind,'dims':dims,'pos':list(pos),'yaw':yaw,'mat':mat,'parent':parent,'station':station,'cad':cad});return PARTS[-1]
def box(name,w,h,d,pos,**kw):return part(name,'box',[w,h,d],pos,**kw)
def cyl(name,r,h,pos,**kw):return part(name,'cyl',[r,h],pos,**kw)
def ring(name,ri,ro,h,pos,start=0,angle=360,**kw):return part(name,'ring',[ri,ro,h,start,angle],pos,**kw)
def ball(name,r,pos,**kw):return part(name,'sphere',[r],pos,**kw)
def rod(name,a,b,r,**kw):return part(name,'rod',[list(a),list(b),r],**kw)
def bolts(prefix,rad,y,n=8,center=(0,0),parent='fixed',station=0,size=.004):
 for i in range(n):
  a=i*TAU/n; p=(center[0]+rad*math.cos(a),y,center[1]+rad*math.sin(a))
  cyl(f'{prefix}_{i:02}',size,.007,p,mat='dark',parent=parent,station=station)
def foot(prefix,x,z,parent='fixed',station=0):
 cyl(prefix+'_pad',.045,.016,(x,.018,z),mat='black',parent=parent,station=station)
 cyl(prefix+'_adjuster',.011,.065,(x,.056,z),mat='steel',parent=parent,station=station)
 cyl(prefix+'_locknut',.017,.009,(x,.067,z),mat='dark',parent=parent,station=station)
def motor(prefix,pos,parent='fixed',station=0,small=False):
 x,y,z=pos;s=.6 if small else 1
 box(prefix+'_motor',.08*s,.15*s,.08*s,(x,y,z),mat='black',parent=parent,station=station)
 for dz in [-.027,-.009,.009,.027]:box(prefix+'_fin'+str(dz),.086*s,.13*s,.003*s,(x,y,z+dz*s),mat='dark',parent=parent,station=station)
 cyl(prefix+'_flange',.053*s,.015*s,(x,y+.08*s,z),mat='steel',parent=parent,station=station)
 box(prefix+'_plug',.025*s,.035*s,.027*s,(x+.048*s,y-.028*s,z),mat='black',parent=parent,station=station)
def scallion(name,pos,parent,station=0,raw=False):
 x,y,z=pos;g=group(name,parent,pos,station=station,label='大葱占位：φ26 / L780（仅形态示意）')
 part(name+'_stem','cone',[.014,.0115,.44],(0,.22,0),mat='white',parent=g,station=station,cad=False)
 part(name+'_neck','cone',[.0115,.010,.11],(0,.495,0),mat='leaf',parent=g,station=station,cad=False)
 for j in range(5):
  a=TAU*j/5; end=(.035*math.cos(a),.76-.025*(j%3),.035*math.sin(a))
  part(f'{name}_leaf_{j}','taperrod',[[.007*math.cos(a),.48,.007*math.sin(a)],list(end),.006,.0015],mat='leaf',parent=g,station=station,cad=False)
 for j in range(5):
  a=TAU*j/5;rod(f'{name}_root_{j}',(.007*math.cos(a),0,.007*math.sin(a)),(.019*math.cos(a),-.022,.019*math.sin(a)),.00065,mat='root',parent=g,station=station,cad=False)
 if raw:
  r=group(name+'_skin',g,station=station)
  ring(name+'_skin_shell',.0142,.0146,.36,(0,.20,0),start=12,angle=280,mat='root',parent=r,station=station,cad=False)
 return g

def shape_for(kind,d):
 key=json.dumps([kind,d],sort_keys=True)
 if key in CQ_CACHE:return CQ_CACHE[key]
 V=cq.Vector
 if kind=='box':s=cq.Workplane('XY').box(*d).val()
 elif kind=='tube':
  w,h,z,t=d;outer=[w,h,z];inner=[w-2*t,h-2*t,z-2*t];axis=int(np.argmax(outer));inner[axis]=outer[axis]+.001;s=cq.Workplane('XY').box(*outer).val().cut(cq.Workplane('XY').box(*inner).val())
 elif kind in ['cyl','cone']:
  if kind=='cyl':r,h=d;s=cq.Solid.makeCylinder(r,h,V(0,-h/2,0),V(0,1,0))
  else:r1,r2,h=d;s=cq.Solid.makeCone(r1,r2,h,V(0,-h/2,0),V(0,1,0))
 elif kind=='slotted_cup':
  r,h=d;s=cq.Solid.makeCylinder(r,h,V(0,-h/2,0),V(0,1,0))
  for zz in [-.009,.009]:s=s.cut(cq.Workplane('XY').box(.061,h+.002,.006).val().translate((0,0,zz)))
 elif kind=='ring_cutout':
  ri,ro,h,rc,rr,aa=d;s=cq.Solid.makeCylinder(ro,h,V(0,-h/2,0),V(0,1,0)).cut(cq.Solid.makeCylinder(ri,h+.004,V(0,-h/2-.002,0),V(0,1,0)))
  a=math.radians(aa);s=s.cut(cq.Solid.makeCylinder(rc,h+.006,V(rr*math.cos(a),-h/2-.003,rr*math.sin(a)),V(0,1,0)))
 elif kind=='ring':
  ri,ro,h,start,ang=d;s=cq.Solid.makeCylinder(ro,h,V(0,-h/2,0),V(0,1,0)).cut(cq.Solid.makeCylinder(ri,h+.004,V(0,-h/2-.002,0),V(0,1,0)))
  if ang<359.99:
   points=[V(0,-h/2-.003,0)]+[V(ro*3*math.cos(math.radians(a)),-h/2-.003,ro*3*math.sin(math.radians(a))) for a in np.linspace(start,start+ang,max(3,math.ceil(ang/20)+1))]+[V(0,-h/2-.003,0)]
   wedge=cq.Solid.extrudeLinear(cq.Wire.makePolygon(points),[],V(0,h+.006,0));s=s.intersect(wedge)
 elif kind=='sphere':s=cq.Solid.makeSphere(d[0],angleDegrees1=-90,angleDegrees2=90)
 elif kind in ['rod','taperrod']:
  a,b,r=d[:3];a,b=V(*a),V(*b);v=b-a
  s=cq.Solid.makeCylinder(r,v.Length,a,v.normalized()) if kind=='rod' else cq.Solid.makeCone(r,d[3],v.Length,a,v.normalized())
 else:
  from mechanical_v2 import make_shape
  s=make_shape(kind,d)
 CQ_CACHE[key]=s;return s
def loc(obj):return cq.Location(cq.Vector(*obj['pos']))*cq.Location(cq.Vector(),cq.Vector(0,1,0),obj['yaw'])*cq.Location(cq.Vector(),cq.Vector(0,0,1),obj.get('roll',0))
def mat4(obj):
 a=math.radians(obj['yaw']);b=math.radians(obj.get('roll',0));c,s=math.cos(a),math.sin(a);co,si=math.cos(b),math.sin(b);m=np.array([[c*co,-c*si,s,obj['pos'][0]],[si,co,0,obj['pos'][1]],[-s*co,s*si,c,obj['pos'][2]],[0,0,0,1]],dtype=float);return m
GM={}; GL={}
for g in GROUPS:
 GM[g['name']]=(GM[g['parent']] if g['parent'] else np.eye(4))@mat4(g)
 GL[g['name']]=(GL[g['parent']] if g['parent'] else cq.Location())*loc(g)

def build():
 print('Building',len(PARTS),'part nodes',flush=True)
 geometries=[];meshes=[];mesh_index={};nodes=[];indices={};parents={};binparts=[];views=[];accessors=[];offset=0
 gltf={'asset':{'version':'2.0','generator':'Parametric engineering concept / metres'},'scene':0,'scenes':[{'nodes':[]}], 'nodes':nodes,'meshes':meshes,'bufferViews':views,'accessors':accessors,'materials':[]}
 mat_index={}
 for n,m in MATS.items():
  co=[int(m['color'][i:i+2],16)/255 for i in [1,3,5]]+[m.get('alpha',1)]
  a={'name':n,'pbrMetallicRoughness':{'baseColorFactor':co,'metallicFactor':m['metal'],'roughnessFactor':m['rough']},'doubleSided':False}
  if m.get('alpha'):a.update({'alphaMode':'BLEND','doubleSided':True})
  mat_index[n]=len(gltf['materials']);gltf['materials'].append(a)
 def buffer(array,target,component,count,typ):
  nonlocal offset
  raw=array.tobytes();pad=(-len(raw))%4;vi=len(views);views.append({'buffer':0,'byteOffset':offset,'byteLength':len(raw),'target':target});binparts.append(raw+b'\0'*pad);offset+=len(raw)+pad
  ac={'bufferView':vi,'componentType':component,'count':count,'type':typ}
  if typ=='VEC3':ac.update({'min':array.reshape(-1,3).min(axis=0).astype(float).tolist(),'max':array.reshape(-1,3).max(axis=0).astype(float).tolist()})
  ai=len(accessors);accessors.append(ac);return ai
 for g in GROUPS:
  i=len(nodes);indices[g['name']]=i
  a=math.radians(g['yaw'])/2
  nodes.append({'name':g['name'],'matrix':mat4(g).T.reshape(-1).tolist(),'children':[],'extras':{'station':g['station'],'label':g['label'],'node_name':g['name']}})
  if g['parent']:nodes[indices[g['parent']]]['children'].append(i)
  else:gltf['scenes'][0]['nodes'].append(i)
 masses=[];valid=0;invalid=[];bboxmin=np.ones(3)*1e5;bboxmax=-bboxmin
 # Keep native component coordinates and a genuine nested STEP product tree.
 # Repeated parts share one scaled shape, rather than baking every world transform into BREP.
 step_groups={g['name']:cq.Assembly(name=g['name']) for g in GROUPS};scaled_shapes={}
 def mm_loc(ob):
  copy=dict(ob);copy['pos']=[x*1000 for x in ob['pos']];return loc(copy)
 for pi,p in enumerate(PARTS):
  try:shp=shape_for(p['kind'],p['dims'])
  except Exception as error:raise ValueError('Invalid CAD part '+p['name']) from error
  key=json.dumps([p['kind'],p['dims']]);mkey=key+p['mat']
  if key not in CACHE:
   if p['kind']=='service_tube':
    # Exact CAD sweep stays in STEP; a predictable tube LOD avoids OCC's highly
    # redundant spline tessellation in the interactive model.
    pts,ro,ri=p['dims'][:3];pts=np.asarray(pts,float);tang=np.gradient(pts,axis=0);tang/=np.linalg.norm(tang,axis=1)[:,None]
    bn=np.cross(pts[len(pts)//2]-pts[0],pts[-1]-pts[0])
    if np.linalg.norm(bn)<1e-9:bn=np.cross(tang[0],[0,1,0] if abs(tang[0,1])<.9 else [1,0,0])
    bn/=np.linalg.norm(bn);ns=np.cross(bn,tang);sides=10;vv=[];tt=[];N=len(pts)
    for r in [ro,ri]:
     for q,nr in zip(pts,ns):
      for a in np.arange(sides)*math.tau/sides:vv.append(q+r*(nr*math.cos(a)+bn*math.sin(a)))
    for layer in range(2):
     off=layer*N*sides
     for i in range(N-1):
      for j in range(sides):
       a=off+i*sides+j;b=off+i*sides+(j+1)%sides;c=b+sides;d=a+sides
       tt.extend([(a,b,c),(a,c,d)] if layer==0 else [(a,c,b),(a,d,c)])
    for i,reverse in [(0,True),(N-1,False)]:
     for j in range(sides):
      a=i*sides+j;b=i*sides+(j+1)%sides;c=b+N*sides;d=a+N*sides
      tt.extend([(a,c,b),(a,d,c)] if reverse else [(a,b,c),(a,c,d)])
    v=np.asarray(vv,dtype='<f4');ix=np.asarray(tt,dtype='<u4').reshape(-1)
   else:
    verts,tris=shp.tessellate(.0007,.22);v=np.array([q.toTuple() for q in verts],dtype='<f4');ix=np.array(tris,dtype='<u4').reshape(-1)
   norm=np.zeros_like(v);vv=v[ix.reshape(-1,3)];nr=np.cross(vv[:,1]-vv[:,0],vv[:,2]-vv[:,0]);np.add.at(norm,ix.reshape(-1,3)[:,0],nr);np.add.at(norm,ix.reshape(-1,3)[:,1],nr);np.add.at(norm,ix.reshape(-1,3)[:,2],nr);length=np.linalg.norm(norm,axis=1);norm/=np.maximum(length[:,None],1e-20)
   CACHE[key]=(buffer(v,34962,5126,len(v),'VEC3'),buffer(norm,34962,5126,len(v),'VEC3'),buffer(ix,34963,5125,len(ix),'SCALAR'))
  if mkey not in mesh_index:
   v,n,t=CACHE[key];mesh_index[mkey]=len(meshes);meshes.append({'name':p['kind'],'primitives':[{'attributes':{'POSITION':v,'NORMAL':n},'indices':t,'material':mat_index[p['mat']]}]})
  idx=len(nodes);a=math.radians(p['yaw'])/2;nodes.append({'name':p['name'],'mesh':mesh_index[mkey],'translation':p['pos'],'rotation':[0,math.sin(a),0,math.cos(a)],'extras':{'station':p['station'],'material':p['mat'],'cad':p['cad'],'label':p['name']}});nodes[indices[p['parent']]]['children'].append(idx)
  world=GM[p['parent']]@mat4(p);bb=shp.BoundingBox();corners=np.array([[x,y,z,1] for x in [bb.xmin,bb.xmax] for y in [bb.ymin,bb.ymax] for z in [bb.zmin,bb.zmax]])@world.T;bboxmin=np.minimum(bboxmin,corners[:,:3].min(axis=0));bboxmax=np.maximum(bboxmax,corners[:,:3].max(axis=0))
  if p['cad']:
   if not shp.isValid():invalid.append(p['name'])
   else:valid+=len(shp.Solids())
   cloc=GL[p['parent']]*loc(p)
   # Shape/placement are both scaled from m to mm for the STEP product.
   moved=shp.moved(cloc)
   if key not in scaled_shapes:scaled_shapes[key]=shp.scale(1000)
   step_groups[p['parent']].add(scaled_shapes[key],loc=mm_loc(p),name=p['name'].replace('.','p').replace('-','m'),color=cq.Color(MATS[p['mat']]['color']))
   rho=MATS[p['mat']]['density'];pr=GProp_GProps();BRepGProp.VolumeProperties_s(moved.wrapped,pr);vol=pr.Mass();cen=pr.CentreOfMass();im=pr.MatrixOfInertia();mass=vol*rho
   # CAD second moment about Y plus parallel axis, using geometry density in kg/m3.
   iy=(im.Value(2,2)+vol*(cen.X()**2+cen.Z()**2))*rho
   ancestor=p['parent']; is_rotor=False
   while ancestor:
    if ancestor=='carousel':is_rotor=True;break
    ancestor=next((g['parent'] for g in GROUPS if g['name']==ancestor),None)
   max_r=max((math.hypot(v.X,v.Z) for v in moved.Vertices()),default=0) if is_rotor else 0
   masses.append({'name':p['name'],'mass_kg':mass,'Iy_kg_m2':iy,'rotor':is_rotor,'max_radius_m':max_r,'parent':p['parent']})
  if pi%300==0:print('part',pi,flush=True)
 rawbin=b''.join(binparts);gltf['buffers']=[{'byteLength':len(rawbin)}];rawjson=json.dumps(gltf,separators=(',',':')).encode();rawjson+=b' '*((-len(rawjson))%4);total=12+8+len(rawjson)+8+len(rawbin)
 (DIST/'cell.glb').write_bytes(struct.pack('<III',0x46546c67,2,total)+struct.pack('<II',len(rawjson),0x4e4f534a)+rawjson+struct.pack('<II',len(rawbin),0x004e4942)+rawbin)
 (OUT/'SCALLION_CELL.glb').write_bytes((DIST/'cell.glb').read_bytes())
 print('Exporting STEP',valid,'valid solids',flush=True)
 for ob in reversed(GROUPS):
  if ob['parent'] and step_groups[ob['name']].children:
   step_groups[ob['parent']].add(step_groups[ob['name']],loc=mm_loc(ob))
 step_asm=cq.Assembly(name='SCALLION_CELL_ASSEMBLY_12_MM')
 for ob in GROUPS:
  if not ob['parent']:step_asm.add(step_groups[ob['name']],loc=mm_loc(ob))
 step_asm.save(str(OUT/'SCALLION_CELL_concept_mm.step'),write_pcurves=False)
 print('STEP exported',flush=True)
 stats={'part_nodes':len(PARTS),'cad_bodies':valid,'invalid_shapes':invalid,'mesh_variants':len(meshes),'unique_geometry':len(CQ_CACHE),'bbox_min_m':bboxmin.tolist(),'bbox_max_m':bboxmax.tolist(),'model_rotor_mass_kg':sum(p['mass_kg'] for p in masses if p['rotor']),'model_rotor_Iy_kg_m2':sum(p['Iy_kg_m2'] for p in masses if p['rotor']),'model_rotor_max_radius_m':max((p['max_radius_m'] for p in masses),default=0),'structural_mass_kg':sum(p['mass_kg'] for p in masses),'note':'Homogeneous simplified geometry. Bearings/motors are envelopes; shaft and arms are explicit. Not a purchased-component mass certificate.'}
 (ROOT/'engineering/mass_breakdown.json').write_text(json.dumps(masses,indent=2),encoding='utf-8')
 (OUT/'geometry_verification.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
 (ROOT/'engineering/scene_manifest.json').write_text(json.dumps({'groups':GROUPS,'parts':PARTS,'materials':MATS},ensure_ascii=False),encoding='utf-8')
 print(json.dumps(stats,ensure_ascii=False),flush=True)
 return stats
