"""All-pose regression of four replaced tools, with proof that other meshes agree.

Unchanged rigid/material pairs reuse the completed full baseline. This is a
geometric delta check, not a new unrestricted all-pairs clearance certificate.
"""
from pathlib import Path
import gzip,json,struct,hashlib,time
import numpy as np
from collision_engine import Engine,world,fcl,tkey,SHAPE_HASH
import machine as m
R=Path(__file__).resolve().parents[1];E=R/'engineering/evidence11';O=R/'dist/downloads'
baseline=json.loads((E/'rigid_baseline.json').read_text())
old=json.loads(gzip.decompress((E/'baseline_manifest.json.gz').read_bytes()))
current=json.loads((R/'engineering/scene_manifest.json').read_text())
changed={p['name'] for p in current['parts'] if p['kind']=='straight_shear11'}
assert changed=={'root_blade_1.03','root_blade_1.17','trim_blade_0','trim_blade_1'}
assert old['groups']==current['groups'],'Group hierarchy changed since baseline'
a={p['name']:p for p in old['parts']};b={p['name']:p for p in current['parts']}
assert set(a)==set(b)
for n in a:
    aa,bb=a[n].copy(),b[n].copy()
    if n in changed:assert aa.pop('kind')=='knife' and bb.pop('kind')=='straight_shear11'
    assert aa==bb,n

raw=(R/'dist/cell.glb').read_bytes();ln=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+ln]);buf=raw[28+ln:]
def bs(i):
    x=g['accessors'][i];v=g['bufferViews'][x['bufferView']];off=v.get('byteOffset',0)+x.get('byteOffset',0)
    return buf[off:off+v['byteLength']]
signatures={}
for n in g['nodes']:
    if 'mesh' not in n:continue
    p=g['meshes'][n['mesh']]['primitives'][0]
    signatures[n['name']]=hashlib.sha256(bs(p['attributes']['POSITION'])+bs(p['indices'])).hexdigest()
previous=json.loads((E/'baseline_mesh_signatures.json').read_text())
mesh_changes={n for n,h in signatures.items() if h!=previous['meshes'][n]}
assert mesh_changes==changed,mesh_changes

src=R/'repair11-final.json';data=json.loads(src.read_text());prior=json.loads(gzip.decompress((E/'baseline_poses.json.gz').read_bytes()))
assert len(data['poses'])==len(prior['poses'])==baseline['poses']
for pa,pb in zip(prior['poses'],data['poses']):
    assert pa['q']==pb['q'] and pa['t']==pb['t'] and pa['phase']==pb['phase']
    assert len(pa['extras'])==len(pb['extras'])
    for x,y in zip(pa['extras'],pb['extras']):
        assert x['name']==y['name'] and x['M']==y['M']
        assert prior['geometries'][x['geometry']]==data['geometries'][y['geometry']]
e=Engine();names=list(e.objs);parts=[e.by[n] for n in names];indices=[names.index(n) for n in changed]
locals=np.array([e.local[n] for n in names]);centres=np.array([(e.bounds[n][0]+e.bounds[n][1])/2 for n in names]);radii=np.array([(e.bounds[n][1]-e.bounds[n][0])/2 for n in names])
extras={}
for k,v in data['geometries'].items():
    vs=np.asarray(v['v']).reshape(-1,3);ts=np.asarray(v['t'],np.int32).reshape(-1,3);geom=fcl.BVHModel();geom.beginModel(len(vs),len(ts));geom.addSubModel(vs,ts);geom.endModel()
    extras[k]=(geom,vs.min(0),vs.max(0))
req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True);hits={};materials={};seen=set();calls=0;start=time.time()
for pi,state in enumerate(data['poses']):
    w=world(state['q']);M=np.array([w[p['parent']] for p in parts])@locals
    c=np.einsum('nij,nj->ni',M[:,:3,:3],centres)+M[:,:3,3];r=np.einsum('nij,nj->ni',np.abs(M[:,:3,:3]),radii);lo,hi=c-r,c+r
    for i in indices:
        n=names[i];inv=np.linalg.inv(M[i]);e.objs[n].setTransform(fcl.Transform(M[i,:3,:3],M[i,:3,3]))
        js=np.flatnonzero(np.all(lo[i]<=hi+1e-7,axis=1)&np.all(hi[i]>=lo-1e-7,axis=1))
        for j in js:
            other=names[j];pair=tuple(sorted((n,other)))
            if other==n or e.sigs[n]==e.sigs[other] or frozenset(pair) in e.allowed:continue
            sig=(pair,tkey(inv@M[j]))
            if sig in seen:continue
            seen.add(sig);e.objs[other].setTransform(fcl.Transform(M[j,:3,:3],M[j,:3,3]));res=fcl.CollisionResult();fcl.collide(e.objs[n],e.objs[other],req,res);calls+=1
            if res.is_collision:hits.setdefault(pair,dict(a=pair[0],b=pair[1],t=state['t'],phase=state['phase'],q=state['q']))
        for x in state['extras']:
            geom,a0,b0=extras[x['geometry']];X=np.asarray(x['M']).reshape(4,4).T;cc=X[:3,:3]@((a0+b0)/2)+X[:3,3];rr=np.abs(X[:3,:3])@((b0-a0)/2)
            if np.any(cc-rr>hi[i]) or np.any(cc+rr<lo[i]):continue
            sig=(x['name'],n,tkey(inv@X))
            if sig in seen:continue
            seen.add(sig);obj=fcl.CollisionObject(geom,fcl.Transform(X[:3,:3],X[:3,3]));res=fcl.CollisionResult();fcl.collide(obj,e.objs[n],req,res);calls+=1
            if res.is_collision:materials.setdefault((x['name'],n),dict(extra=x['name'],solid=n,extra_trace=x['trace'],extra_path=x['path'],extra_M=x['M'],t=state['t'],phase=state['phase'],q=state['q'],product=x['product']))
    if pi%300==0:print('delta pose',pi,'rigid',len(hits),'material',len(materials),flush=True)
combined=dict(baseline)
combined['rigid_candidates']=[x for x in baseline['rigid_candidates'] if not changed.intersection([x['a'],x['b']])]+list(hits.values())
combined['extra_candidates']=[x for x in baseline['extra_candidates'] if x['solid'] not in changed]+list(materials.values())
combined.update(source_pose_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),glb_sha256=hashlib.sha256(raw).hexdigest(),
    changed_tools=sorted(changed),unchanged_meshes_proved=len(signatures)-len(changed),baseline_glb_sha256=previous['glb_sha256'],
    delta_pose_count=len(data['poses']),delta_narrow_phase_calls=calls,delta_seconds=time.time()-start,geometry_code_sha256=SHAPE_HASH,
    scope='Completed full baseline, plus all-pose regression of four replaced tool meshes. Per-part position/index hashes, exact unchanged group/part metadata and identical joint/material poses prove all other pairs unchanged. Same rigid body and declared mates excluded. Surface contacts, containment-only, flexible materials/film and continuous motion are not production-certified.')
(O/'full_workflow_clearance_screen_11.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2))
(E/'tool_delta_checks.json').write_text(json.dumps({k:v for k,v in combined.items() if k not in ['extra_candidates','rigid_candidates']},ensure_ascii=False,indent=2))
print('DONE delta',len(hits),'rigid',len(materials),'material',round(time.time()-start,1),'seconds',flush=True)
