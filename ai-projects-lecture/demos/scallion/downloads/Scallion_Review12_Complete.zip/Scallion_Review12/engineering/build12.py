import json,struct
from pathlib import Path
import machine as m
from refine12 import install
from scipy.spatial.transform import Rotation
from infeed12 import install as infeed
infeed(m)
install(m)
stats=m.k.build()
p=m.k.DIST/'cell.glb';raw=p.read_bytes();sz=struct.unpack_from('<I',raw,12)[0];obj=json.loads(raw[20:20+sz]);binary=raw[28+sz:]
by={v['name']:v for v in m.PART}
for node in obj['nodes']:
 if node.get('mesh') is not None:
  src=by[node['name']];node['rotation']=Rotation.from_matrix(m.k.mat4(src)[:3,:3]).as_quat().tolist();node['extras'].update(support=src.get('support'),connection=src.get('connection','product'))
obj['asset']['generator']='Scallion review12 / derived from supplied revision11'
js=json.dumps(obj,separators=(',',':')).encode();js+=b' '*(-len(js)%4)
out=struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary
p.write_bytes(out);(m.k.OUT/'SCALLION_CELL.glb').write_bytes(out)
data=dict(revision='MECHANICAL-12',joints=m.JOINTS,linear_axes=m.AXES,cylinders=m.CYL,mounts=m.MOUNTS,contact_checks=m.CONTACTS,services=m.SERVICES,stats=stats,review12=m.REVIEW12)
(m.k.DIST/'mechanics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
print('REVIEW12',stats,flush=True)
