import json,math,copy
import numpy as np
from pathlib import Path
import machine as m
k=m.k;by={p['name']:p for p in m.PART}
results=[];bad=[]
for c in m.CYL:
 j=next(j for j in m.JOINTS if j['child']==c['child'] and j['type']=='prismatic')
 rod=by[c['rod']];end=np.array(rod['dims'][1]);cfg=next(g for g in m.GROUP if g['name']==c['child'])
 minins=1e9;maxins=-1e9;err=0
 for q in np.linspace(*j['limits'],21):
  ob=copy.deepcopy(cfg);ob['pos']=(np.array(j.get('offset',[0,0,0]))+np.array(j['axis'])*q).tolist();T=k.mat4(ob)
  actual=(T@np.r_[end,1])[:3];target=np.array(c['home_end'])+np.array(j['axis'])*q
  err=max(err,float(np.linalg.norm(actual-target)))
  ext=float(np.dot(actual-np.array(c['nose']),c['axis']));ins=c['rod_length']-ext;minins=min(minins,ins);maxins=max(maxins,ins)
 r={'name':c['name'],'min_insertion_mm':minins*1000,'max_insertion_mm':maxins*1000,'barrel_mm':c['barrel_length']*1000,'max_endpoint_error_mm':err*1000}
 results.append(r)
 if minins<.00899 or maxins>c['barrel_length']-.00899 or err>1e-8:bad.append(r)
# Rail and screw coverage use the installed lengths, actual block centres and nut lengths.
rail=[]
for a in m.AXES:
 margins=[(.12+q-.06-.0775/2,a['L']-(.12+q+.06+.0775/2)) for q in [0,a['stroke']]]
 minmargin=min(x for pair in margins for x in pair)
 rail.append({'axis':a['name'],'min_block_end_margin_mm':minmargin*1000,'nut_end_margin_mm':min(.12-.02-.05,a['L']-.05-(.12+a['stroke']+.03))*1000})
 if minmargin<.02:bad.append(rail[-1])
# Nominal simplified-body moving masses, plus an explicit 0.5 kg material allowance.
groups={g['name']:g for g in m.GROUP}
def under(p,ancestor):
 g=p
 while g:
  if g==ancestor:return True
  g=groups[g]['parent']
 return False
masses=json.loads((m.ROOT/'engineering/mass_breakdown.json').read_text())
liftmass=sum(p['mass_kg'] for p in masses if under(p['parent'],'weigh_lift'))+.5
push=245.5*.7;required=liftmass*(9.81+.5)+10
calculations={'lift_mass_with_material_kg':liftmass,'lift_available_N':push,'lift_required_N':required,'lift_force_margin':push/required,'assumptions':{'air_pressure_MPa':.5,'efficiency':.7,'acceleration_m_s2':.5,'additional_friction_N':10,'material_kg':.5},'note':'Nominal model mass. Bearing moment/guide load, leakage, actual CG and material tests are not validated.'}
out={'cylinder_sweep_samples':len(results)*21,'cylinders':results,'rail_coverage':rail,'failures':bad,'lift_calculation':calculations}
Path('dist/downloads/kinematic_geometry_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'cylinders':len(results),'failures':bad,'calculation':calculations},ensure_ascii=False,indent=2))
if bad:raise SystemExit(1)
