"""Build a review surface from completed, current revision-11 evidence."""
from pathlib import Path
import json,hashlib,html,gzip

R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads'
def read(n):return json.loads((O/n).read_text())
flow=read('full_workflow_timeline_11.json');screen=read('full_workflow_clearance_screen_11.json')
mount=read('mount_checks.json');pipes=read('hose_pair_checks_11.json');flex=read('hose_rigid_checks_11.json')
pose_path=R/'repair11-final.json';poses=json.loads(pose_path.read_text())['poses']
def expected_material(x):
    n,p=x['solid'],x['phase']
    if n.startswith('feed_clip_'):return p in ['feed','root','load']
    if '_PU_' in n and n.startswith(('loader_grip','grip_','unload_grip')):return True
    if n.startswith('root_blade_'):return p=='root'
    if n.startswith(('trim_blade_','trim_counter_')):return p=='trim'
    if n.startswith('weigh_insert_top_'):return p=='weigh'
    if n.startswith('out_insert_top_'):return p in ['outfeed','return']
    return False
unexpected=[x for x in screen['extra_candidates'] if not expected_material(x)]
screen.update(source_pose_sha256=hashlib.sha256(pose_path.read_bytes()).hexdigest(),
  expected_material_contacts=[x for x in screen['extra_candidates'] if expected_material(x)],unexpected_material_candidates=unexpected,
  material_classification='Only named cutting edges in their process phase, PU pads, feed clips and receiver top inserts are classified as intended. Film/debris and continuous deformable processing are outside this screen.')
(O/'full_workflow_clearance_screen_11.json').write_text(json.dumps(screen,ensure_ascii=False,indent=2))
names={p['name'] for p in json.loads((R/'engineering/scene_manifest.json').read_text())['parts']}
stages={s['id']:s for s in flow['stages']};cases=[]
def case(ident,title,phase,a,b,action,time=None):
    assert a in names and b in names,(a,b)
    s=stages[phase];t=time if time is not None else (s['start']+s['end'])/2
    cases.append(dict(id=ident,title=title,t=t,phase=phase,parts=[dict(name=a),dict(name=b)],
      evidence=f"整套作业{screen['poses']}个离散姿态；同刚体和声明配合排除，柔性管另列。",
      status='已实改；限定离散检查点' if not screen['rigid_candidates'] else '已实改；仍有刚体候选待处理',
      problem='本项用于检查实体连接、进入顺序或退让空间；不代表整机工业验收。',
      action=action,resolved=not bool(screen['rigid_candidates'])))
case('R01','反刃先侧退，再随刀架进出','trim','trim_counter_0','counter_TR12x3_screw11','增加250 mm独立退让、双导向、螺母、两端支承、联轴器和电机；反刃退出后才允许径向退刀。')
case('R02','取料与主夹的交接开口','load','loader_grip_0_frame','grip_0_0_frame','开口夹架与两侧短导向保留中央物料通道，交接始终先夹稳再松开。')
p=next(p for p in poses if p['phase']=='peel' and .08<p['q']['peel_radial']<.15)
case('R03','喷环低位进入，避开保膜夹片','peel','peel_half_guide_0_1','film_clip_post11_0_1_1','径向进出前先下降30 mm，进入后升到扫描起点；扫描完成后低位退出。',p['t'])
case('R04','清洗歧管下移并接到支承','wash','wash_manifold_-0.51_-0.065','wash_pipe_cross_-0.51','喷淋歧管、风刀和管夹分别接到实体支架；污水独立下排。')
case('R05','成袋左右旋丝杠与成形器','wrap','wrap_TR12x3_LH_RH11','wrap_former_hanger11_0_1','自制TR12×3左右旋丝杠同时驱动两侧，导杆承受横向反力；每侧240 mm开程。')
case('R06','膜套夹片与主夹连接','wrap','film_clip_arm11_0_0_1','film_clip_post11_0_0_1','膜套保持夹片固定到随主夹运动的支承；膜张力和夹持力尚需试料。')
case('R07','称重与包装分站','weigh','weigh_axis_carriage','weigh_cup_-0.51','成袋、称重、横封占三个独立工位，称重前杯托升起承接；示例读数不冒充实测。')
case('R08','横封动力与封条','seal','seal_TR12x3_LH_RH11','seal_heat_face11_0_1','两侧同步开合，头部沿独立1600 mm径向轴退让；温度、压力和膜材窗口尚未冻结。')
case('R09','封切头与卸料架错序进入','seal','seal_side_cantilever11','unload_carrier_inner_rise11','先把卸料架送入待料位置腾出通道，再进横封头；横封头退出后卸料夹才接管。')
case('R10','滑环定子接到静止约束架','feed','valve_control_slipring','slipring_fixed_restraint','滑环定子属于静止组件，转子属于回转组件；定子约束到固定供气支架。')
case('R11','成品杯托与承接座','outfeed','out_cup_6_1','out_insert_top_6_1','卸料夹松开后允许23 mm重力落座，成品杯托随盘分度输出。')
case('R12','清水只供清洗站','wash','water_tank','wash_manifold_-0.51_-0.065','取消绕其他三站的清水主管；清水从外侧水箱直接进入清洗支路，污水不回箱。')

# Show representative open candidates; the downloadable JSON retains every pair.
for i,hit in enumerate(pipes['hose_pair_candidates'][:4],1):
    cases.append(dict(id=f'P{i:02}',title='待排管：'+hit['a'],t=hit['t'],phase=hit['phase'],
      parts=[dict(name=hit['a'],route=hit['a']),dict(name=hit['b'],route=hit['b'])],resolved=False,
      evidence=f"外径包络筛查：中心线间距{hit['distance_mm']:.2f} mm，所需外径间距{hit['required_mm']:.2f} mm。",
      status='未关闭：管间距离候选',problem=hit['a']+' 与 '+hit['b']+' 的名义管外径包络相交。',
      action='须分层重新排管、落实弯曲半径与管夹，并重新做完整作业检查；本版不标为无干涉。'))

raw=(D/'cell.glb').read_bytes() if (D/'cell.glb').exists() else gzip.decompress((D/'cell.glb.gz').read_bytes())
status=f"刚体{screen['poses']}姿态检出{len(screen['rigid_candidates'])}组候选；管间{len(pipes['hose_pair_candidates'])}组、管对机械件{len(flex['capsule_contacts'])}组候选尚未关闭。"
report=dict(revision='MECHANICAL11 / PROCESS11',status=status,scope=screen['scope'],poses=screen['poses'],
  production_release=False,source_original_reconstructed_exactly=False,solidworks_runtime_tested=False,
  raw_glb_sha256=hashlib.sha256(raw).hexdigest(),pose_source_sha256=hashlib.sha256(pose_path.read_bytes()).hexdigest(),
  rigid_candidate_count=len(screen['rigid_candidates']),material_candidate_count=len(screen['extra_candidates']),unexpected_material_candidate_count=len(unexpected),
  mount_gaps_over_0p3mm=len(mount['gaps_over_0p3mm']),hose_pair_candidate_count=len(pipes['hose_pair_candidates']),
  hose_rigid_candidate_count=len(flex['capsule_contacts']),footprint_guard_outer_diameter_m=7.34,
  resolved_ids=[c['id'] for c in cases if c['resolved']],unresolved_ids=[c['id'] for c in cases if not c['resolved']],
  cautions=['刚体筛查排除同刚体、声明配合，网格表面相交不等于精确穿透体积；不能证明所有安装连接内部无干涉。',
   '带料筛查包含茎、颈、叶、外皮；膜、碎屑与流体粒子不在刚体筛查内；柔性变形和真实切削未认证。',
   '管间及管对机械件使用外径包络筛查；候选仍待精确复核和重排，不作为零干涉通过。',
   '3757个实体有效、装配树往返读取与连接距离通过，也不能代替强度、刚度、疲劳、采购件和工艺验收。',
   '本版为参数化重建设计，布局已扩展，不能作为用户原始3.24装配无修改的细化。',
   '未在原生SolidWorks中重建配合和执行运动研究；网页尚未进行真实浏览器GPU验收。'],cases=cases)
(R/'engineering/review-cases.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
(O/'assembly_review_11.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
data=json.loads((D/'mechanics.json').read_text());data['verification']=dict(status_zh=status,production_release=False,report='downloads/assembly_review_11.json')
(D/'mechanics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
esc=html.escape
rows=''.join(f"<tr><td>{esc(c['id'])}<br>{c['t']:.2f}s</td><td><b>{esc(c['title'])}</b><p>{esc(c['action'])}</p></td><td class={'pass' if c['resolved'] else 'open'}>{esc(c['status'])}<small>{esc(c['evidence'])}</small></td></tr>" for c in cases)
css=(D/'assembly-review-10.html').read_text().split('<style>')[1].split('</style>')[0]
page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>青葱工坊 · 结构修订11</title><style>{css}</style><main>
<a href="index.html">← 返回完整作业与定位检查</a><div class="eyebrow">MECHANICAL REVISION 11</div><h1>反刃、成袋与横封已实改。管路仍需重排。</h1>
<p class="lead">本版把反刃250 mm侧退、双膜成袋、左右旋丝杠、热封条、支承、联轴器与电机纳入共享CAD。网页使用相同几何与明确运动副，保留完整作业、当前工序跟随和物料跟随。</p>
<p class="status">{esc(status)} 本版不是整机工业验收通过或制造放行文件。</p>
<h2>布局和原始模型的关系</h2><p>主夹半径830 / 970 mm，外围护架直径约7.34 m。本版扩大了原始紧凑布局。它是公开尺寸依据下的参数化重建设计，未证明与3.24.SLDASM原始零件逐一一致。</p>
<h2>本轮验证</h2><p>有效CAD实体3757个，明确运动副84个，双轨丝杠轴9条。{screen['poses']}个整套作业离散姿态参与刚体及带料筛查；10001个运动采样检查行程与互锁，6次物料交接误差小于1×10⁻¹⁴ m。刚体与声明配合的排除边界见下文。</p>
<p>静态支承距离检查{mount['rigid_mounts_checked']}项，超过0.3 mm的名义间隙{len(mount['gaps_over_0p3mm'])}项。气、水和污水分别连通，168条路由的端点与实体端口核对；连通不代表避碰通过。</p>
<h2>管路尚未关闭</h2><p>管间筛查{pipes['poses']}个姿态发现{len(pipes['hose_pair_candidates'])}组候选；管对机械件筛查{flex['poses']}个姿态发现{len(flex['capsule_contacts'])}组候选。以下仅展示4组定位入口，原始JSON保留全部记录。候选需要精确复核和重新排管，不能靠隐藏管路视图当作解决。</p>
<h2>检查点与未完成项</h2><div class="scroll"><table><thead><tr><th>编号 / 时刻</th><th>实体调整或待办</th><th>证据范围</th></tr></thead><tbody>{rows}</tbody></table></div>
<h2>导入SolidWorks</h2><p>下载AP214毫米制实体装配。按文件层级导入，再保存SLDASM / SLDPRT；STEP不含原生SW配合或参数化历史。包内提供产品树、运动副与丝杠关系、介质端口及名义管长。本环境没有执行原生SW运动研究。</p>
<p><a href="downloads/Scallion_SW_Assembly_11.zip">SW装配交换包11</a> · <a href="downloads/Scallion_GLB_11.zip">展示模型GLB11</a> · <a href="downloads/Scallion_Mechanical_11.zip">设计与复查资料11</a></p>
<h2>验证边界</h2><ul>{''.join('<li>'+esc(c)+'</li>' for c in report['cautions'])}</ul>
<p><a href="downloads/full_workflow_clearance_screen_11.json">刚体与带料原始候选</a> · <a href="downloads/hose_pair_checks_11.json">全部管间候选</a> · <a href="downloads/hose_rigid_checks_11.json">全部管对机械件候选</a> · <a href="downloads/assembly_review_11.json">修订与检查点</a> · <a href="assembly-review-10.html">历史修订10</a></p>
<small>GLB SHA256：{report['raw_glb_sha256']}</small></main></html>'''
(D/'assembly-review-11.html').write_text(page)
print(status)
