"""Losslessly retain positions; pack index and unit-normal attributes for viewing."""
import struct,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'dist/downloads/SCALLION_CELL.glb';raw=p.read_bytes();ln=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+ln]);data=raw[28+ln:]
if g.get('extras',{}).get('packed_normals'):print('already packed');raise SystemExit
normals={x['attributes']['NORMAL'] for m in g['meshes'] for x in m['primitives']}
indices={x['indices'] for m in g['meshes'] for x in m['primitives']}
views=[];chunks=[];offset=0;max_error=0
for ai,a in enumerate(g['accessors']):
 v=g['bufferViews'][a['bufferView']];b=data[v.get('byteOffset',0)+a.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
 if ai in normals:
  n=np.frombuffer(b,dtype='<f4');q=np.clip(np.rint(n*127),-127,127).astype('i1');max_error=max(max_error,float(np.max(np.abs(n-q/127))));b=q.tobytes();a['componentType']=5120;a['normalized']=True;a.pop('min',None);a.pop('max',None)
 if ai in indices:
  ix=np.frombuffer(b,dtype='<u4')
  if ix.max()<65536:b=ix.astype('<u2').tobytes();a['componentType']=5123
 a['bufferView']=len(views);a.pop('byteOffset',None);views.append({'buffer':0,'byteOffset':offset,'byteLength':len(b),'target':v['target']});pad=(-len(b))%4;chunks.append(b+b'\0'*pad);offset+=len(b)+pad
blob=b''.join(chunks);g['bufferViews']=views;g['buffers']=[{'byteLength':len(blob)}]
g['extensionsUsed']=list(set(g.get('extensionsUsed',[])+['KHR_mesh_quantization']));g['extensionsRequired']=list(set(g.get('extensionsRequired',[])+['KHR_mesh_quantization']));g.setdefault('extras',{})['packed_normals']=True
body=json.dumps(g,separators=(',',':')).encode();body+=b' '*((-len(body))%4)
output=struct.pack('<III',0x46546c67,2,28+len(body)+len(blob))+struct.pack('<II',len(body),0x4e4f534a)+body+struct.pack('<II',len(blob),0x004e4942)+blob
p.write_bytes(output);(ROOT/'dist/cell.glb').write_bytes(output)
(ROOT/'dist/downloads/mesh_packing.json').write_text(json.dumps({'position_error_m':0,'normal_component_max_error':max_error,'before_bytes':len(raw),'after_bytes':len(output),'method':'unchanged float32 positions; normalized int8 normals; uint16 indices; KHR_mesh_quantization'},indent=2))
print('packed',len(raw),'->',len(output),'max normal component error',max_error)
