import os,json,numpy as np
from pathlib import Path
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from collision_engine import m
P={p['name']:p for p in m.PART};cache={};rows=[]
def sh(n):
 if n not in cache:
  p=P[n];s=m.k.shape_for(p['kind'],p['dims']).moved(m.k.GL[p['parent']]*m.k.loc(p));b=s.BoundingBox();cache[n]=(s,np.array([b.xmin,b.ymin,b.zmin]),np.array([b.xmax,b.ymax,b.zmax]))
 return cache[n]
for l in m.MOUNTS:
 a,b=l['part'],l['support']
 if '12' not in a or a not in P or b not in P or l['type'] not in ['rigid','bolted','flange']:continue
 sa,la,ha=sh(a);sb,lb,hb=sh(b);lower=float(np.linalg.norm(np.maximum(0,np.maximum(la-hb,lb-ha))))
 if lower>.0003:dist=lower
 else:q=BRepExtrema_DistShapeShape(sa.wrapped,sb.wrapped);q.Perform();dist=q.Value()
 rows.append(dict(a=a,b=b,gap_mm=dist*1000))
fail=[r for r in rows if r['gap_mm']>.3];fail.sort(key=lambda r:-r['gap_mm'])
out=dict(checked=len(rows),gap_candidates=fail,scope='New named rigid mount distances at home pose. CAD contact check only; no stiffness/fastener certification.')
(m.k.OUT/'mount12.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
