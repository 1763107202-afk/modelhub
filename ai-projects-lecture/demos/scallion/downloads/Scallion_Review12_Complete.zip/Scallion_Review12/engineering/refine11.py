"""Revision 11: independently parked counter-tool and real dry process modules.

Nominal mechanism geometry, SI metres. Custom TR12x3 drives have explicitly
declared opposite-handed nuts; no supplier part or manufacturing release is claimed.
"""
import json, math
import numpy as np
import cadquery as cq

def install(m):
    k=m.k; by={p['name']:p for p in m.PART}; gb={g['name']:g for g in m.GROUP}; old=k.shape_for
    def shape(t,d):
        key=json.dumps([t,d])
        if key in k.CQ_CACHE:return k.CQ_CACHE[key]
        if t=='straight_shear11':
            # A continuous, single-bevel edge. The previous V-notch delayed
            # centreline severing until its backing holder reached the stem.
            w,h,z=d;V=cq.Vector
            pts=[V(-w/2,y,zz) for y,zz in [(-h/2,-z/2),(h/2,-z/2),(h/2,z/2-.006),(-h/2+.0002,z/2),(-h/2,z/2),(-h/2,-z/2)]]
            s=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts),[],V(w,0,0))
            for x,zz,r in [(-w*.28,-z*.28,.0032),(w*.28,-z*.28,.0032),(0,-.026,.00301)]:
                s=s.cut(m.axis_cylinder([x,-h/2-.002,zz],[x,h/2+.002,zz],r))
        elif t=='former_half11':
            sign=d[0]
            s=m.axis_cylinder([0,.244,0],[0,.535,0],.038).cut(m.axis_cylinder([0,.243,0],[0,.536,0],.034))
            s=s.intersect(cq.Workplane('XY').box(.120,.310,.080).val().translate((0,.397,sign*.0405)))
            # Two longitudinal heated flange interfaces outside the vegetable.
            for x in [-.037,.037]:
                flange=cq.Workplane('XY').box(.012,.306,.018).val().translate((x,.397,sign*.010))
                s=s.fuse(flange)
        elif t=='counter_post11':
            # Hollow vertical post, with the upper linear guide bored through it.
            x=d[0];s=old('rhs_axis',[[x,-.200,.320],[x,-.7956,.320],.018,.002])
        else:return old(t,d)
        assert s.isValid(),t
        k.CQ_CACHE[key]=s;return s
    k.shape_for=shape
    for p in m.PART:
        if p['kind']=='knife' and p['name'].startswith(('root_blade_','trim_blade_')):p['kind']='straight_shear11'
    # The main clamp carries the vegetable; these separately connected soft clips
    # retain the open sleeve during indexing until its bottom has been sealed.
    for i in range(6):
        for l in [0,1]:
            for sign in [-1,1]:
                par=f'grip_{i}_{l}_jaw_{sign}'
                post=m.beam(f'film_clip_post11_{i}_{l}_{sign}',[0,-.006,sign*.045],[0,-.064,sign*.045],.008,par,f'grip_{i}_{l}_jaw_body_{sign}')
                arm=m.beam(f'film_clip_arm11_{i}_{l}_{sign}',[0,-.064,sign*.045],[0,-.064,sign*.0039],.008,par,post)
                m.box(f'film_clip_PU11_{i}_{l}_{sign}',(.024,.008,.004),(0,-.064,sign*.002),par,'pad',arm)

    # Six distinct process positions. Fixed tooling moves; carousel dimensions stay.
    gb['weigh_axis']['parent']='station5'
    for n in ['unload_axis','outfeed']:gb[n]['parent']='station6'
    for j in m.JOINTS:
        if j['child']=='weigh_axis':j['parent']='station5'
        if j['child']=='unload_axis':j['parent']='station6'
    for p in m.PART:
        if p['parent']=='station4' and p['name'].startswith('weigh_'):p['parent']='station5'
        if p['parent']=='station5' and p['name'].startswith(('unload_','outfeed_')):p['parent']='station6'
    gb['station4']['label']='双膜成袋与纵封'
    gb['station5']['label']='独立称重'
    gb['station6']['label']='横封熔断与成品移载'
    # Put the utility skid behind the output equipment, on its own grounded frame.
    gb['utilities']['parent']='station3';gb['utilities']['pos']=[2.20,0,0]
    gb['console']['parent']='station3';gb['console']['pos']=[2.10,0,1.00]
    for z in [-.20,.20]:
        fp=m.foot('utility_ground11_'+str(z),2.20,z,'station3')
        leg=m.tube('utility_ground_leg11_'+str(z),(.04,.021,.04),(0,.1075,z),'utilities',support=fp)
        m.contact(leg,'utility_skid_'+str(z));m.set_support('utility_skid_'+str(z),leg)
    removed={p['name'] for p in m.PART if p['parent']=='pack_oem'}
    m.PART[:]=[p for p in m.PART if p['name'] not in removed]
    m.MOUNTS[:]=[x for x in m.MOUNTS if x['part'] not in removed and x['support'] not in removed]
    m.GROUP[:]=[g for g in m.GROUP if g['name']!='pack_oem']

    # Counter reaction comes from the positive side, after the radial frame enters.
    # The former lower cross-shoe no longer traverses the uncut leaf centreline.
    ctr=m.g('trim_counter11','trim_axis_slide',label='反刃横向退让 / 独立TR12x3导向驱动')
    m.joint('trim_counter_shift','prismatic','trim_axis_slide',ctr,[0,0,1],0,.250,home=.250)
    for l,x in enumerate([-.49,-.35]):
        by['trim_counter_'+str(l)]['parent']=ctr
        by['trim_counter_'+str(l)]['pos'][2]=.040
        post=by['trim_counter_stand_'+str(l)]
        postx=-.100+.040*l
        post.update(parent=ctr,kind='counter_post11',dims=[postx],pos=[0,0,0])
        shoe=by['trim_counter_shoe_'+str(l)]
        shoe.update(parent=ctr,dims=[[x,-.7956,.320],[x,-.7956,.040],.012,.002],pos=[0,0,0])
        tie=by['trim_counter_upper_tie_'+str(l)]
        tie.update(parent=ctr,dims=[[x,-.200,.320],[-.100+.040*l,-.200,.320],.018,.002],pos=[0,0,0])
        reaction=m.beam('counter_lower_reaction11_'+str(l),[postx,-.7956,.320],[x,-.7956,.320],.018,ctr,post['name'])
        m.set_support(post['name'],tie['name']);m.set_support(shoe['name'],reaction)
    for n in ['trim_counter_support_cross','trim_counter_cross_riser_-0.4','trim_counter_cross_riser_-0.32']:
        if n in by:
            m.PART.remove(by[n]);m.MOUNTS[:]=[x for x in m.MOUNTS if x['part']!=n and x['support']!=n]
    for x in [-.40,-.32]:
        rail=m.rod('counter_guide11_'+str(x),[x,-.180,.270],[x,-.180,.900],.006,'trim_axis_slide')
        for z in [.270,.900]:
            seat=m.p('counter_guide_seat11_'+str(x)+'_'+str(z),'bored_z',[.040,.040,.025,.00605,0],(x,-.180,z),'trim_axis_slide','aluminum')
            stem=m.beam('counter_guide_stay11_'+str(x)+'_'+str(z),[x,-.337,.20],[x,-.200,z],.018,'trim_axis_slide','trim_fixed_cross')
            m.set_support(seat,stem);m.set_support(rail,seat)
        bush=m.p('counter_bush11_'+str(x),'bored_z',[.030,.040,.060,.00608,0],(x,-.180,.440),ctr,'aluminum')
        reach=m.beam('counter_bush_reach11_'+str(x),[x,-.200,.440],[x,-.200,.320],.018,ctr,'trim_counter_upper_tie_0')
        m.set_support(bush,reach)
    rotor=m.g('trim_counter_screw11','trim_axis_slide',(-.10,-.180,0))
    sh=m.rod('counter_TR12x3_screw11',[0,0,.270],[0,0,.930],.006,rotor)
    for z in [.270,.900]:
        block=m.p('counter_screw_seat11_'+str(z),'bored_z',[.040,.040,.025,.0061,0],(-.10,-.180,z),'trim_axis_slide','dark')
        stay=m.beam('counter_screw_stay11_'+str(z),[-.12,-.337,.20],[-.10,-.200,z],.018,'trim_axis_slide','trim_fixed_cross')
        m.set_support(block,stay);m.set_support(sh,block,'bearing')
    nut=m.p('counter_TR12x3_nut11','bored_z',[.034,.038,.040,.00605,0],(-.10,-.180,.440),ctr,'aluminum');m.set_support(nut,sh,'screw_nut')
    m.beam('counter_nut_reach11',[-.10,-.200,.440],[-.10,-.200,.320],.020,ctr,nut)
    m.set_support('trim_counter_upper_tie_0','counter_nut_reach11');m.set_support('trim_counter_upper_tie_1','counter_nut_reach11')
    plate=m.p('counter_motor_plate11','bored_z',[.080,.080,.006,.015,0],(-.10,-.180,.952),'trim_axis_slide','aluminum')
    stay=m.beam('counter_motor_stay11',[-.080,-.180,.900],[-.065,-.180,.952],.018,'trim_axis_slide','counter_screw_seat11_0.9');m.set_support(plate,stay)
    motor=m.p('counter_servo100W11','bored_z',[.060,.060,.090,.0051,0],(-.10,-.180,1.000),'trim_axis_slide','black',plate)
    m.ring('counter_coupling11',[0,0,.918],[0,0,.932],.012,.00605,rotor,'chrome',sh)
    m.ring('counter_motor_coupling_half11',[0,0,.932],[0,0,.945],.012,.00505,rotor,'chrome','counter_coupling11')
    m.rod('counter_motor_shaft11',[0,0,.935],[0,0,.970],.005,rotor,support='counter_motor_coupling_half11')
    m.joint('trim_counter_rotation11','revolute','trim_axis_slide',rotor,[0,0,1],-1e9,1e9,relation='theta=2*pi*(trim_counter_shift-0.250)/0.003')

    bynow={p['name']:p for p in m.PART}
    bynow['counter_screw_stay11_0.27']['dims'][0][0]=-.160
    stay=bynow['counter_screw_stay11_0.9'];stay['dims'][:2]=[[.100,-.337,.200],[.100,-.200,.900]]
    root=m.beam('counter_screw_outboard_root11',[-.160,-.337,.200],[.100,-.337,.200],.018,'trim_axis_slide','trim_fixed_cross');m.set_support(stay['name'],root)
    reach=m.beam('counter_screw_outboard_reach11',[.100,-.200,.900],[-.100,-.200,.900],.018,'trim_axis_slide',stay['name']);m.set_support('counter_screw_seat11_0.9',reach)

    # Keep stationary union restraint inside the rotary hose distributor radius.
    by['union_restraint_bracket']['dims']=[[.065,1.510,0],[.065,2.850,0],.012,.002]
    by['union_anti_rotation']['dims'][:2]=[[.054,-.020,0],[.065,-.020,0]]
    by['union_bracket_root']['dims']=[[.065,1.640,0],[.065,2.850,0],.012,.002]
    by['union_overhead_mast']['dims']=[[2.50,.10,.85],[2.50,2.850,.85],.050,.003]
    by['union_overhead_mast']['parent']='fixed'
    by['union_overhead_beam']['dims']=[[2.50,2.850,.85],[.065,2.850,0],.040,.003]
    by['union_overhead_beam']['parent']='fixed'
    mastfoot=m.foot('union_ground11',2.5,.85,top=.088)
    m.set_support('union_overhead_mast',mastfoot)
    m.set_support('union_restraint_bracket','union_overhead_beam')
    m.set_support('union_bracket_root','union_overhead_beam')

    def process_head(prefix,station,wrap):
        stroke=.750 if wrap else 1.600
        base_y=.430 if wrap else .760
        slide,bp=m.axis(prefix+'_axis','station'+str(station),(.72,base_y,0 if wrap else 1.150),stroke)
        axis_slide=slide
        fresh={p['name']:p for p in m.PART}
        fresh[prefix+'_axis_servo_200W'].update(kind='bored_x',dims=[.090,.060,.060,.0052,0])
        fresh[prefix+'_axis_CPDW32'].update(kind='step_coupling_x',dims=[])
        m.set_support(prefix+'_axis_CPDW32',prefix+'_axis_fixed_journal12');m.set_support(prefix+'_axis_locknut',prefix+'_axis_fixed_journal12')
        for p in m.PART:
            if p['name'].startswith(prefix+'_axis_endstop_'):p['pos'][1]=.0245;p['pos'][2]=.142
        fresh[prefix+'_axis_nut_housing'].update(dims=[.040,.056,.055,.01404,-.005],pos=[0,.042,0])
        for z in [-.15,.15]:
            fresh[prefix+'_axis_side_shield_'+str(z)].update(dims=[stroke+.260,.025,.002,.0003],pos=[(stroke+.260)/2,.030 if wrap else .055,math.copysign(.240,z)])
            for x in [.070,.940]:
                br=m.beam(prefix+'_shield_stay11_'+str(x)+'_'+str(z),[x,.012,math.copysign(.125,z)],[x,.030 if wrap else .055,math.copysign(.240,z)],.012,prefix+'_axis',bp)
                m.contact(br,prefix+'_axis_side_shield_'+str(z));m.set_support(prefix+'_axis_side_shield_'+str(z),br)
        # Bolted under-frame cross supports do not hang in free space.
        for x in ([.80,1.60] if wrap else [.80,1.60,2.40]):
            cross=m.tube(prefix+'_base_cross11_'+str(x),(.060,.030,.500),(x,base_y-.015,0 if wrap else 1.150),'station'+str(station),support='frame_'+str(station-1)+'_-0.22')
            if not wrap:
                for zz in [.95,1.35]:
                    xx=1.00 if x==.80 and zz==1.35 else x
                    fp=m.foot('seal_axis_ground11_'+str(x)+'_'+str(zz),xx,zz,'station6')
                    leg=m.beam('seal_axis_leg11_'+str(x)+'_'+str(zz),[xx,.097,zz],[xx,base_y-.030,zz],.040,'station6',fp);m.contact(leg,cross)
                    if xx!=x:m.beam('seal_front_leg_extension11',[x,base_y-.030,zz],[xx,base_y-.030,zz],.040,'station6',leg)
            if not wrap:m.set_support(cross,'seal_front_leg_extension11' if x==.8 else leg)
            m.set_support(bp,cross)
        if not wrap:
            slide=m.g('seal_head11',axis_slide,(0,0,-1.150))
            up=m.beam('seal_cantilever_rise11',[0,.076,0],[0,.200,0],.025,axis_slide,'seal_axis_carriage')
            cantilever=m.beam('seal_side_cantilever11',[0,.200,0],[0,.200,-1.580],.025,axis_slide,up)
            for zz in [-.430,.430]:
                link=m.beam('seal_cantilever_top_link11_'+str(zz),[0,.200,zz],[-.040,.200,zz],.020,slide,cantilever)
                drop=m.beam('seal_cantilever_drop11_'+str(zz),[-.040,.200,zz],[-.040,.0945,zz],.020,slide,link)
                m.beam('seal_cantilever_sole_link11_'+str(zz),[-.040,.0945,zz],[0,.0945,zz],.020,slide,drop)
            m.set_support('seal_axis_carriage','seal_axis_HGH20_-0.06_-0.095','linear_bearing')
        # Opposite-handed TR12x3 nuts share one screw and two separate guide rods.
        r=m.g(prefix+'_screw_rotor11',slide,(.080,.150,0))
        screw=m.rod(prefix+'_TR12x3_LH_RH11',[0,0,-.460],[0,0,.470],.006,r)
        for z in [-.430,.430]:
            sole=m.box(prefix+'_end_sole11_'+str(z),(.170,.025,.070),(.070,.0945,z),slide,support=prefix+'_axis_carriage' if wrap else 'seal_cantilever_sole_link11_'+str(z))
            if wrap:
                reach=m.beam('wrap_end_outrigger11_'+str(z),[.070,.060,math.copysign(.1249,z)],[.070,.060,z],.025,slide,'wrap_axis_carriage')
                spacer=m.box('wrap_end_spacer11_'+str(z),(.050,.010,.050),(.070,.0775,z),slide,support=reach);m.set_support(sole,spacer)
            seat=m.p(prefix+'_bearing_seat11_'+str(z),'bored_z',[.060,.065,.035,.0101,.0105],(.080,.1395,z),slide,'dark',sole)
            m.ring(prefix+'_6000_bearing11_'+str(z),[.080,.150,z-.012],[.080,.150,z+.012],.010,.00605,slide,'chrome',seat)
            m.set_support(screw,prefix+'_6000_bearing11_'+str(z),'bearing');m.contact(screw,prefix+'_6000_bearing11_'+str(z))
        for x in [.015,.145]:
            guide=m.rod(prefix+'_guide12_11_'+str(x),[x,.150,-.430],[x,.150,.430],.006,slide)
            for z in [-.430,.430]:
                block=m.p(prefix+'_guide_seat11_'+str(x)+'_'+str(z),'bored_z',[.030,.065,.035,.00604,.0105],(x,.1395,z),slide,'aluminum',prefix+'_end_sole11_'+str(z))
                m.set_support(guide,block)
        plate=m.p(prefix+'_motor_plate11','bored_z',[.080,.080,.006,.015,0],(.080,.150,.482),slide,'aluminum')
        stay=m.beam(prefix+'_motor_stay11',[.105,.150,.430],[.115,.150,.482],.018,slide,prefix+'_bearing_seat11_0.43');m.set_support(plate,stay)
        motor=m.p(prefix+'_servo200W11','bored_z',[.060,.060,.090,.0051,0],(.080,.150,.530),slide,'black',plate)
        m.rod(prefix+'_motor_shaft11',[0,0,.470],[0,0,.495],.005,r,support=screw)
        m.ring(prefix+'_shaft_coupling11',[0,0,.455],[0,0,.484],.012,.00605,r,'chrome',screw)
        m.joint(prefix+'_jaw_rotation11','revolute',slide,r,[0,0,1],-1e9,1e9,relation='theta=2*pi*('+prefix+'_jaw11_1-'+str(.240 if wrap else .080)+')/0.003')
        for sign in [-1,1]:
            jaw=m.g(prefix+'_jaw11_'+str(sign),slide)
            m.joint(prefix+'_jaw11_'+str(sign),'prismatic',slide,jaw,[0,0,sign],0,(.240 if wrap else .080),home=(.240 if wrap else .080))
            n=m.p(prefix+'_nut11_'+str(sign),'bored_z',[.034,.038,.040,.00605,0],(.080,.150,sign*.100),jaw,'aluminum');m.set_support(n,screw,'screw_nut')
            cross=m.beam(prefix+'_moving_cross11_'+str(sign),[.160,.110 if wrap else .070,sign*.100],[-.560,.110 if wrap else .070,sign*.100],.020,jaw)
            m.beam(prefix+'_nut_stem11_'+str(sign),[.080,.131,sign*.100],[.080,.110 if wrap else .070,sign*.100],.020,jaw,n);m.set_support(cross,prefix+'_nut_stem11_'+str(sign))
            for x in [.015,.145]:
                bush=m.p(prefix+'_guide_bush11_'+str(sign)+'_'+str(x),'bored_z',[.028,.030,.040,.00608,0],(x,.150,sign*.100),jaw,'aluminum')
                stay=m.beam(prefix+'_bush_stem11_'+str(sign)+'_'+str(x),[x,.135,sign*.100],[x,.110 if wrap else .070,sign*.100],.018,jaw,cross);m.set_support(bush,stay)
            for l,x in enumerate([-.510,-.370]):
                hx=x+(-.130 if l==0 else .230) if wrap else x
                post=m.beam(prefix+'_head_post11_'+str(l)+'_'+str(sign),[x+.065 if wrap else x,.110 if wrap else .070,sign*(.350 if wrap else .100)],[x+.065 if wrap else x,1.150 if wrap else -.080,sign*(.350 if wrap else .100)],.016,jaw,cross)
                arm=m.beam(prefix+'_head_reach11_'+str(l)+'_'+str(sign),[x+.065 if wrap else x,1.150 if wrap else -.080,sign*(.350 if wrap else .100)],[hx,1.150 if wrap else -.080,sign*(.060 if wrap else .015)],.012,jaw,post)
                if wrap:
                    lower=m.beam('wrap_lower_reach11_'+str(l)+'_'+str(sign),[x+.065,.110,sign*.100],[x+.065,.110,sign*.350],.016,jaw,cross);m.set_support(post,lower)
                    hanger=m.beam('wrap_former_hanger11_'+str(l)+'_'+str(sign),[hx,1.150,sign*.060],[hx,.524,sign*.060],.012,jaw,arm)
                    hanger=m.beam('wrap_former_lower_link11_'+str(l)+'_'+str(sign),[hx,.524,sign*.060],[x-.037,.524,sign*.060],.012,jaw,hanger)
                    hanger=m.beam('wrap_former_tangent_link11_'+str(l)+'_'+str(sign),[x-.037,.524,sign*.060],[x-.037,.524,sign*.010],.012,jaw,hanger)
                    former=m.p('wrap_former11_'+str(l)+'_'+str(sign),'former_half11',[sign],(x,0,0),jaw,'chrome',hanger)
                    for dx in [-.037,.037]:
                        m.box('wrap_longitudinal_heater11_'+str(l)+'_'+str(sign)+'_'+str(dx),(.0015,.306,.002),(x+dx,.397,sign*.00105),jaw,'orange',former)
                        m.box(('wrap_cut_edge11_' if sign<0 else 'wrap_cut_anvil11_')+str(l)+'_'+str(dx),(.002,.306,.003),(x+math.copysign(.0435,dx),.397,sign*.00155),jaw,'chrome',former)
                else:
                    bar=m.box('seal_backbar11_'+str(l)+'_'+str(sign),(.110,.008,.012),(x,-.080,sign*.00905),jaw,'aluminum',arm)
                    m.box('seal_heat_face11_'+str(l)+'_'+str(sign),(.110,.008,.003),(x,-.080,sign*.00155),jaw,'orange',bar)
                    if sign<0:m.box('seal_cut_wire11_'+str(l),(.110,.00015,.00015),(x,-.0825,-.00015),jaw,'chrome','seal_heat_face11_'+str(l)+'_'+str(sign))
        if wrap:
            # Four vertical reels feed two opposing webs into the forming jaws.
            for sign in [-1,1]:
                out=m.beam('wrap_reel_upper_outrigger11_'+str(sign),[0,.080,sign*.120],[0,.080,sign*.180],.016,slide,'wrap_axis_carriage')
                drop=m.beam('wrap_reel_outer_drop11_'+str(sign),[0,.080,sign*.180],[0,.055,sign*.180],.016,slide,out)
                under=m.beam('wrap_reel_under_reach11_'+str(sign),[0,.055,sign*.180],[.020,.055,sign*.560],.016,slide,drop)
                m.beam('wrap_reel_lower_drop11_'+str(sign),[.020,.055,sign*.560],[.020,.020,sign*.560],.016,slide,under)
            for l,x in enumerate([.340,.480]):
                for sign in [-1,1]:
                    stem=m.beam('film_reel_stand11_'+str(l)+'_'+str(sign),[.02,.020,sign*.560],[x,.020,sign*.560],.020,slide,'wrap_reel_lower_drop11_'+str(sign))
                    shaft=m.rod('film_reel_shaft11_'+str(l)+'_'+str(sign),[x,.210,sign*.500],[x,.565,sign*.500],.006,slide)
                    for y in [.220,.555]:
                        bracket=m.beam('film_reel_bracket11_'+str(l)+'_'+str(sign)+'_'+str(y),[x,.020,sign*.560],[x,y,sign*.560],.016,slide,stem)
                        reach=m.beam('film_reel_bearing_reach11_'+str(l)+'_'+str(sign)+'_'+str(y),[x,y,sign*.560],[x,y,sign*.515],.018,slide,bracket)
                        seat=m.ring('film_reel_bearing11_'+str(l)+'_'+str(sign)+'_'+str(y),[x,y-.008,sign*.500],[x,y+.008,sign*.500],.015,.0061,slide,'dark',reach)
                        m.set_support(shaft,seat,'bearing')
                    reel=m.g('film_reel11_'+str(l)+'_'+str(sign),slide,(x,0,sign*.500))
                    m.ring('film_roll11_'+str(l)+'_'+str(sign),[0,.235,0],[0,.541,0],.040,.0061,reel,'paper',shaft)
                    m.joint('film_feed11_'+str(l)+'_'+str(sign),'revolute',slide,reel,[0,1,0],-1e9,1e9)
                    m.ring('film_reel_brake11_'+str(l)+'_'+str(sign),[x,.205,sign*.500],[x,.212,sign*.500],.018,.0061,slide,'dark',shaft)
                    for z in [sign*.300,sign*.328]:
                        nip=m.g('film_nip11_'+str(l)+'_'+str(z),slide,(x,0,z))
                        m.rod('film_nip_shaft11_'+str(l)+'_'+str(z),[0,.205 if abs(abs(z)-.300)<1e-8 else .215,0],[0,.565,0],.004,nip)
                        m.ring('film_nip_roller11_'+str(l)+'_'+str(z),[0,.235,0],[0,.541,0],.012,.0041,nip,'rubber','film_nip_shaft11_'+str(l)+'_'+str(z))
                        for y in [.220,.555]:
                            side=m.beam('film_nip_side11_'+str(l)+'_'+str(z)+'_'+str(y),[x+.015,y,sign*.500],[x+.035,y,sign*.500],.010,slide,'film_reel_bearing11_'+str(l)+'_'+str(sign)+'_'+str(y))
                            out=m.beam('film_nip_outboard11_'+str(l)+'_'+str(z)+'_'+str(y),[x+.035,y,sign*.500],[x+.035,y,z],.010,slide,side)
                            br=m.beam('film_nip_stay11_'+str(l)+'_'+str(z)+'_'+str(y),[x+.035,y,z],[x+.0079,y,z],.010,slide,out)
                            m.ring('film_nip_bearing11_'+str(l)+'_'+str(z)+'_'+str(y),[x,y-.005,z],[x,y+.005,z],.008,.0041,slide,'dark',br)
                            m.set_support('film_nip_shaft11_'+str(l)+'_'+str(z),'film_nip_bearing11_'+str(l)+'_'+str(z)+'_'+str(y),'bearing')
                        m.joint('film_nip_drive11_'+str(l)+'_'+str(z),'revolute',slide,nip,[0,1,0],-1e9,1e9,relation='film rolling contact; inner nip driven, outer nip idler')
                        if abs(abs(z)-.300)<1e-8:
                            plate=m.plate('film_nip_motor_plate11_'+str(l)+'_'+str(sign),(.070,.008,.060),(x,.1655,z),slide,holes=[[0,0,.0041]])
                            side=m.beam('film_nip_motor_stay11_'+str(l)+'_'+str(sign),[x-.010,.020,sign*.560],[x+.030,.1655,z],.012,slide,stem);m.set_support(plate,side)
                            motor=m.p('film_nip_motor60W11_'+str(l)+'_'+str(sign),'drilled',[.040,.045,.040,[[0,0,.0041]]],(x,.192,z),slide,'black',plate)

        return slide
    process_head('wrap',4,True)
    process_head('seal',6,False)
    by['feed_spindle_hub']['dims'][0][1]+=.001;by['feed_spindle_hub']['dims'][1][1]+=.001
    for y in [.590,.940]:
        for j in range(12):
            ball=f'main_6208_ball_{y}_{j}'
            if ball in by:m.contact(ball,'main_6208_inner_'+str(y))
    # Keep neighbouring 60-degree tool sectors physically separated. This is an
    # explicit 500mm radial layout change, recorded in the review and SW guide.
    radial=.500
    for i in range(6):
        g=gb['station'+str(i+1)];a=math.radians(g['yaw']);g['pos']=[radial*math.cos(a),0,-radial*math.sin(a)]
        for g in m.GROUP:
            if g['parent']=='carrier_'+str(i):g['pos'][0]+=radial
        for p in m.PART:
            if p['parent']=='carrier_'+str(i):
                if p['name']=='arm_'+str(i):p['dims'][0]+=radial;p['pos'][0]+=radial/2
                elif not p['name'].startswith('arm_bolt_'):p['pos'][0]+=radial
        sp=by['central_spoke_'+str(i)];sp['dims'][0]+=radial;sp['pos'][0]-=radial/2
        for y in [.18,.40]:
            p=by['hex_frame_'+str(i)+'_'+str(y)]
            for q in p['dims'][:2]:q[0]*=(1.15+radial)/1.15;q[2]*=(1.15+radial)/1.15
        p=by['guard_post_'+str(i)]
        for q in p['dims'][:2]:q[0]*=3.65/2.45;q[2]*=3.65/2.45
        for p in m.PART:
            if p['name'].startswith('outer_guard_foot_'+str(i)+'_'):p['pos'][0]*=3.65/2.45;p['pos'][2]*=3.65/2.45
    by['guard_top_ring']['dims'][:2]=[3.630,3.670]
    for a in [0,120,240]:
        panel=by['base_panel_mount_'+str(a)];panel['pos'][0]-=.5;panel['pos'][1]=.420
        index=int(panel['parent'].replace('station',''))-1;m.set_support(panel['name'],'central_spoke_'+str(index))
    for p in m.PART:
        if p.get('support'):
            mapping=('frame_3_','frame_4_') if p['name'].startswith('weigh') else ('frame_4_','frame_5_') if p['name'].startswith('unload') else None
            if mapping and p['support'].startswith(mapping[0]):m.set_support(p['name'],p['support'].replace(*mapping,1))
    m._pre_services_parts11={p['name'] for p in m.PART}
    # Every added group must precede its descendants in the exported assembly.
    m.apply_home()

def after_services(m):
    # Moved equipment takes its fixed supply from its actual station ancestor.
    ports=m.SERVICES['ports'];routes=m.SERVICES['routes']
    for r in routes:
        if r['name']=='lead_fixed_supply_weigh_axis_slide':r['start']='A_STATION_4'
        if r['name']=='lead_fixed_supply_unload_axis_slide':r['start']='A_STATION_5'
    # Routed point snapshots are regenerated by routing11 after the final pose.
    from routing11 import install
    install(m)
