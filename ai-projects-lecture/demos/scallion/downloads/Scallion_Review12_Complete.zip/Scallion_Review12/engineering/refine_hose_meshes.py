"""Use parallel-transport circular sections for CAD hose viewing LOD.
The STEP BREP is unchanged. This removes flattening caused by a fixed binormal.
"""
import json,struct
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];p=R/'dist/cell.glb';raw=p.read_bytes();ln=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+ln]);data=bytearray(raw[28+ln:]);parts={p['name']:p for p in json.loads((R/'engineering/scene_manifest.json').read_text())['parts']}
assert not g.get('extras',{}).get('packed_normals'),'Run before compact_glb.py'
def arr(ai,cols):
 a=g['accessors'][ai];v=g['bufferViews'][a['bufferView']];return np.frombuffer(data,dtype='<f4',count=a['count']*cols,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,cols)
seen=set();n=0;error=0
for node in g['nodes']:
 part=parts.get(node['name'])
 if not part or part['kind']!='service_tube' or node['mesh'] in seen:continue
 seen.add(node['mesh']);prim=g['meshes'][node['mesh']]['primitives'][0];pts,ro,ri=part['dims'][:3];pts=np.array(pts);tang=np.gradient(pts,axis=0);tang/=np.maximum(np.linalg.norm(tang,axis=1)[:,None],1e-14);frames=[];prev=None
 for t in tang:
  axis=prev if prev is not None else np.eye(3)[np.argmin(np.abs(t))];v=axis-t*np.dot(axis,t)
  if np.linalg.norm(v)<1e-8:v=np.eye(3)[np.argmin(np.abs(t))];v-=t*np.dot(v,t)
  v/=np.linalg.norm(v);b=np.cross(t,v);frames.append((v,b));prev=v
 vv=np.array([q+r*(a*np.cos(th)+b*np.sin(th)) for r in [ro,ri] for q,(a,b) in zip(pts,frames) for th in np.arange(10)*np.pi/5],dtype='<f4');positions=arr(prim['attributes']['POSITION'],3);assert positions.shape==vv.shape;positions[:]=vv
 for radius,layer in [(ro,0),(ri,1)]:error=max(error,float(np.max(np.abs(np.linalg.norm(vv[layer*len(pts)*10:(layer+1)*len(pts)*10].reshape(-1,10,3)-pts[:,None,:],axis=2)-radius))))
 ai=g['accessors'][prim['indices']];view=g['bufferViews'][ai['bufferView']];ix=np.frombuffer(data,dtype='<u4',count=ai['count'],offset=view.get('byteOffset',0)).reshape(-1,3);faces=vv[ix];nr=np.cross(faces[:,1]-faces[:,0],faces[:,2]-faces[:,0]);norm=np.zeros_like(vv)
 for col in range(3):np.add.at(norm,ix[:,col],nr)
 norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-20);arr(prim['attributes']['NORMAL'],3)[:]=norm
 a=g['accessors'][prim['attributes']['POSITION']];a['min']=vv.min(axis=0).tolist();a['max']=vv.max(axis=0).tolist();n+=1
body=json.dumps(g,separators=(',',':')).encode();body+=b' '*(-len(body)%4);output=struct.pack('<III',0x46546c67,2,28+len(body)+len(data))+struct.pack('<II',len(body),0x4e4f534a)+body+struct.pack('<II',len(data),0x004e4942)+data
p.write_bytes(output);(R/'dist/downloads/SCALLION_CELL.glb').write_bytes(output)
(R/'dist/downloads/hose_mesh_checks.json').write_text(json.dumps(dict(hose_meshes=n,max_outer_inner_radius_error_m=error,method='Parallel transport circular sections on the nominal centreline; BREP unchanged.'),indent=2));print('refined hose meshes',n,'max radius residual',error)
