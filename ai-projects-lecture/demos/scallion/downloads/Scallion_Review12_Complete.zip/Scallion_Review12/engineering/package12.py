from pathlib import Path
import json,csv,zipfile,hashlib,shutil
import cadquery as cq
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence,TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.IFSelect import IFSelect_RetDone
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads';S=R/'sw_exchange_12';S.mkdir(exist_ok=True)
step=O/'SCALLION_CELL_concept_mm.step';doc=TDocStd_Document(TCollection_ExtendedString('SW_STEP_CHECK12'));rd=STEPCAFControl_Reader();rd.SetNameMode(True);rd.SetColorMode(True)
assert rd.ReadFile(str(step))==IFSelect_RetDone;assert rd.Transfer(doc)
tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());roots=TDF_LabelSequence();tool.GetFreeShapes(roots)
def name(label):
 a=TDataStd_Name();return a.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(),a) else ''
nodes=[];leaves=[]
def walk(label,path=(),depth=0):
 ref=TDF_Label();target=label
 if tool.IsReference_s(label):tool.GetReferredShape_s(label,ref);target=ref
 n=(name(target) if tool.IsAssembly_s(target) else name(label)) or name(target);path=path+(n,)
 if tool.IsAssembly_s(target):
  comps=TDF_LabelSequence();tool.GetComponents_s(target,comps,False);nodes.append(dict(name=n,depth=depth,children=comps.Length(),path='/'.join(path)))
  for i in range(1,comps.Length()+1):walk(comps.Value(i),path,depth+1)
 else:
  s=cq.Shape.cast(tool.GetShape_s(target));leaves.append(dict(name=n,depth=depth,solids=len(s.Solids()),path='/'.join(path)))
for i in range(1,roots.Length()+1):walk(roots.Value(i))
manifest=json.loads((R/'engineering/scene_manifest.json').read_text());cad=[p for p in manifest['parts'] if p['cad']]
expected={p['name'].replace('.','p').replace('-','m') for p in cad};assert {p['name'] for p in leaves}==expected
assert len(leaves)==len(cad);assert 'AUTOMOTIVE_DESIGN' in step.read_text()[:1000]
check=dict(schema='AP214 AUTOMOTIVE_DESIGN',unit='mm',root_products=roots.Length(),subassemblies=len(nodes),leaf_components=len(leaves),solid_occurrences=sum(x['solids'] for x in leaves),product_depth=max(x['depth'] for x in leaves),all_names_preserved=True,sha256=hashlib.sha256(step.read_bytes()).hexdigest(),solidworks_tested=False,native_mates=False)
(O/'sw_assembly_checks12.json').write_text(json.dumps(check,ensure_ascii=False,indent=2));shutil.copy2(step,S/'SCALLION_ASSEMBLY_12_AP214_MM.step')
with (S/'COMPONENT_TREE.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['name','depth','solids','path']);w.writeheader();w.writerows(leaves)
data=json.loads((D/'mechanics.json').read_text())
with (S/'SW_MATE_PLAN.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['运动副','类型','固定父组件','移动组件','父坐标轴','下限_mm或rad','上限_mm或rad','初始位置_mm或rad','备注'])
 for j in data['joints']:
  scale=1000 if j['type']=='prismatic' else 1;w.writerow([j['name'],j['type'],j['parent'],j['child'],json.dumps(j['axis']),j['limits'][0]*scale,j['limits'][1]*scale,j.get('home',0)*scale,j.get('relation','需在SW中建立原生配合')])
with (S/'MEDIA_PORTS.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['端口','介质','父组件','X_mm','Y_mm','Z_mm','连接部件'])
 for n,p in data['services']['ports'].items():w.writerow([n,p['medium'],p['parent'],*[x*1000 for x in p['point']],p['body']])
(S/'先读我_SW装配导入说明.md').write_text('''# 青葱工坊 · 机械修订12装配交换包

本包来自用户提供的修订11工程，包含新增输送定距/翻转上料、独立连袋检重、低位封底、升降移载与直立收集结构。尺寸是名义设计值，采购件内部简化。

## 文件内容

SCALLION_ASSEMBLY_12_AP214_MM.step：毫米制AP214实体装配，保留产品树、零件命名、分色。它不是后缀改名的SLDASM，也不包含SW原生特征历史、原生配合或已经求解的SW运动研究。
COMPONENT_TREE.csv：组件层级。
SW_MATE_PLAN.csv：移动子装配、坐标轴、行程、丝杠关系。
MEDIA_PORTS.csv：既有气水路接口；新增上料/升降的拖链与阀管仍需工程定型。
review12_checks.json：本轮动作与交接检查；sw_assembly_checks12.json：STEP重读检查。

## 在SolidWorks中打开

1. 整包解压到一个新文件夹。在SW选择“文件→打开”，文件类型选STEP，点“选项”。
2. 将STEP装配结构映射保持为“Default (As per the file)”或该版本对应的“按照文件”；采用毫米。避免选择“全部导入为单一零件”。
3. 若3D Interconnect方式只生成外部引用，可按当前版本的导入选项关闭它后重新导入，或使用该版本支持的断开链接命令。
4. 导入后展开左侧产品树，核对station1～station6、infeed_X12、unload_Z12、outfeed等子装配。先另存为.SLDASM，再按SW提示保存/外部化各组件为.SLDPRT，保留关联文件在同一目录。
5. 要运行SW运动研究，先按SW_MATE_PLAN建立真实配合和限位；网页动画不会自动转换成SW配合。

本环境没有运行SolidWorks，因此没有交付冒充原生格式的SLDASM，也未验证你的SW版本的导入对话框。官方STEP导入说明：https://help.solidworks.com/2026/english/SolidWorks/sldworks/t_reading_step_iges_acis_sw.htm

## 动作与工艺

定向来料输送→翻转夹持90度→托杯接管→切根→主夹接管→剪叶→去皮→冲洗→关水滴沥→风刀表面除水→套袋纵封切片、底封保压冷却→独立连袋检重→封口复检→升降从上方装入收集杯→松夹→成品盘30度分度。
包装为顶部开口、底部热封的套袋；不是全密封或真空包装。本版显示单袋毛重；净重应扣除实测袋重。不含按500g目标自动组合若干根的配料机构。
24位收集盘满后停止，等待取料；没有虚构自动换盘。输送带上游需根向一致的来料；任意散乱料的解缠、方向纠错与整线实料成功率尚未验证。

## 未关闭事项

原修订11的管间196组、管对机械件136组候选不能因改版视为消失。新增/变更刚体的检查结果见rigid_screen12.json；FCL表面相交只能作为复核候选。软膜褶皱、软管变形、整机连续碰撞、夹持湿态试验、热封温压、导轨挠度、电气与PLC安全回路、食品接触与清洗卫生仍未完成验收。本版是可复核的设计迭代，不能标记为整机零干涉或直接制造放行。
''',encoding='utf-8')
for n in ['geometry_verification.json','sw_assembly_checks12.json','review12_checks.json','timeline12.json','rigid_screen12.json','mount12.json','review12_conclusion.md','baseline_review_11.json']:
 if (O/n).exists():shutil.copy2(O/n,S/n)
out=O/'Scallion_SW_Assembly_12.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in S.iterdir():z.write(f,'Scallion_SW_Assembly_12/'+f.name)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps(check,indent=2));print('ZIP',out.stat().st_size,flush=True)
