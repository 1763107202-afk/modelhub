"""Public-reference mechanical redesign, SI metres.
Rigid components, explicit bearing/guide joints, and declared design assumptions.
Catalogued interfaces are distinguished from custom nominal geometry.
"""
from pathlib import Path
import math,json,struct,copy
import numpy as np
import cadquery as cq
import kernel as k
from shapes import refined_shape
ROOT=Path(__file__).resolve().parents[1]
k.shape_for=refined_shape
k.MATS.update({'chrome':dict(color='#d7e0e6',metal=.98,rough=.17,density=7930),'rubber':dict(color='#26333a',metal=.02,rough=.8,density=1150),'water':dict(color='#42b5c4',metal=.08,rough=.26,density=1150)})
k.MATS['steel'].update(color='#bfcbd0',metal=.88,rough=.28)
k.MATS['green'].update(color='#15594e',metal=.5,rough=.28)
GROUP=k.GROUPS; PART=k.PARTS
JOINTS=[]; AXES=[]; CYL=[]; MOUNTS=[]; CONTACTS=[]
oldshape=k.shape_for

def axis_cylinder(a,b,r):
 a,b=cq.Vector(*a),cq.Vector(*b);v=b-a
 return cq.Solid.makeCylinder(r,v.Length,a,v.normalized())
def shape(t,d):
 key=json.dumps([t,d])
 if key in k.CQ_CACHE:return k.CQ_CACHE[key]
 if t=='bored_x':
  w,h,z,r,dy=d;s=cq.Workplane('XY').box(w,h,z).val().cut(axis_cylinder([-w/2-.002,dy,0],[w/2+.002,dy,0],r))
 elif t=='hgh20':
  s=cq.Workplane('XY').box(.0775,.026,.044).val()
  # Rail running clearance is intentional; the balls are not modelled.
  s=s.cut(cq.Workplane('XY').box(.080,.020,.02008).val().translate((0,-.009,0)))
  for x in [-.018,.018]:
   for z in [-.016,.016]:s=s.cut(axis_cylinder([x,.014,z],[x,.006,z],.0021))
 elif t=='rail20':
  L=d[0];s=cq.Workplane('XY').box(L,.0175,.020).val()
  for x in np.arange(-L/2+.03,L/2-.015,.060):
   s=s.cut(axis_cylinder([x,-.010,0],[x,.010,0],.003));s=s.cut(axis_cylinder([x,.00876,0],[x,.00025,0],.00475))
 elif t=='jaw_block':
  s=cq.Workplane('XY').box(.090,.026,.015).val()
  for x in [-.036,.036]:s=s.cut(axis_cylinder([x,0,-.010],[x,0,.010],.00402))
 elif t=='step_coupling_x':
  s=axis_cylinder([-.075,0,0],[-.035,0,0],.016).cut(axis_cylinder([-.076,0,0],[-.055,0,0],.00502)).cut(axis_cylinder([-.055,0,0],[-.034,0,0],.00602))
 elif t=='bored_z':
  w,h,z,r,dy=d;s=cq.Workplane('XY').box(w,h,z).val().cut(axis_cylinder([0,dy,-z/2-.002],[0,dy,z/2+.002],r))
 elif t=='shellbox':
  w,h,z,wall=d;s=cq.Workplane('XY').box(w,h,z).val().cut(cq.Workplane('XY').box(w-2*wall,h-2*wall,z-2*wall).val())
 elif t=='guidedbody':
  w,h,z=d;s=cq.Workplane('XY').box(w,h,z).val()
  for x,r in [(0,.018),(-.025,.00901),(.025,.00901)]:s=s.cut(axis_cylinder([x,-h/2-.002,0],[x,h/2+.002,0],r))
 elif t=='cup':
  ri,ro,h=d;s=axis_cylinder([0,0,0],[0,h,0],ro).cut(axis_cylinder([0,.004,0],[0,h+.002,0],ri))
 elif t=='sloped_tray':
  w,z,t,fall,ox,oz,rr=d
  # Four ruled panels slope from the rim towards the perforated low collection area.
  outer=[[-w/2,fall,-z/2],[w/2,fall,-z/2],[w/2,fall,z/2],[-w/2,fall,z/2]]
  inner=[[ox-.035,0,oz-.035],[ox+.035,0,oz-.035],[ox+.035,0,oz+.035],[ox-.035,0,oz+.035]]
  panels=[]
  for i in range(4):
   q=[outer[i],outer[(i+1)%4],inner[(i+1)%4],inner[i]]
   panels.append(cq.Solid.extrudeLinear(cq.Wire.makePolygon([cq.Vector(*v) for v in q]+[cq.Vector(*q[0])]),[],cq.Vector(0,-t,0)))
  s=cq.Compound.makeCompound(panels+[cq.Workplane('XY').box(.07,t,.07).val().translate((ox,-t/2,oz)).cut(axis_cylinder([ox,-t-.001,oz],[ox,.001,oz],rr))])
 elif t=='rhs_axis':
  a,b,w,twall=d;a,b=np.array(a),np.array(b);v=b-a;L=np.linalg.norm(v);u=v/L
  s=oldshape('rhs_round',[w,L,w,twall]);
  va=np.cross([0,1,0],u);angle=math.degrees(math.acos(np.clip(u[1],-1,1)))
  if np.linalg.norm(va)>1e-8:s=s.rotate((0,0,0),tuple(va),angle)
  s=s.translate(tuple((a+b)/2))
 else:return oldshape(t,d)
 if not s.isValid():raise ValueError(t)
 k.CQ_CACHE[key]=s;return s
k.shape_for=shape

def g(n,p='fixed',pos=(0,0,0),yaw=0,roll=0,label=None,station=0):
 k.group(n,p,pos,yaw,station,label);GROUP[-1]['roll']=roll;return n

def p(n,t,ds,pos=(0,0,0),parent='fixed',mat='steel',support=None,join='rigid',cad=True):
 v=k.part(n,t,ds,pos,mat=mat,parent=parent,cad=cad)
 v['support']=support;v['connection']=join
 if support:MOUNTS.append({'part':n,'support':support,'type':join})
 return n

def box(n,ds,at,parent='fixed',mat='steel',support=None):return p(n,'softbox',[*ds,min(.001,min(ds)*.15)],at,parent,mat,support)
def tube(n,ds,at,parent='fixed',support=None):return p(n,'rhs_round',[*ds,.003],at,parent,support=support)
def beam(n,a,b,w=.06,parent='fixed',support=None):return p(n,'rhs_axis',[list(a),list(b),w,min(.003,w*.15)],parent=parent,support=support)
def rod(n,a,b,r,parent='fixed',mat='chrome',support=None):return p(n,'rod',[list(a),list(b),r],parent=parent,mat=mat,support=support)
def ring(n,a,b,ro,ri,parent='fixed',mat='steel',support=None):return p(n,'axisring',[list(a),list(b),ro,ri],parent=parent,mat=mat,support=support)
def plate(n,ds,at,parent='fixed',holes=(),support=None):return p(n,'drilled',[*ds,list(holes)],at,parent,support=support)
def bolt(n,at,parent='fixed',r=.003,L=.02,support=None):return p(n,'socket_bolt',[r,L],at,parent,'dark',support)
def contact(a,b,allow=.00025):CONTACTS.append({'a':a,'b':b,'limit_m':allow})
def joint(n,kind,parent,child,axis,lo,hi,**kw):
 JOINTS.append(dict(name=n,type=kind,parent=parent,child=child,axis=list(axis),limits=[lo,hi],**kw))
def foot(n,x,z,parent='fixed',top=.085):
 pad=p(n+'_pad','cyl',[.043,.016],(x,.008,z),parent,'rubber',join='ground')
 screw=p(n+'_M20','cyl',[.010,top-.012],(x,(top+.012)/2,z),parent,'chrome',pad,'threaded')
 p(n+'_nut','hexnut',[.017,.012],(x,top-.009,z),parent,'steel',screw,'threaded')
 fp=plate(n+'_plate',(.09,.012,.09),(x,top+.006,z),parent,support=screw)
 contact(pad,screw);contact(screw,fp);return fp

def axis(n,parent,at,stroke,qhome=None,roll=0,yaw=0):
 """Two HGR20, four HGH20CA, R16-05, BK12/BF12, CPDW32 nominal drive."""
 if qhome is None:qhome=stroke
 base=g(n,parent,at,yaw,roll,label=n+' / 1605 + HGR20')
 L=stroke+.26
 bp=plate(n+'_base', (L+.18,.012,.27),((L-.08)/2,.006,0),base)
 for z in [-.095,.095]:
  ped=box(n+'_rail_pad_'+str(z),(L,.028,.030),(L/2,.026,z),base,support=bp)
  rail=p(n+'_HGR20_'+str(z),'rail20',[L],(L/2,.04875,z),base,'dark',ped)
  contact(ped,rail)
  for j,x in enumerate(np.arange(.03,L-.015,.06)):bolt(n+'_rail_M6_'+str(z)+'_'+str(j),(x,.043,z),base,r=.003,L=.022,support=rail)
 for side,x,w,ri in [('BK12',.020,.025,.006),('BF12',L-.020,.020,.005)]:
  # Official block height43, shaft height25; this datum preserves the offset.
  h=p(n+'_'+side,'bored_x',[w,.043,.060,.01401,.0035],(x,.0335,0),base,'dark',bp)
  contact(h,bp)
  ring(n+'_'+side+'_bearing',[x-w*.30,.037,0],[x+w*.30,.037,0],.014,ri+.00002,base,'chrome',h)
  for z in [-.023,.023]:bolt(n+'_'+side+'_M5_'+str(z),(x,.021,z),base,r=.0025,L=.018,support=h)
 screw=g(n+'_rotor',base,pos=(0,.037,0),label='丝杠与联轴器旋转；5 mm / rev')
 sh=rod(n+'_1605_screw',[.050,0,0],[L-.050,0,0],.008,screw)
 rod(n+'_fixed_journal12',[-.055,0,0],[.050,0,0],.006,screw,support=sh)
 rod(n+'_floating_journal10',[L-.050,0,0],[L+.008,0,0],.005,screw,support=sh)
 ring(n+'_locknut',[-.003,0,0],[.008,0,0],.010,.00602,screw,'dark',sh)
 cp=ring(n+'_CPDW32',[-.075,0,0],[-.035,0,0],.016,.00602,screw,'aluminum',sh)
 for x in [-.061,-.048]:ring(n+'_diaphragm_'+str(x),[x-.001,0,0],[x+.001,0,0],.017,.008,screw,'chrome',cp)
 rod(n+'_motor_shaft10',[-.090,0,0],[-.055,0,0],.005,screw,support=cp)
 br=p(n+'_motor_mount','bored_x',[.010,.080,.090,.018,-.003],(-.080,.040,0),base,'steel',bp)
 box(n+'_servo_200W',(.090,.060,.060),(-.130,.037,0),base,'black',br)
 for z in [-.031,.031]:box(n+'_motor_fins_'+str(z),(.072,.047,.003),(-.135,.037,z),base,'dark',n+'_servo_200W')
 box(n+'_encoder',(.025,.045,.045),(-.185,.037,0),base,'black',n+'_servo_200W')
 # Slider origin is independent of its installation plate; no extra Y degree of freedom.
 carriage=g(n+'_slide',base,(.12+qhome,0,0),label='双轨四滑块承载移动架')
 joint(n,'prismatic',base,carriage,[1,0,0],0,stroke,home=qhome,offset=[.12,0,0],drive=screw,lead=.005)
 joint(n+'_screw','revolute',base,screw,[1,0,0],-1e9,1e9,relation='theta=2*pi*q/0.005')
 moving=plate(n+'_carriage',(.240,.012,.25),(0,.076,0),carriage)
 for x in [-.06,.06]:
  for z in [-.095,.095]:
   bl=p(n+'_HGH20_'+str(x)+'_'+str(z),'hgh20',[],(x,.057,z),carriage,'aluminum',moving,'linear_bearing')
   for dx in [-.018,.018]:
    for dz in [-.016,.016]:bolt(n+'_block_M5_'+str(x)+'_'+str(z)+'_'+str(dx)+'_'+str(dz),(x+dx,.075,z+dz),carriage,r=.0025,L=.018,support=bl)
 nut=ring(n+'_R16_05_nut',[-.020,.037,0],[.020,.037,0],.014,.00802,carriage,'chrome')
 ring(n+'_nut_flange',[.020,.037,0],[.030,.037,0],.024,.00802,carriage,'chrome',nut)
 carrier=p(n+'_nut_housing','bored_x',[.040,.058,.055,.01404,-.004],(0,.041,0),carriage,'aluminum',moving)
 contact(carrier,moving)
 for z in [-.019,.019]:
  rod(n+'_nut_fix_M5_'+str(z),[.016,.037,z],[.035,.037,z],.0025,carriage,'dark',n+'_nut_flange')
 for x in [.035,L-.035]:box(n+'_endstop_'+str(x),(.012,.025,.020),(x,.025,.145),base,'orange',bp)
 for z in [-.15,.15]:box(n+'_side_shield_'+str(z),(L,.090,.002),(L/2,.057,z),base,'glass',bp)
 AXES.append(dict(name=n,base=base,slide=carriage,rotor=screw,stroke=stroke,home=qhome,lead=.005,L=L,shaft_axis=[0,.037,0],rail_separation=.190,carriage_centres=.120,guide='HGR20/HGH20CA',nut='R16-05T3-DEB',support='BK12/BF12',mount=bp))
 return carriage,bp

def cylinder(n,parent,child,rear,nose,end,bore=.025,stroke=.04,axis_dir=None):
 """A rigid piston rod moves with the load and stays inserted in both end states."""
 a,b,e=map(lambda v:np.array(v,float),(rear,nose,end));u=(b-a)/np.linalg.norm(b-a)
 r=bore/2;ro=r+.003
 rr=.0125 if bore>=.08 else .010 if bore>=.063 else .006 if bore>=.025 else .005 if bore>=.020 else .003
 barrel=ring(n+'_barrel',a,b,ro,r,parent,'blue')
 for j,c in enumerate([a,b]):
  if j==0:rod(n+'_cap_0',c-u*.006,c+u*.006,ro+.003,parent,'aluminum',barrel)
  else:ring(n+'_cap_1',c-u*.006,c+u*.006,ro+.003,rr+.0001,parent,'aluminum',barrel)
 for side in [-1,1]:
  # Side tie rods are an assembly depiction; ports are on the stationary shell.
  v=np.cross(u,[0,1,0] if abs(u[1])<.9 else [1,0,0]);v/=np.linalg.norm(v)
  rod(n+'_tie_'+str(side),a+v*side*(ro+.001),b+v*side*(ro+.001),.002,parent,'chrome',barrel)
 child_ob=next(ob for ob in GROUP if ob['name']==child)
 inv=np.linalg.inv(k.mat4(child_ob))
 def local(v):return (inv@np.r_[v,1])[:3]
 jcfg=next((j for j in JOINTS if j['child']==child and j['type']=='prismatic'),None)
 projection=float(np.dot(u,jcfg['axis'])) if jcfg else 1.0
 ext_home=float(np.dot(e-b,u));ext_max=ext_home+max(0,projection*stroke)
 rod_length=ext_max+.009
 rodname=rod(n+'_rod',local(e-u*rod_length),local(e),rr,child,'chrome')
 ring(n+'_rod_nut',local(e-u*.006),local(e+u*.006),rr*1.5,rr+.00001,child,'dark',rodname)
 ring(n+'_piston',local(e-u*(rod_length+.0025)),local(e-u*(rod_length-.0025)),r-.00010,rr+.00001,child,'dark',rodname)
 for j,t in enumerate([.15,.85]):
  c=a+(b-a)*t;v=np.cross(u,[1,0,0] if abs(u[0])<.9 else [0,1,0]);v/=np.linalg.norm(v)
  ring(n+'_port_'+str(j),c+v*ro,c+v*(ro+.012),.005,.002,parent,'chrome',barrel)
 CYL.append(dict(name=n,parent=parent,child=child,nose=b.tolist(),home_end=e.tolist(),axis=u.tolist(),rod=rodname,stroke=stroke,bore=bore,pressure_Pa=(150000 if 'grip' in n else 500000),efficiency=.7,rod_length=rod_length,barrel_length=float(np.linalg.norm(b-a))))
 return barrel

def gripper(n,parent,at,station,product=False):
 base=g(n,parent,at,label='双导杆、对置气缸、软垫夹持',station=station)
 frame=p(n+'_frame','drilled',[.110,.008,.300,[[0,0,.024]]],(0,.031,0),base)
 for x in [-.036,.036]:rod(n+'_guide_'+str(x),[x,0,-.145],[x,0,.145],.004,base,support=frame)
 for side in [-1,1]:
  j=g(n+'_jaw_'+str(side),base,pos=(0,0,side*.030),label='滑动夹爪 / 开程18 mm')
  jaw=box(n+'_jaw_body_'+str(side),(.090,.026,.015),(0,0,0),j,'aluminum')
  box(n+'_PU_'+str(side),(.045,.024,.008),(0,0,-side*.010),j,'pad',jaw)
  # The rod-end interface is expressed in the moving jaw's coordinates.
  end=[0,0,side*.041]
  joint(n+'_jaw_'+str(side),'prismatic',base,j,[0,0,side],0,.018,offset=[0,0,side*.030],home=0)
  c=cylinder(n+'_cyl_'+str(side),base,j,[0,0,side*.146],[0,0,side*.110],end,bore=.012,stroke=.018)
  wall=box(n+'_cyl_mount_'+str(side),(.10,.040,.008),(0,.010,side*.145),base,support=frame)
  MOUNTS.append(dict(part=c,support=wall,type='flange'))
 for x in [-.043,.043]:
  for z in [-.125,.125]:bolt(n+'_mount_'+str(x)+'_'+str(z),(x,.038,z),base,support=frame)
 return base,frame

# Main foundations: welded radial members, outer hexagon and individually grounded legs.
g('fixed',None,label='焊接机架与静止部件')
central=plate('foundation_centre',(.32,.020,.32),(0,.39,0))
for i in range(6):
 a=math.radians(i*60);g('station'+str(i+1),'fixed',yaw=i*60+180,label=['上料与剪叶','气动去皮','水洗与风干','独立称重','移载与包装接口','空夹复位'][i],station=i+1)
 par='station'+str(i+1)
 for z in [-.22,.22]:
  long=tube(f'frame_{i}_{z}',(1.62,.06,.06),(.91,.40,z),par,support=central)
  for x in [1.15,1.66]:
   fp=foot(f'foot_{i}_{x}_{z}',x,z,par)
   leg=tube(f'leg_{i}_{x}_{z}',(.060,.273,.060),(x,.2335,z),par,support=fp)
   contact(fp,leg);contact(leg,long)
 for x in [.62,1.15,1.66]:tube(f'frame_cross_{i}_{x}',(.06,.06,.50),(x,.40,0),par,support=f'frame_{i}_-0.22')
 for y in [.18,.40]:
  aa=[1.15*math.cos(a),y,1.15*math.sin(a)];b=[1.15*math.cos(a+math.pi/3),y,1.15*math.sin(a+math.pi/3)]
  beam(f'hex_frame_{i}_{y}',aa,b,.050,support=central)
# Explicit bearing supports and axial locating faces.
g('drive',label='主传动 / 双支承 / 减速器')
base=plate('main_column_base',(.24,.020,.24),(0,.420,0),'drive',holes=[[-.085,-.085,.0065],[.085,-.085,.0065],[-.085,.085,.0065],[.085,.085,.0065]],support=central)
p('main_column','ring',[.075,.083,.950,0,360],(0,.905,0),'drive','steel',base)
for y in [.590,.940]:
 flange=ring('main_bearing_flange_'+str(y),[0,y-.025,0],[0,y-.013,0],.098,.021,'drive',support='main_column')
 housing=p('main_6208_housing_'+str(y),'ring',[.04001,.062,.040,0,360],(0,y,0),'drive','steel',flange)
 ring('main_6208_outer_'+str(y),[0,y-.009,0],[0,y+.009,0],.040,.034,'drive','dark',housing)
 for z in [-.075,.075]:
  for x in [-.075,.075]:bolt('main_bearing_M8_'+str(y)+'_'+str(x)+'_'+str(z),(x,y-.014,z),'drive',r=.004,L=.030,support=flange)
 for j in range(10):
  a=j*math.tau/10;p('main_6208_ball_'+str(y)+'_'+str(j),'sphere',[.0045],(.0295*math.cos(a),y,.0295*math.sin(a)),'drive','chrome',housing,join='rolling')
 # Structural radial ribs link the bearing housing flange to the load tube.
 for a in [0,90,180,270]:
  aa=math.radians(a);beam('bearing_web_'+str(y)+'_'+str(a),[.05*math.cos(aa),y-.019,.05*math.sin(aa)],[.082*math.cos(aa),y-.019,.082*math.sin(aa)],.014,'drive',housing)
# Motor / reducer supported at both flange and base, not carrying rotor bending moment.
plate('gearbox_mount',(.26,.012,.24),(0,.325,0),'drive',support=central)
for x in [-.10,.10]:tube('drive_mount_riser_'+str(x),(.035,.084,.035),(x,.370,0),'drive',support='gearbox_mount')
p('planetary_80to1','cyl',[.072,.105],(0,.2665,0),'drive','dark','gearbox_mount')
p('servo750W','softbox',[.090,.135,.090,.005],(0,.1465,0),'drive','black','planetary_80to1')
p('servo_encoder','softbox',[.073,.032,.073,.003],(0,.063,0),'drive','black','servo750W')
for z in [-.046,.046]:box('servo_fins_'+str(z),(.080,.110,.004),(0,.145,z),'drive','dark','servo750W')
g('carousel','fixed',label='回转上盘 / 6 × 双通道夹具')
rod('main_shaft40',[0,.360,0],[0,1.470,0],.020,'carousel')
rod('reducer_output32',[0,.314,0],[0,.352,0],.016,'carousel',support='main_shaft40')
p('main_32_40_coupling','coupling',[.01602,.02002,.037,.060],(0,.360,0),'carousel','chrome','main_shaft40')
for y in [.59,.94]:ring('main_6208_inner_'+str(y),[0,y-.009,0],[0,y+.009,0],.025,.02001,'carousel','chrome','main_shaft40')
ring('shaft_axial_shoulder',[0,.576,0],[0,.581,0],.026,.02001,'carousel',support='main_shaft40')
p('rotor_hub','keyed_hub',[.02002,.110,.040],(0,1.450,0),'carousel','steel','main_shaft40')
box('shaft_key',(.008,.035,.007),(.020,1.450,0),'carousel','dark','main_shaft40')
joint('main_index','revolute','fixed','carousel',[0,1,0],-math.tau,math.tau,gear_ratio=80,step_rad=math.pi/3)
for i in range(6):
 car=g('carrier_'+str(i),'carousel',yaw=i*60+180,label='双通道夹具扇区'+str(i+1),station=i+1)
 arm=tube('arm_'+str(i),(.56,.040,.040),(.365,1.45,0),car,support='rotor_hub')
 for x in [.105,.155]:
  for z in [-.015,.015]:bolt('arm_bolt_'+str(i)+'_'+str(x)+'_'+str(z),(x,1.469,z),car,r=.004,L=.035,support=arm)
 tie=tube('arm_side_'+str(i),(.050,.040,.200),(.620,1.450,.080),car,support=arm)
 spine=tube('grip_spine_'+str(i),(.04,.400,.04),(.620,1.230,.160),car,support=tie)
 bridge=tube('grip_bridge_'+str(i),(.36,.030,.035),(.460,1.015,.160),car,support=spine)
 for l,r in enumerate([.33,.47]):
  gr,fr=gripper(f'grip_{i}_{l}',car,(r,1.040,0),i+1)
  tab=box(f'grip_tab_{i}_{l}',(.10,.012,.060),(r,1.006,.135),car,support=bridge)
  MOUNTS.append(dict(part=fr,support=tab,type='bolted'))
  k.scallion(f'product_{i}_{l}',(r,.58,0),car,station=i+1,raw=i<2)
# Central rotary union for clamp air only. Process air stays on the fixed frame.
g('rotary_union','drive',pos=(0,1.53,0),label='Deublin 双通道接口；安装包络按公开图复核')
p('union_stator','ring',[.020,.054,.080,0,360],(0,0,0),'rotary_union','blue',join='rotary_union_stator')
ring('union_fixed_air_in',[.054,0,0],[.075,0,0],.008,.004,'rotary_union','blue','union_stator')
rod('union_anti_rotation',[.06,-.02,0],[.11,-.02,0],.004,'rotary_union','steel','union_stator')
beam('union_restraint_bracket',[.11,1.37,0],[.11,1.51,0],.020,'drive',support='main_column')
beam('union_bracket_root',[.070,1.37,0],[.11,1.37,0],.020,'drive',support='main_column')
ring('union_rotor_stub',[0,1.465,0],[0,1.57,0],.019,.012,'carousel','chrome','main_shaft40')
# Lower guard remains removable for bearing inspection.
g('guard','fixed',label='非承压防护')
for a in [0,120,240]:p('base_panel_'+str(a),'ring',[.655,.658,.30,a,110],(0,.255,0),'guard','green',central)
for i in range(6):
 a=math.radians(i*60);x,z=.71*math.cos(a),.71*math.sin(a)
 rod('guard_post_'+str(i),[x,.43,z],[x,1.51,z],.010,'guard','steel',central)
p('guard_top_ring','ring',[.700,.715,.018,0,360],(0,1.51,0),'guard','dark','guard_post_0')

# A supported directional magazine and a full loader axis.
g('feeder','station1',pos=(1.35,0,0),label='定向料盘 / 根部杯托与弹性夹片')
for x,z in [(-.31,-.30),(-.31,.30),(.31,-.30),(.31,.30)]:
 fp=foot('feed_foot_'+str(x)+'_'+str(z),x,z,'feeder');tube('feed_leg_'+str(x)+'_'+str(z),(.04,.323,.04),(x,.2585,z),'feeder',support=fp)
p('feed_base','cyl',[.36,.012],(0,.426,0),'feeder',support='feed_leg_-0.31_-0.3')
ring('feed_spindle_housing',[0,.432,0],[0,.535,0],.045,.01801,'feeder',support='feed_base')
p('feed_reducer','cyl',[.06,.070],(0,.390,0),'feeder','dark','feed_base')
p('feed_servo','cyl',[.035,.090],(0,.310,0),'feeder','black','feed_reducer')
g('magazine','feeder',label='φ35双支承料盘主轴')
rod('feed_spindle',[0,.390,0],[0,.565,0],.0175,'magazine')
p('feed_disc','ring',[.01751,.35,.012,0,360],(0,.550,0),'magazine',support='feed_spindle')
for i in range(12):
 a=i*math.tau/12
 for l,r in enumerate([.18,.32]):
  x,z=r*math.cos(a),r*math.sin(a)
  p(f'feed_cup_{i}_{l}','cup',[.015,.023,.030],(x,.556,z),'magazine','pad','feed_disc')
  beam(f'feed_clip_post_{i}_{l}',[x,.556,z+.043],[x,1.035,z+.043],.012,'magazine','feed_disc')
  p(f'feed_clip_{i}_{l}','ring',[.0145,.019,.020,25,310],(x,1.035,z),'magazine','pad',f'feed_clip_post_{i}_{l}')
  if i not in [5,6,7]:k.scallion(f'stock_{i}_{l}',(x,.580,z),'magazine',station=1)
joint('magazine_index','revolute','feeder','magazine',[0,1,0],0,math.tau,step_rad=math.pi/6)
load,bp=axis('load_axis','station1',(.60,.620,0),1.10)
# The loader vertical mast and rear crossbeam support both grippers.
for z in [-.14,.14]:tube('loader_mast_'+str(z),(.035,.430,.035),(0,.297,z),load,support='load_axis_carriage')
tube('loader_cross',(.040,.030,.320),(0,.515,0),load,support='loader_mast_-0.14')
for l,x in enumerate([-.39,-.25]):
 beam('loader_reach_'+str(l),[0,.515,.12],[x,.515,.12],.026,load,'loader_cross')
 gr,fr=gripper('loader_grip_'+str(l),load,(x,.540,0),1);MOUNTS.append(dict(part=fr,support='loader_reach_'+str(l),type='bolted'))

# Root shear at the front magazine sector: two rails, one cylinder, two blades.
g('root_station','station1',label='上料盘内侧切根 / 支承、导向与废根斗')
rb=plate('root_fixed_plate',(.37,.012,.60),(1.10,.485,-.12),'root_station',support='frame_cross_0_1.15')
for x in [.94,1.26]:
 tube('root_stand_'+str(x),(.035,.049,.035),(x,.4545,0),'root_station',support='frame_cross_0_1.15')
 rod('root_guide_'+str(x),[x,.530,-.18],[x,.530,.14],.006,'root_station',support=rb)
g('root_knife','root_station',label='双刀共用横梁 / 刀片与反刃间隙0.10 mm')
joint('root_cut','prismatic','root_station','root_knife',[0,0,1],0,.090,home=0)
kb=box('root_knife_bridge',(.36,.018,.05),(1.10,.550,-.10),'root_knife',support='root_guide_0.94')
for r in [1.03,1.17]:
 p('root_blade_'+str(r),'knife',[.085,.003,.090],(r,.575,-.065),'root_knife',support=kb)
 box('root_counter_'+str(r),(.085,.016,.045),(r,.5654,.045),'root_station','dark',rb)
 box('root_holder_'+str(r),(.085,.0145,.028),(r,.56625,-.09),'root_knife',support=kb)
 for dx in [-.024,.024]:bolt('root_knife_M6_'+str(r)+'_'+str(dx),(r+dx,.569,-.090),'root_knife',support='root_holder_'+str(r))
c=cylinder('root_80','root_station','root_knife',[1.10,.555,-.57],[1.10,.555,-.35],[1.10,.555,-.085],bore=.08,stroke=.09)
box('root_cylinder_rear_mount',(.14,.090,.008),(1.10,.536,-.380),'root_station',support=rb)
for r in [1.03,1.17]:
 box('root_counter_pedestal_'+str(r),(.065,.0664,.040),(r,.5242,.045),'root_station',support=rb)
for x in [.94,1.26]:ring('root_guide_bush_'+str(x),[x,.53,-.120],[x,.53,-.080],.011,.00602,'root_knife','aluminum','root_knife_bridge')
box('root_rod_clevis',(.030,.035,.018),(1.10,.545,-.10),'root_knife',support=kb)
ring('root_hopper',[1.10,.435,0],[1.10,.470,0],.12,.11,'root_station',support=rb)
p('root_waste','cup',[.112,.120,.23],(1.10,.010,0),'root_station','green',join='ground')

# Station1 top trimmer on a hanging guided carriage, supported by an external gantry.
for z in [-.24,.24]:
 tube('trim_gantry_'+str(z),(.05,1.12,.05),(1.24,.99,z),'station1',support='frame_0_'+str(-.22 if z<0 else .22))
 tube('trim_gantry_beam_'+str(z),(1.05,.05,.05),(.94,1.525,z),'station1',support='trim_gantry_'+str(z))
trim,tbp=axis('trim_axis','station1',(.70,1.55,0),1.60)
for x in [-.40,-.26]:tube('trim_drop_'+str(x),(.025,.395,.025),(x,-.120,-.12),trim,support='trim_axis_carriage')
box('trim_fixed_cross',(.31,.020,.20),(-.33,-.327,0),trim,support='trim_drop_-0.4')
g('trim_knife',trim,label='剪叶刀导向与气缸')
joint('trim_cut','prismatic',trim,'trim_knife',[0,0,1],0,.08,home=0)
for x in [-.49,-.17]:rod('trim_guide_'+str(x),[x,-.327,-.19],[x,-.327,.14],.005,trim,support='trim_fixed_cross')
for l,x in enumerate([-.49,-.35]):
 p('trim_blade_'+str(l),'knife',[.11,.003,.080],(x,-.450,-.065),'trim_knife',support='trim_fixed_cross')
 box('trim_counter_'+str(l),(.11,.018,.045),(x,-.4606,.04),trim,'dark','trim_fixed_cross')
 beam('trim_knife_drop_'+str(l),[x,-.327,-.10],[x,-.442,-.10],.020,'trim_knife','trim_fixed_cross')
box('trim_knife_tie',(.30,.02,.03),(-.42,-.327,-.10),'trim_knife',support='trim_guide_-0.49')
cylinder('trim_63',trim,'trim_knife',[-.23,-.327,-.46],[-.23,-.327,-.25],[-.23,-.327,-.14],bore=.063,stroke=.08)
for x in [-.54,-.12]:beam('trim_cyl_support_'+str(x),[x,-.35,-.39],[x,-.35,.08],.026,trim,'trim_fixed_cross')
box('trim_cyl_rear_mount',(.50,.070,.008),(-.33,-.302,-.370),trim,support='trim_cyl_support_-0.54')

# Peeling: radial 320 mm stage + vertical 370 mm screw stage + four opening cylinders.
peel,pp=axis('peel_radial','station2',(.72,.430,0),.65)
for z in [-.13,.13]:
 tube('peel_tower_'+str(z),(.035,.710,.035),(.20,.437,z),peel,support='peel_radial_carriage')
scan,sp=axis('peel_scan','peel_radial',(.20,.740,0),.30,0,roll=-90,yaw=180)
# Correct parent: both vertical rails and their base ride on the radial carriage.
next(v for v in GROUP if v['name']=='peel_scan')['parent']=peel
phead=g('peel_head',scan,pos=(.120,.082,0),roll=-90,yaw=180,label='扫描横梁 / 两个开合喷环')
tube('peel_head_cross',(.82,.025,.026),(-.30,.052,.22),phead,support='peel_scan_carriage')
tube('peel_head_cross_back',(.82,.025,.026),(-.30,.052,-.22),phead,support='peel_scan_carriage')
for x in [-.70,.10]:tube('peel_head_end_'+str(x),(.025,.025,.466),(x,.052,0),phead,support='peel_head_cross')
for l,x in enumerate([-.628,-.488]):
 for side in [-1,1]:
  half=g(f'nozzle_{l}_{side}',phead,label='导杆约束的开合半环')
  joint(f'nozzle_{l}_{side}','prismatic',phead,half,[0,0,side],0,.065,home=.065)
  # Initial scene is open. The solver explicitly applies all joint home poses.
  manifold=p(f'peel_manifold_{l}_{side}','ring',[.044,.052,.018,0 if side>0 else 180,180],(x,0,0),half,'blue')
  for j in range(4):
   a=math.radians((j+.5)*45+(0 if side>0 else 180));v=np.array([math.cos(a),0,math.sin(a)])
   A=np.array([x,0,0])+v*.052;B=np.array([x,-.005,0])+v*.036
   ring(f'peel_nozzle_{l}_{side}_{j}',A,B,.004,.001,half,'chrome',manifold)
  slide=box(f'peel_half_slide_{l}_{side}',(.06,.016,.026),(x+.045,.028,side*.060),half,support=manifold)
  beam(f'peel_half_bridge_{l}_{side}',[x,.009,side*.045],[x+.045,.028,side*.060],.012,half,manifold)
  rod(f'peel_half_guide_{l}_{side}',[x+.045,.028,side*.025],[x+.045,.028,side*.235],.004,phead,support='peel_head_cross')
  cylinder(f'peel_open_{l}_{side}',phead,half,[x+.045,.028,side*.270],[x+.045,.028,side*.180],[x+.045,.028,side*.060],bore=.020,stroke=.065)
  box(f'peel_cyl_mount_{l}_{side}',(.055,.050,.018),(x+.045,.045,side*.267),phead,support='peel_head_cross')
  ring(f'peel_guide_bush_{l}_{side}',[x+.045,.028,side*.190],[x+.045,.028,side*.230],.012,.00402,phead,'aluminum','peel_head_cross')
ring('peel_hopper_lip',[.40,.48,0],[.40,.51,0],.18,.17,'station2',support='frame_cross_1_0.62')
p('peel_drum','cup',[.16,.165,.31],(.40,.010,0),'station2','green',join='ground')

# Wash / blow stage; drain tray and two spring-return isolation flaps.
wash,wp=axis('wash_axis','station3',(.72,.430,0),.55)
for z in [-.16,.16]:tube('wash_tower_'+str(z),(.025,.620,.025),(-.16,.392,z),wash,support='wash_axis_carriage')
for x in [-.51,-.37]:
 beam('wash_head_arm_'+str(x),[-.16,.692,.14],[x,.692,.14],.020,wash,'wash_tower_0.16')
 for y in [.20,.33,.46]:
  for z in [-.065,.065]:
   rod('wash_nozzle_'+str(x)+'_'+str(y)+'_'+str(z),[x,y,z],[x,y,z*.72],.005,wash,'water','wash_head_arm_'+str(x))
 for z in [-.04,.04]:box('air_knife_'+str(x)+'_'+str(z),(.018,.24,.015),(x,.48,z),wash,'blue','wash_head_arm_'+str(x))
 # Side manifolds support all nozzles and connect to a fixed hose loop.
 for z in [-.065,.065]:rod('wash_manifold_'+str(x)+'_'+str(z),[x,.20,z],[x,.70,z],.009,wash,'water','wash_head_arm_'+str(x))
tray=plate('wash_tray',(.56,.006,.54),(.43,.533,0),'station3',holes=[[.22,.16,.018]],support='frame_cross_2_0.62')
for x in [.20,.66]:
 for z in [-.23,.23]:tube('tray_stand_'+str(x)+'_'+str(z),(.022,.100,.022),(x,.480,z),'station3',support='frame_2_'+str(-.22 if z<0 else .22))
for side in [-1,1]:
 door=g('wash_flap_'+str(side),'station3',(.72,0,side*.275),label='弹簧复位隔水挡板 / 垂直铰链')
 rod('wash_hinge_'+str(side),[.72,.55,side*.275],[.72,1.40,side*.275],.006,'station3',support=tray)
 box('wash_panel_'+str(side),(.49,.82,.004),(-.245,.975,0),door,'glass',support='wash_hinge_'+str(side))
 p('wash_spring_'+str(side),'ring',[.0061,.012,.06,0,360],(0,1.35,0),door,'chrome','wash_hinge_'+str(side))
 joint('wash_flap_'+str(side),'revolute','station3',door,[0,1,0],-.8,.8,home=0,spring_return=True)

# Weighing: independent radial carriage, guided vertical lift, and two separate load paths.
wslide,wb=axis('weigh_axis','station4',(.72,.430,0),.42)
g('weigh_lift',wslide,label='独立40 mm升降，不与径向丝杠螺母混为同一自由度')
joint('weigh_lift','prismatic',wslide,'weigh_lift',[0,1,0],0,.040,home=0)
p('weigh_MGQ_body','guidedbody',[.088,.1195,.042],(0,.14175,0),wslide,'blue','weigh_axis_carriage')
for x in [-.025,.025]:
 rod('weigh_guide13_'+str(x),[x,.085,0],[x,.255,0],.0065,'weigh_lift',support='weigh_lift_plate')
 ring('weigh_guide_bush_'+str(x),[x,.09,0],[x,.19,0],.009,.00652,wslide,'dark','weigh_MGQ_body')
liftplate=plate('weigh_lift_plate',(.10,.012,.09),(0,.255,0),'weigh_lift')
cylinder('weigh_MGQ25',wslide,'weigh_lift',[0,.088,0],[0,.207,0],[0,.249,0],bore=.025,stroke=.04)
for x in [-.51,-.37]:
 beam('weigh_reach_'+str(x),[0,.255,.03],[x+.12,.255,.03],.025,'weigh_lift',liftplate)
 beam('weigh_drop_'+str(x),[x+.12,.255,.03],[x+.12,.105,.03],.020,'weigh_lift','weigh_reach_'+str(x))
 lc=box('loadcell_'+str(x),(.12,.018,.028),(x+.06,.097,0),'weigh_lift','aluminum','weigh_drop_'+str(x))
 # Cup and all product guides are supported ONLY from the load-cell free end.
 cup=p('weigh_cup_'+str(x),'cup',[.015,.021,.026],(x,.106,0),'weigh_lift','pad',lc)
 for z in [-.022,.022]:beam('weigh_product_guide_'+str(x)+'_'+str(z),[x,.114,z],[x,.215,z],.006,'weigh_lift',lc)

# Unloading with full guide and a physically supported outfeed spindle.
unload,ub=axis('unload_axis','station5',(.60,.660,0),1.15)
for z in [-.14,.14]:tube('unload_mast_'+str(z),(.035,.410,.035),(0,.287,z),unload,support='unload_axis_carriage')
tube('unload_cross',(.045,.03,.31),(0,.5,0),unload,support='unload_mast_-0.14')
for l,x in enumerate([-.39,-.25]):
 beam('unload_reach_'+str(l),[0,.50,.12],[x,.50,.12],.026,unload,'unload_cross')
 gr,fr=gripper('unload_grip_'+str(l),unload,(x,.520,0),5);MOUNTS.append(dict(part=fr,support='unload_reach_'+str(l),type='bolted'))
g('outfeed','station5',pos=(1.40,0,0),label='成品盘 / φ35轴 / 双轴承 / 同轴减速电机')
for x,z in [(-.28,-.28),(-.28,.28),(.28,-.28),(.28,.28)]:
 fp=foot('out_foot_'+str(x)+'_'+str(z),x,z,'outfeed');tube('out_leg_'+str(x)+'_'+str(z),(.04,.323,.04),(x,.2585,z),'outfeed',support=fp)
op=plate('outfeed_mount',(.70,.014,.70),(0,.427,0),'outfeed',support='out_leg_-0.28_-0.28')
ring('outfeed_column',[0,.434,0],[0,.560,0],.049,.03601,'outfeed',support=op)
for y in [.46,.54]:ring('outfeed_6207_outer_'+str(y),[0,y-.0085,0],[0,y+.0085,0],.036,.030,'outfeed','dark','outfeed_column')
p('outfeed_reducer','cyl',[.060,.080],(0,.385,0),'outfeed','dark',op)
p('outfeed_motor','cyl',[.035,.100],(0,.295,0),'outfeed','black','outfeed_reducer')
g('outfeed_rotor','outfeed',label='双支承旋转部分与静止基座分开')
rod('outfeed_shaft35',[0,.410,0],[0,.595,0],.0175,'outfeed_rotor')
ring('outfeed_coupling',[0,.410,0],[0,.450,0],.026,.01751,'outfeed_rotor','chrome','outfeed_shaft35')
for y in [.46,.54]:ring('outfeed_6207_inner_'+str(y),[0,y-.0085,0],[0,y+.0085,0],.023,.01751,'outfeed_rotor','chrome','outfeed_shaft35')
p('outfeed_hub','ring',[.01751,.070,.018,0,360],(0,.571,0),'outfeed_rotor',support='outfeed_shaft35')
p('outfeed_disc','ring',[.01751,.35,.012,0,360],(0,.586,0),'outfeed_rotor',support='outfeed_hub')
for i in range(12):
 a=i*math.tau/12
 for l,r in enumerate([.18,.32]):
  x,z=r*math.cos(a),r*math.sin(a);p(f'out_cup_{i}_{l}','cup',[.015,.023,.030],(x,.592,z),'outfeed_rotor','pad','outfeed_disc')
joint('outfeed_index','revolute','outfeed','outfeed_rotor',[0,1,0],0,math.tau,step_rad=math.pi/6)
# Packaging is an explicitly mounted integration boundary, not invented vendor internals.
pack=g('pack_oem','station5',(1.55,0,.60),label='束带模块安装接口；供应商CAD/自动接口未冻结')
for x in [-.20,.20]:
 fp=foot('pack_foot_'+str(x),x,0,pack);tube('pack_leg_'+str(x),(.04,.63,.04),(x,.412,0),pack,support=fp)
plate('pack_mount_plate',(.58,.012,.32),(0,.733,0),pack,support='pack_leg_-0.2')
p('pack_supplier_envelope','softbox',[.50,.40,.28,.002],(0,.939,0),pack,'glass','pack_mount_plate',cad=False)
box('pack_interface_label',(.40,.06,.005),(0,.90,.143),pack,'orange','pack_supplier_envelope')

# Stationary utilities: physical skid, regulator manifold and explicit supported pipes.
g('utilities','station6',pos=(1.10,0,0),label='固定气、水、电接口与维护空间')
for z in [-.20,.20]:tube('utility_skid_'+str(z),(.85,.04,.04),(0,.080,z),'utilities',support='frame_5_'+str(-.22 if z<0 else .22))
for z in [-.20,.20]:tube('utility_post_'+str(z),(.035,1.05,.035),(.32,.625,z),'utilities',support='utility_skid_'+str(z))
box('utility_backplate',(.004,.43,.48),(.3395,.92,0),'utilities',support='utility_post_-0.2')
for z in [-.12,.12]:box('utility_standoff_'+str(z),(.0375,.030,.030),(.31875,1.05,z),'utilities',support='utility_backplate')
box('FRL_manifold',(.11,.055,.30),(.245,1.05,0),'utilities','blue','utility_backplate')
for z in [-.105,0,.105]:
 p('FRL_filter_'+str(z),'cyl',[.026,.12],(.245,.9625,z),'utilities','blue','FRL_manifold')
 p('FRL_gauge_'+str(z),'cyl',[.021,.014],(.245,1.086,z),'utilities','white','FRL_manifold')
p('control_cabinet','shellbox',[.28,.55,.42,.002],(-.14,.375,0),'utilities','dark','utility_skid_-0.2')
box('cabinet_door',(.264,.530,.002),(-.14,.375,.212),'utilities','steel','control_cabinet')
for y in [.20,.55]:box('cabinet_hinge_'+str(y),(.018,.06,.014),(-.26,y,.212),'utilities','dark','cabinet_door')
p('water_tank','cup',[.205,.210,.38],(-.14,.100,.52),'utilities','steel',join='ground_skid')
# Pipeline tracing is grouped independently so it can be hidden while inspecting mechanics.
g('services','fixed',label='静止支路；软管按装配空间示意')
for i in range(6):
 par='station'+str(i+1);y=.46
 rod('air_fixed_run_'+str(i),[.75,y,-.20],[1.30,y,-.20],.008,par,'blue',support='frame_'+str(i)+'_-0.22')
 # Vertical riser is fixed to the station support and does not follow a rotating carrier.
 rod('air_riser_'+str(i),[1.30,y,-.20],[1.30,1.08,-.20],.006,par,'blue',support='air_fixed_run_'+str(i))
for i,j in [(1,2),(2,3),(3,4),(4,5),(5,6),(6,1)]:
 aa=math.radians(180+(i-1)*60);bb=math.radians(180+(j-1)*60)
 rod('air_ring_link_'+str(i),[.78*math.cos(aa)-.20*math.sin(aa),.46,-.78*math.sin(aa)-.20*math.cos(aa)],[.78*math.cos(bb)-.20*math.sin(bb),.46,-.78*math.sin(bb)-.20*math.cos(bb)],.008,'services','blue')
# HMI attached to a leg rather than a free-floating panel.
g('console','station6',pos=(1.50,0,.36),label='操作面板')
fp=foot('console_foot',0,0,'console');tube('console_post',(.04,1.03,.04),(0,.612,0),'console',support=fp)
p('HMI','shellbox',[.24,.18,.065,.002],(0,1.18,0),'console','dark','console_post')
box('HMI_screen',(.205,.135,.004),(0,1.185,.035),'console','green','HMI')
p('E_stop','cyl',[.020,.026],(.075,1.29,0),'console','red','HMI')


# Installation refinements found by measured surface-gap checks.
by={v['name']:v for v in PART}
def set_support(a,b,typ='rigid'):
 ob=next((v for v in PART if v['name']==a),None)
 if ob:ob['support']=b;ob['connection']=typ
 found=False
 for x in MOUNTS:
  if x['part']==a:x['support']=b;x['type']=typ;found=True
 if not found and ob:MOUNTS.append(dict(part=a,support=b,type=typ))
for i in range(6):
 par='station'+str(i+1)
 sp=tube('central_spoke_'+str(i),(.66,.060,.060),(.37,.400,0),par,support=central)
 for z in [-.22,.22]:set_support(f'frame_{i}_{z}',f'frame_cross_{i}_0.62')
 set_support(f'frame_cross_{i}_0.62',sp)
 low=tube('lower_cross_'+str(i),(.050,.050,.50),(1.15,.180,0),par,support=f'leg_{i}_1.15_-0.22')
 # Pipe clips and foot brackets touch both the pipe and its supporting beam.
 for x in [.80,1.25]:
  cl=box('air_clip_'+str(i)+'_'+str(x),(.026,.030,.024),(x,.445,-.20),par,support=f'frame_{i}_-0.22')
 set_support('air_fixed_run_'+str(i),'air_clip_'+str(i)+'_0.8')
 for l in range(2):
  tab=by[f'grip_tab_{i}_{l}'];tab['dims']=[.10,.037,.060,.001];tab['pos'][1]=1.0485
for i in range(6):
 s=(-i-3)%6+1;par='station'+str(s)
 bg=box('guard_base_'+str(i),(.25,.030,.060),(.71,.415,0),par,support=f'frame_cross_{s-1}_0.62')
 set_support('guard_post_'+str(i),bg)
 set_support(f'hex_frame_{i}_0.4',f'frame_cross_{s-1}_1.15')
 set_support(f'hex_frame_{i}_0.18','lower_cross_'+str(s-1))
for a,i in [(0,1),(120,3),(240,5)]:
 s=(-i-3)%6+1;bp=box('base_panel_mount_'+str(a),(.035,.030,.050),(.654,.4,0),'station'+str(s),support=f'frame_cross_{s-1}_0.62');set_support('base_panel_'+str(a),bp)
plate('main_column_spacer',(.24,.010,.24),(0,.405,0),'drive',support=central)
set_support('main_column_base','main_column_spacer');set_support('gearbox_mount','drive_mount_riser_-0.1');set_support('union_restraint_bracket','union_bracket_root')
by['union_anti_rotation']['dims'][0][0]=.050
for v in PART:
 if v['name'].startswith('main_bearing_M8_'):
  v['pos'][0]=math.copysign(.060,v['pos'][0]);v['pos'][2]=math.copysign(.060,v['pos'][2])
for n in ['root_waste','peel_drum']:by[n]['pos'][1]=0
for z in [-.30,.30]:tube('feed_underframe_'+str(z),(.66,.04,.04),(0,.400,z),'feeder',support='feed_leg_-0.31_'+str(z))
for v in PART:
 if v['name'].startswith('feed_leg_'):v['dims'][1]=.283;v['pos'][1]=.2385
by['feed_disc']['dims'][1]=.380
set_support('feed_base','feed_underframe_-0.3')
for i in range(12):
 for l in range(2):
  v=by[f'feed_clip_{i}_{l}'];x,y,z=v['pos'];b=box(f'feed_clip_tab_{i}_{l}',(.014,.020,.040),(x,y,z+.030),'magazine',support=f'feed_clip_post_{i}_{l}');set_support(v['name'],b)
for n,z in [('loader',.515),('unload',.500)]:
 target='load_axis_slide' if n=='loader' else 'unload_axis_slide'
 for l,x in enumerate([-.39,-.25]):
  H=.039 if n=='loader' else .034
  b=box(n+'_grip_tab_'+str(l),(.10,H,.060),(x,z+.013+H/2,.12),target,support=n+'_reach_'+str(l));set_support(n+'_grip_'+str(l)+'_frame',b)
for v in PART:
 if '_guide_' in v['name'] and v['name'].startswith(('grip_','loader_grip_','unload_grip_')):set_support(v['name'],v['parent']+'_cyl_mount_1')
# Hanging trimmer is carried by horizontal reaches from the actual carriage.
for x in [-.40,-.26]:
 reach=beam('trim_reach_'+str(x),[.03,.095,-.12],[x,.095,-.12],.026,trim,'trim_axis_carriage')
 v=by['trim_drop_'+str(x)];v['dims'][1]=.399;v['pos'][1]=-.1175;set_support(v['name'],reach)
set_support('trim_fixed_cross','trim_drop_-0.4')
for l,x in enumerate([-.49,-.35]):
 b=box('trim_counter_stand_'+str(l),(.090,.1146,.040),(x,-.3943,.040),trim,support='trim_fixed_cross');set_support('trim_counter_'+str(l),b);set_support('trim_blade_'+str(l),'trim_knife_drop_'+str(l))
for x in [-.54,-.12]:
 b=box('trim_cyl_bridge_'+str(x),(.070,.026,.06),(x,-.35,0),trim,support='trim_fixed_cross');set_support('trim_cyl_support_'+str(x),b)
# Radial carriage outriggers support vertical scan rails and wash towers.
pp=plate('peel_carriage_extension',(.55,.012,.30),(.10,.088,0),peel,support='peel_radial_carriage')
for z in [-.13,.13]:
 v=by['peel_tower_'+str(z)];v['dims'][1]=.698;v['pos'][1]=.443;set_support(v['name'],pp)
head_anchor=tube('peel_head_anchor',(.026,.026,.466),(-.013,.052,0),phead,support='peel_scan_carriage')
set_support('peel_head_cross',head_anchor);set_support('peel_head_cross_back',head_anchor)
for l,x in enumerate([-.628,-.488]):
 for side in [-1,1]:
  b=box(f'peel_mount_extension_{l}_{side}',(.055,.025,.067),(x+.045,.052,side*.245),phead,support='peel_head_cross' if side>0 else 'peel_head_cross_back')
  set_support(f'peel_cyl_mount_{l}_{side}',b)
  set_support(f'peel_half_guide_{l}_{side}',f'peel_guide_bush_{l}_{side}')
  set_support(f'peel_guide_bush_{l}_{side}','peel_head_cross' if side>0 else 'peel_head_cross_back')
  set_support(f'peel_half_slide_{l}_{side}',f'peel_half_bridge_{l}_{side}')
for a in AXES:
 n=a['name'];base=a['base'];L=a['L']
 set_support(n+'_CPDW32',n+'_fixed_journal12');set_support(n+'_locknut',n+'_fixed_journal12')
 # A stepped 10/12 mm coupling must not leave the motor's 10 mm shaft floating.
 by[n+'_CPDW32']['kind']='step_coupling_x';by[n+'_CPDW32']['dims']=[]
 for z in [-.15,.15]:
  for x in [.07,L-.07]:
   b=box(n+'_shield_mount_'+str(z)+'_'+str(x),(.024,.025,.016),(x,.0245,math.copysign(.142,z)),base,support=n+'_base')
  set_support(n+'_side_shield_'+str(z),n+'_shield_mount_'+str(z)+'_0.07')
 for v in PART:
  if v['name'].startswith(n+'_endstop_'):v['pos'][2]=.140
for x in [.94,1.26]:
 b=tube('root_frame_cross_'+str(x),(.04,.06,.50),(x,.4,0),'root_station',support='frame_0_-0.22');set_support('root_stand_'+str(x),b)
 for z in [-.175,.135]:
  h=p('root_guide_pedestal_'+str(x)+'_'+str(z),'bored_z',[.035,.050,.020,.00602,.014],(x,.516,z),'root_station',support=rb)
 set_support('root_guide_'+str(x),'root_guide_pedestal_'+str(x)+'_-0.175')
set_support('root_fixed_plate','root_stand_0.94')
by['root_fixed_plate']['dims'][3]=[[0,.12,.110]]
by['root_hopper']['dims'][1][1]=.479
for r in [1.03,1.17]:set_support('root_blade_'+str(r),'root_holder_'+str(r));set_support('root_counter_'+str(r),'root_counter_pedestal_'+str(r))
set_support('root_knife_bridge','root_guide_bush_0.94')
wh=plate('wash_carriage_extension',(.40,.012,.40),(-.06,.088,0),wash,support='wash_axis_carriage')
for z in [-.16,.16]:
 v=by['wash_tower_'+str(z)];v['dims'][1]=.608;v['pos'][1]=.398;set_support(v['name'],wh)
for x in [-.51,-.37]:
 bar=beam('wash_pipe_cross_'+str(x),[x,.692,-.065],[x,.692,.14],.018,wash,'wash_head_arm_'+str(x))
 for z in [-.065,.065]:set_support('wash_manifold_'+str(x)+'_'+str(z),bar)
 for y in [.20,.33,.46]:
  for z in [-.065,.065]:set_support('wash_nozzle_'+str(x)+'_'+str(y)+'_'+str(z),'wash_manifold_'+str(x)+'_'+str(z))
 for z in [-.04,.04]:
  line=rod('air_knife_inlet_'+str(x)+'_'+str(z),[x,.60,z],[x,.692,z],.006,wash,'blue',bar);set_support('air_knife_'+str(x)+'_'+str(z),line)
set_support('wash_tray','tray_stand_0.66_0.23')
for side in [-1,1]:
 b=box('flap_hinge_base_'+str(side),(.080,.020,.080),(.70,.546,side*.26),'station3',support=tray);set_support('wash_hinge_'+str(side),b)
for x in [-.51,-.37]:
 for n in ['weigh_reach_','weigh_drop_']:
  v=by[n+str(x)]
  for aa in v['dims'][:2]:aa[2]=0
 for z in [-.022,.022]:set_support('weigh_product_guide_'+str(x)+'_'+str(z),'weigh_cup_'+str(x))
for z in [-.20,.20]:
 for x in [-.32,.32]:foot('utility_ground_'+str(x)+'_'+str(z),x,z,'utilities',top=.048)
 set_support('utility_skid_'+str(z),'utility_ground_-0.32_'+str(z)+'_plate')
for x in [-.35,.10]:
 for z in [.32,.72]:foot('tank_ground_'+str(x)+'_'+str(z),x,z,'utilities',top=.048)
plate('tank_skid',(.60,.040,.50),(-.14,.080,.52),'utilities',support='tank_ground_-0.35_0.32_plate')
set_support('water_tank','tank_skid');set_support('FRL_manifold','utility_standoff_-0.12')
for z in [-.105,0,.105]:by['FRL_gauge_'+str(z)]['pos'][1]=1.0845
p('cabinet_gasket','shellbox',[.264,.530,.001,.0003],(-.14,.375,.2105),'utilities','rubber','control_cabinet');set_support('cabinet_door','cabinet_gasket')
by['HMI_screen']['pos'][2]=.0345
p('E_stop_stem','cyl',[.008,.014],(.075,1.277,0),'console','dark','HMI');set_support('E_stop','E_stop_stem')


by={v['name']:v for v in PART}
by['trim_fixed_cross']['dims'][2]=.250
for n in ['trim_knife_drop_0','trim_knife_drop_1']:by[n]['dims'][1][1]=-.4485
for x in [-.54,-.12]:by['trim_cyl_bridge_'+str(x)]['dims'][0]=.120
set_support('reducer_output32','main_32_40_coupling','shaft_coupling')
for v in PART:
 if '_endstop_' in v['name']:v['pos'][1]=.0245
hs=tube('peel_hopper_stand',(.035,.050,.035),(.57,.455,0),'station2',support='central_spoke_1')
set_support('peel_hopper_lip',hs)
for side in [-1,1]:beam('peel_hopper_brace_'+str(side),[.40,.430,side*.22],[.40,.480,side*.17],.018,'station2','frame_1_'+str(side*.22))


by={v['name']:v for v in PART}
# Running clearances are cut into the guide blocks; rods do not pass through solids.
for v in PART:
 if '_jaw_body_' in v['name']:v['kind']='jaw_block';v['dims']=[]
 if v['name'].startswith('peel_half_slide_'):v['kind']='bored_z';v['dims']=[.060,.016,.026,.00402,0]
by['pack_interface_label']['cad']=False
by['tank_skid']['kind']='rhs_round';by['tank_skid']['dims']=[.60,.040,.50,.003]
for y in [.46,.54]:
 for j in range(10):
  a=j*math.tau/10;p('outfeed_6207_ball_'+str(y)+'_'+str(j),'sphere',[.0035],(.0265*math.cos(a),y,.0265*math.sin(a)),'outfeed','chrome','outfeed_6207_outer_'+str(y),join='rolling')
by['feed_spindle_housing']['dims'][2]=.045;by['feed_spindle_housing']['dims'][3]=.03601
for y in [.455,.515]:
 ring('feed_6207_outer_'+str(y),[0,y-.0085,0],[0,y+.0085,0],.036,.030,'feeder','dark','feed_spindle_housing')
 ring('feed_6207_inner_'+str(y),[0,y-.0085,0],[0,y+.0085,0],.023,.01751,'magazine','chrome','feed_spindle')
 for j in range(10):
  a=j*math.tau/10;p('feed_6207_ball_'+str(y)+'_'+str(j),'sphere',[.0035],(.0265*math.cos(a),y,.0265*math.sin(a)),'feeder','chrome','feed_6207_outer_'+str(y),join='rolling')
ring('feed_spindle_hub',[0,.535,0],[0,.544,0],.060,.01751,'magazine',support='feed_spindle')
set_support('feed_disc','feed_spindle_hub')


# The union restraint stays above the rotating hub, with an independent overhead support.
by={v['name']:v for v in PART}
by['union_restraint_bracket']['dims'][0]=[.11,1.510,0]
by['union_restraint_bracket']['dims'][1]=[.11,1.640,0]
by['union_bracket_root']['dims'][0]=[.070,1.640,0]
by['union_bracket_root']['dims'][1]=[.110,1.640,0]
mast=beam('union_overhead_mast',[.80,.430,0],[.80,1.640,0],.030,'fixed','guard_base_0')
overhead=beam('union_overhead_beam',[.80,1.640,0],[.110,1.640,0],.025,'fixed',mast)
set_support('union_restraint_bracket',overhead);set_support('union_bracket_root',overhead)
# Open-position latch pins are present for the empty indexing review.
for side in [-1,1]:
 j=next(j for j in JOINTS if j['name']=='wash_flap_'+str(side));j['limits']=[-math.pi/2,math.pi/2]
 ring('flap_latch_sector_'+str(side),[.72,1.335,side*.275],[.72,1.341,side*.275],.030,.0061,'station3',support='wash_hinge_'+str(side))
 rod('flap_latch_pin_'+str(side),[.745,1.330,side*.275],[.745,1.350,side*.275],.003,'station3','orange','flap_latch_sector_'+str(side))


def apply_home():
 for j in JOINTS:
  if j['type']=='prismatic':
   ob=next(x for x in GROUP if x['name']==j['child']);off=np.array(j.get('offset',[0,0,0]),float);ob['pos']=(off+np.array(j['axis'])*j.get('home',0)).tolist()
 for a in AXES:
  ob=next(x for x in GROUP if x['name']==a['rotor']);ob['roll']=0
 k.GM.clear();k.GL.clear()
 for ob in GROUP:
  k.GM[ob['name']]=(k.GM[ob['parent']] if ob['parent'] else np.eye(4))@k.mat4(ob)
  k.GL[ob['name']]=(k.GL[ob['parent']] if ob['parent'] else cq.Location())*k.loc(ob)
from refine07 import install as refine_structure
refine_structure(__import__(__name__))
from refine10 import install as refine_exchange
refine_exchange(__import__(__name__))
from refine11 import install as refine_dry_process
refine_dry_process(__import__(__name__))
apply_home()
from service_routes import install as install_services
SERVICES=install_services(__import__(__name__))
from refine10 import after_services
after_services(__import__(__name__))
from refine11 import after_services as refine_dry_services
refine_dry_services(__import__(__name__))
apply_home()

if __name__=='__main__':
 stats=k.build()
 # Exporter places roll+yaw consistently with the STEP placements.
 raw=(k.DIST/'cell.glb').read_bytes();sz=struct.unpack_from('<I',raw,12)[0];obj=json.loads(raw[20:20+sz]);binary=raw[28+sz:]
 from scipy.spatial.transform import Rotation
 by={v['name']:v for v in PART}
 for node in obj['nodes']:
  if node.get('mesh') is not None:
   src=by[node['name']];node['rotation']=Rotation.from_matrix(k.mat4(src)[:3,:3]).as_quat().tolist();node['extras'].update(support=src.get('support'),connection=src.get('connection','product'))
 obj['asset']['generator']='Scallion Mechanical Review 11 / guided dry process modules'
 js=json.dumps(obj,separators=(',',':')).encode();js+=b' '*(-len(js)%4);out=struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary
 (k.DIST/'cell.glb').write_bytes(out);(k.OUT/'SCALLION_CELL.glb').write_bytes(out)
 data=dict(revision='MECHANICAL-11',joints=JOINTS,linear_axes=AXES,cylinders=CYL,mounts=MOUNTS,contact_checks=CONTACTS,services=SERVICES,stats=stats,limitations=['采购件内部为安装与运动简化表达，非厂家原版CAD','气水路为名义管径与定长软管布置，阀岛内部和PLC未冻结','成袋和封切为自制名义机构，膜张力、温度、压力和实料工艺未验收','未完成整机连续碰撞、疲劳、实料及电气验证'])
 (k.DIST/'mechanics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 print('Joints',len(JOINTS),'axes',len(AXES),'cylinders',len(CYL),flush=True)
