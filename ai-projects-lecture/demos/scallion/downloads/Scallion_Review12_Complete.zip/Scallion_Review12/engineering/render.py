"""CPU path-traced, geometry-derived inspection views. No generated imagery."""
import sys,os,math,json,struct,time,re,gzip
from pathlib import Path
import numpy as np
import mitsuba as mi
from PIL import Image
mi.set_variant('llvm_ad_rgb')
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'renders';OUT.mkdir(exist_ok=True)

def load_glb(path):
 raw=path.read_bytes() if path.exists() else gzip.decompress(path.with_suffix('.glb.gz').read_bytes());n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);b=raw[28+n:]
 def acc(i):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];types={5126:'<f4',5125:'<u4',5123:'<u2',5122:'<i2',5121:'u1',5120:'i1'};components={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
  arr=np.frombuffer(b,dtype=types[a['componentType']],count=a['count']*components[a['type']],offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],components[a['type']])
  if a.get('normalized'):arr=arr.astype(float)/(127 if a['componentType']==5120 else 32767)
  return arr
 meshes=[]
 def walk(i,parent=np.eye(4),anc=()):
  node=g['nodes'][i];name=node.get('name','');anc=anc+(name,)
  if 'matrix' in node:M=np.array(node['matrix']).reshape(4,4).T
  else:
   x,y,z,w=node.get('rotation',[0,0,0,1]);M=np.array([[1-2*y*y-2*z*z,2*x*y-2*w*z,2*x*z+2*w*y,0],[2*x*y+2*w*z,1-2*x*x-2*z*z,2*y*z-2*w*x,0],[2*x*z-2*w*y,2*y*z+2*w*x,1-2*x*x-2*y*y,0],[0,0,0,1]],float);M[:3,3]=node.get('translation',[0,0,0]);M[:3,:3]*=node.get('scale',[1,1,1])
  world=parent@M
  if 'mesh' in node:
   p=g['meshes'][node['mesh']]['primitives'][0];v=acc(p['attributes']['POSITION']);nr=acc(p['attributes']['NORMAL']);indices=acc(p['indices']).reshape(-1,3).astype(np.uint32)
   v=v@world[:3,:3].T+world[:3,3];nr=nr@world[:3,:3].T;nr/=np.maximum(np.linalg.norm(nr,axis=1)[:,None],1e-10)
   meshes.append({'name':name,'path':anc,'v':v,'n':nr,'i':indices,'mat':p['material'],'extras':node.get('extras',{})})
  for ch in node.get('children',[]):walk(ch,world,anc)
 for n in g['scenes'][0]['nodes']:walk(n)
 return g,meshes

def visible(m,mode):
 n=m['name'];a=m['path'];mat=m['extras'].get('material','')
 if 'guard' in a or n.startswith(('guard_post_','guard_top_ring','outer_guard_foot_')):return False
 if mat=='glass' or n=='main_column' or n=='pack_interface_label':return False
 if mode=='overview' and n.startswith(('hose_cylinder_','hose_supply_grip_','hose_branch_loader','hose_branch_unload','hose_supply_loader_grip_1','hose_supply_unload_grip_1','hose_half_fixed_feed_','hose_lead_fixed_','hose_lead_moving_')):return False
 if mode=='overview':return True
 if mode=='utility':return not n.startswith(('product_','stock_'))
 if mode=='drive':return ('drive' in a or 'rotary_union' in a or n.startswith(('main_shaft','main_32','main_6208_inner','rotor_hub','reducer_output','shaft_','union_rotor')))
 if mode=='axis':return 'load_axis' in a
 if mode=='peel':return 'station2' in a
 if mode=='magazine':return 'magazine' in a or n.startswith('feed_')
 if mode=='trim':return 'trim_axis' in a or n.startswith(('trim_gantry','trim_top_cross','trim_axis_hanger','frame_0_','frame_cross_0_','leg_0_','foot_0_'))
 if mode=='root':return 'root_station' in a
 if mode=='clamp':return 'carrier_0' in a and not n.startswith('product_')
 if mode=='wrap':return 'wrap_axis' in a or n.startswith(('wrap_base_cross11_','frame_3_','frame_cross_3_','leg_3_','foot_3_'))
 if mode=='seal':return 'seal_axis' in a or n.startswith(('seal_base_cross11_','seal_axis_ground11_','seal_axis_leg11_','seal_front_leg_extension11'))
 if mode=='weigh':return ('weigh_axis' in a) and not n.startswith('product_')
 if mode=='wash':return 'station3' in a
 if mode=='outfeed':return 'outfeed' in a
 return False

def merge_meshes(ms,materials):
 out={}
 for mat in set(m['mat'] for m in ms):
  group=[m for m in ms if m['mat']==mat];vs=[];ns=[];ids=[];offset=0
  for m in group:
   vs.append(m['v']);ns.append(m['n']);ids.append(m['i']+offset);offset+=len(m['v'])
  v=np.concatenate(vs).astype(np.float32);n=np.concatenate(ns).astype(np.float32);ix=np.concatenate(ids).astype(np.uint32)
  shape=mi.Mesh('material_'+str(mat),len(v),len(ix),has_vertex_normals=True)
  params=mi.traverse(shape);params['vertex_positions']=v.reshape(-1);params['vertex_normals']=n.reshape(-1);params['faces']=ix.reshape(-1);params.update()
  glmat=materials[mat]['pbrMetallicRoughness'];color=glmat['baseColorFactor'][:3]
  # Linearise authored sRGB swatches, matching the GLTFLoader interpretation.
  color=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in color]
  bsdf=mi.load_dict({'type':'principled','base_color':{'type':'rgb','value':color},'metallic':glmat.get('metallicFactor',0),'roughness':max(.14,glmat.get('roughnessFactor',.4))})
  shape.set_bsdf(bsdf);out['geometry_'+str(mat)]=shape
 return out

def render(mode,g,allmeshes,width=1440,height=1040,spp=48):
 ms=[m for m in allmeshes if visible(m,mode)]
 vv=np.concatenate([m['v'] for m in ms]);lo=vv.min(axis=0);hi=vv.max(axis=0);target=(lo+hi)/2
 dims=hi-lo;size=max(dims);target[1]-=dims[1]*.015
 views={'wrap':[1.3,.8,1.4],'seal':[1.3,.8,1.4],'overview':[1.20,.88,1.36],'magazine':[1.1,.9,1.4],'trim':[1.1,.6,1.4],'drive':[1.05,.70,1.35],'peel':[1.15,.64,1.45],'root':[1.1,.78,1.55],'clamp':[1.3,.70,1.3],'weigh':[1.4,.8,1.25],'utility':[1.0,.80,1.25],'axis':[1.1,.9,1.6],'wash':[1.3,.8,1.2],'outfeed':[1.2,1.0,1.4]}
 direction=np.asarray(views[mode]);direction/=np.linalg.norm(direction)
 forward=-direction;right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward)
 corners=vv[::max(1,len(vv)//60000)]-target
 tx=math.tan(math.radians(34)/2);ty=tx/(width/height)
 dist=max(np.max(np.abs(corners@right)/tx-corners@forward),np.max(np.abs(corners@up)/ty-corners@forward))*1.12
 origin=target+direction*dist
 sensor={'type':'perspective','fov':34,'to_world':mi.ScalarTransform4f.look_at(origin=origin,target=target,up=[0,1,0]),'sampler':{'type':'independent','sample_count':spp},'film':{'type':'hdrfilm','width':width,'height':height,'rfilter':{'type':'tent'}}}
 floor_y=-.0001 if mode in ['overview','utility','peel','weigh','wash','outfeed'] else lo[1]-.005
 scene={'type':'scene','integrator':{'type':'path','max_depth':5,'rr_depth':3,'hide_emitters':True},'sensor':sensor,'environment':{'type':'constant','radiance':{'type':'rgb','value':[.18,.22,.28]}},'floor':{'type':'rectangle','to_world':mi.ScalarTransform4f.translate([0,floor_y,0])@mi.ScalarTransform4f.rotate([1,0,0],-90)@mi.ScalarTransform4f.scale([100,100,1]),'bsdf':{'type':'diffuse','reflectance':{'type':'rgb','value':[.022,.038,.051]}}}}
 for i,(direction,power,scale) in enumerate([([-.7,1.5,1],3.8,.9),([1.2,1,-.9],5.0,.65),([1,1.0,1.8],1.6,.65)]):
  point=target+np.array(direction)*size
  scene['softbox_'+str(i)]={'type':'rectangle','to_world':mi.ScalarTransform4f.look_at(origin=point,target=target,up=[0,1,0])@mi.ScalarTransform4f.scale([size*scale,size*scale*.75,1]),'emitter':{'type':'area','radiance':{'type':'rgb','value':[power,power,power]}}}
 scene.update(merge_meshes(ms,g['materials']));s=mi.load_dict(scene)
 start=time.time();print('render',mode,'triangles',sum(len(m['i']) for m in ms),flush=True)
 img=mi.render(s,spp=spp,seed=13)
 path=OUT/(mode+'.png');bitmap=mi.Bitmap(img*.95).convert(mi.Bitmap.PixelFormat.RGB,mi.Struct.Type.UInt8,True)
 pixels=np.array(bitmap)
 try:
  import cv2
  pixels=cv2.fastNlMeansDenoisingColored(pixels,None,4.5,4.5,7,21)
 except ImportError:pass
 Image.fromarray(pixels).save(path)
 Image.open(path).convert('RGB').save(OUT/(mode+'.jpg'),quality=92,optimize=True)
 (OUT/(mode+'.json')).write_text(json.dumps({'visible_meshes':len(ms),'triangles':sum(len(m['i']) for m in ms)}))
 print(mode,'done',round(time.time()-start,1),flush=True)

if __name__=='__main__':
 g,meshes=load_glb(ROOT/'dist/downloads/SCALLION_CELL.glb')
 for mode in (sys.argv[1:] or ['overview','drive','axis','peel','root','clamp','wash','weigh','outfeed']):
  render(mode,g,meshes,width=1440 if mode=='overview' else 1120,height=1100 if mode=='overview' else 900,spp=96)
