"""Revision 07: explicit clearances, relocated supports and motion envelopes.
All dimensions are nominal design geometry in metres, not manufacturing tolerances.
"""
import math,json
import numpy as np
import cadquery as cq

def install(m):
 k=m.k;by={p['name']:p for p in m.PART};gb={g['name']:g for g in m.GROUP};old=k.shape_for
 def update(n,kind=None,dims=None,pos=None):
  p=by.get(n) or next(p for p in m.PART if p['name']==n);by[n]=p
  if kind:p['kind']=kind
  if dims is not None:p['dims']=dims
  if pos is not None:p['pos']=list(pos)
  return p
 def shift(n,delta):by[n]['pos']=(np.array(by[n]['pos'])+delta).tolist()
 def bored(n,r):
  p=by[n]
  if p['kind']=='drilled':p['dims'][3].append([0,0,r])
  elif p['kind']=='cyl':p['kind']='ring';p['dims']=[r,p['dims'][0],p['dims'][1],0,360]
 def shape(t,d):
  key=json.dumps([t,d])
  if key in k.CQ_CACHE:return k.CQ_CACHE[key]
  if t=='grip_tab_bored':
   w,h,z,dy=d;s=cq.Workplane('XY').box(w,h,z).val()
   for x,r in [(0,.0092),(-.036,.0042),(.036,.0042)]:s=s.cut(m.axis_cylinder([x,dy,-z/2-.002],[x,dy,z/2+.002],r))
  elif t=='feed_disc_open':
   ri,ro,h=d;s=old('ring',[ri,ro,h,0,360])
   for i in range(12):
    a=i*math.tau/12
    for r in [.18,.32]:
     x,z=r*math.cos(a),r*math.sin(a);s=s.cut(m.axis_cylinder([x,-h,z],[x,h,z],.0153))
  elif t=='wall_line':
   a,b,h,w=d;a,b=np.array(a),np.array(b);v=b-a;L=np.linalg.norm(v);s=cq.Workplane('XY').box(L,h,w).val().rotate((0,0,0),(0,1,0),-math.degrees(math.atan2(v[2],v[0]))).translate(tuple((a+b)/2))
  elif t=='sector_tray':
   outline,ox,oz,fall,t=d;outer=[cq.Vector(x,fall,z) for x,z in outline];inner=[cq.Vector(ox+sx*.035,0,oz+sz*.035) for sx,sz in [(-1,-1),(1,-1),(1,1),(-1,1)]];panels=[]
   for i in range(4):
    pts=[outer[i],outer[(i+1)%4],inner[(i+1)%4],inner[i]]
    for tri in [[pts[0],pts[1],pts[2]],[pts[0],pts[2],pts[3]]]:panels.append(cq.Solid.extrudeLinear(cq.Wire.makePolygon(tri+[tri[0]]),[],cq.Vector(0,-t,0)))
   floor=cq.Workplane('XY').box(.07,t,.07).val().translate((ox,-t/2,oz)).cut(m.axis_cylinder([ox,-t-.001,oz],[ox,.001,oz],.018));s=cq.Compound.makeCompound(panels+[floor])
  elif t=='belt_loop_z':
   R,t,L,w=d
   def cap(r):return cq.Workplane('XY').moveTo(-r,-L/2).lineTo(-r,L/2).threePointArc((0,L/2+r),(r,L/2)).lineTo(r,-L/2).threePointArc((0,-L/2-r),(-r,-L/2)).close().extrude(w).val().translate((0,0,-w/2))
   s=cap(R+t/2).cut(cap(R-t/2))
  elif t=='air_distribution_ring':
   ri,ro,h=d;s=old('ring',[ri,ro,h,0,360]).cut(old('ring',[ri+.003,ro-.003,h-.006,0,360]))
   for i in range(6):
    a=i*math.pi/3;v=np.array([math.cos(a),0,math.sin(a)]);s=s.cut(m.axis_cylinder(v*(ro-.005),v*(ro+.002),.003))
   s=s.cut(m.axis_cylinder([ri-.002,0,0],[ri+.006,0,0],.003))
  elif t=='trim_frame_open':
   w,h,z=d;s=cq.Workplane('XY').box(w,h,z).val()
   s=s.cut(m.axis_cylinder([.10,0,-z],[.10,0,z],.0102))
   for x in [-.16,.16]:s=s.cut(m.axis_cylinder([x,0,-z],[x,0,z],.0052))
  else:return old(t,d)
  if not s.isValid():raise ValueError(t)
  k.CQ_CACHE[key]=s;return s
 k.shape_for=shape

 # Shaft penetrations are actual holes, including coupler maintenance clearance.
 for n,r in [('foundation_centre',.039),('main_column_base',.0203),('main_column_spacer',.0203),('gearbox_mount',.039),('planetary_80to1',.0162),('feed_base',.0265),('feed_reducer',.0177),('outfeed_mount',.0265),('outfeed_reducer',.0265)]:bored(n,r)
 # Reduce a zero-clearance coincident shoulder face by 0.1 mm axially.
 by['shaft_axial_shoulder']['dims'][0][1]=.5771;by['shaft_axial_shoulder']['dims'][1][1]=.5810
 by['union_rotor_stub']['dims'][1][1]=1.592
 # Guard supports sit BETWEEN working radial axes, on connected radial outriggers.
 for i in range(6):
  a=math.radians(30+i*60);pt=np.array([2.45*math.cos(a),.10,2.45*math.sin(a)])
  update('guard_post_'+str(i),'rhs_axis',[pt.tolist(),[pt[0],1.85,pt[2]],.040,.002])
  s=(-i-3)%6+1;par='station'+str(s)
  # Build in world coordinates, one end touching the existing station side frame.
  M=k.mat4(gb[par]);q=M@np.array([.62,.415,-.22,1])
  fp=m.foot('outer_guard_foot_'+str(i),pt[0],pt[2],top=.088)
  update('guard_base_'+str(i),'drilled',[.10,.012,.10,[]],(pt[0],.094,pt[2]))['parent']='fixed'
  m.set_support('guard_base_'+str(i),fp)
  m.set_support('guard_post_'+str(i),fp)
 oldbases={'guard_base_'+str(i) for i in range(6)};m.PART[:]=[p for p in m.PART if p['name'] not in oldbases];m.MOUNTS[:]=[p for p in m.MOUNTS if p['part'] not in oldbases]
 update('guard_top_ring',dims=[2.430,2.470,.020,0,360],pos=(0,1.85,0))
 # The union mast clears the weighing axis and its lift throughout its stroke.
 update('union_overhead_mast',dims=[[.70,.43,.35],[.70,1.64,.35],.030,.003])
 update('union_overhead_beam',dims=[[.70,1.64,.35],[.11,1.64,0],.025,.003])
 mb=m.beam('union_mast_foot',[.70,.415,.22],[.70,.415,.35],.030,'station4','frame_3_0.22')
 m.set_support('union_overhead_mast',mb)

 for a in m.AXES:
  n=a['name'];L=a['L']
  update(n+'_servo_200W','bored_x',[.090,.060,.060,.0052,0])
  update(n+'_nut_housing',dims=[.040,.056,.055,.01404,-.005],pos=(0,.042,0))
  # Removable side covers stand outside the moving towers and support outriggers.
  for z in [-.15,.15]:
   update(n+'_side_shield_'+str(z),dims=[L,.050,.002,.0003],pos=(L/2,.037,math.copysign(.24,z)))
   for x in [.07,L-.07]:
    update(n+'_shield_mount_'+str(z)+'_'+str(x),dims=[.024,.026,.110,.001],pos=(x,.0245,math.copysign(.187,z)))
 # Bore the rear installation ears for both guides and the cylinder rod.
 for i in range(6):
  by['grip_bridge_'+str(i)]['pos'][2]=.180;by['grip_spine_'+str(i)]['pos'][2]=.180
  for l in range(2):update(f'grip_tab_{i}_{l}','grip_tab_bored',[.10,.037,.060,-.0085])

 # Loader/unloader sit above the discs, grip BELOW the carousel clamps, and park
 # outside the magazine envelope. The pickup coordinate remains q=.70/.75.
 for prefix,axis,station,final_y in [('loader','load_axis',1,.920),('unload','unload_axis',5,.920)]:
  lateral=.60;gb[axis]['pos'][2]=lateral
  old_y=.970 if prefix=='loader' else .950;basey=gb[axis]['pos'][1];dy=final_y-old_y-(basey-.430)
  # Original mast upper components translate down relative to the raised base.
  cross_y=(.515 if prefix=='loader' else .500)+dy
  for z in [-.14,.14]:
   mast=by[prefix+'_mast_'+str(z)];top=cross_y-.015
   update(mast['name'],dims=[.035,top-.094,.035,.003],pos=(0,(top+.094)/2,math.copysign(.20,z)))
   leg=m.box(prefix+'_outrigger_'+str(z),(.10,.012,.135),(0,.088,math.copysign(.1675,z)),axis+'_slide',support=axis+'_carriage')
   m.set_support(mast['name'],leg)
  update(prefix+'_cross',dims=[.045,.030,.435,.003],pos=(0,cross_y,0))
  bridge=m.beam(prefix+'_transverse_reach',[0,cross_y,0],[0,cross_y,.12-lateral],.035,axis+'_slide',prefix+'_cross')
  for l in range(2):
   shift(prefix+'_reach_'+str(l),[0,dy,0]);shift(prefix+'_grip_tab_'+str(l),[0,dy,0])
   shift(prefix+'_reach_'+str(l),[0,0,-lateral]);shift(prefix+'_grip_tab_'+str(l),[0,0,-lateral]);m.set_support(prefix+'_reach_'+str(l),bridge)
   gb[prefix+'_grip_'+str(l)]['pos'][2]-=lateral
   gb[prefix+'_grip_'+str(l)]['pos'][1]+=dy
   tab=by[prefix+'_grip_tab_'+str(l)];h=tab['dims'][1];dyhole=gb[prefix+'_grip_'+str(l)]['pos'][1]-tab['pos'][1]
   update(tab['name'],'grip_tab_bored',[.10,h,.060,dyhole])
  for x in [.02,.90,1.15]:
   cross=m.tube(axis+'_raised_cross_'+str(x),(.050,.050,.50),(x+.60,basey-.025,lateral),'station'+str(station),support=None)
   arm=m.beam(axis+'_frame_outrigger_'+str(x),[x+.60,.415,math.copysign(.22,lateral)],[x+.60,.415,lateral+math.copysign(.22,lateral)],.030,'station'+str(station),f'frame_{station-1}_{math.copysign(.22,lateral)}')
   for z in [-.20,.20]:
    leg=m.tube(axis+'_riser_'+str(x)+'_'+str(z),(.04,basey-.480,.04),(x+.60,(basey+.380)/2,z+lateral),'station'+str(station),support=arm)
    m.contact(cross,leg)
   m.set_support(axis+'_base',cross)
  # Base and upper frame outside the former 1.72m envelope, with grounded feet.
  for z in [-.22,.22]:
   ext=m.tube(axis+'_frame_extension_'+str(z),(.55,.060,.060),(1.995,.40,z),'station'+str(station),support=f'frame_{station-1}_{z}')
   fp=m.foot(axis+'_outer_foot_'+str(z),2.22,z,'station'+str(station))
   m.tube(axis+'_outer_leg_'+str(z),(.06,.273,.06),(2.22,.2335,z),'station'+str(station),support=fp)
   m.contact(ext,axis+'_outer_leg_'+str(z))
  m.set_support(axis+'_frame_outrigger_1.15',axis+'_frame_extension_'+str(math.copysign(.22,lateral)))
 # Root mechanism is above cup rims. Rear barrel is OUTSIDE the rotating disc.
 gb['root_station']['pos'][1]=.115
 for n in ['root_waste','root_frame_cross_0.94','root_frame_cross_1.26']:shift(n,[0,-.115,0])
 for x in [.94,1.26]:
  st=by['root_stand_'+str(x)];st['dims'][1]+=.115;st['pos'][1]-=.0575
  st['pos'][2]=-.47
  by['root_frame_cross_'+str(x)]['dims'][2]=1.00
  leg=m.tube('root_front_stand_'+str(x),(.035,st['dims'][1],.035),(x,st['pos'][1],.47),'root_station',support='root_frame_cross_'+str(x));m.contact(leg,'root_fixed_plate')
 update('root_fixed_plate',dims=[.37,.012,1.00,[[-.07,0,.030],[.07,0,.030]]],pos=(1.10,.485,0))
 shift('root_hopper',[0,-.115,0]);update('root_cylinder_rear_mount',pos=(1.10,.556,-.580))
 by['root_hopper']['dims'][1][1]=.543
 hanger=m.beam('root_hopper_hanger',[1.230,.479,-.470],[1.230,.420,-.470],.012,'root_station','root_fixed_plate')
 hook=m.beam('root_hopper_hook',[1.230,.420,-.470],[1.220,.420,0],.012,'root_station',hanger);m.set_support('root_hopper',hook)
 for x in [1.04,1.16]:
  bb=m.beam('root_rear_bridge_'+str(x),[x,.485,-.480],[x,.485,-.580],.025,'root_station','root_fixed_plate')
  vv=m.beam('root_rear_riser_'+str(x),[x,.485,-.580],[x,.511,-.580],.025,'root_station',bb);m.set_support('root_cylinder_rear_mount',vv)
 update('root_rod_clevis','bored_z',[.050,.050,.018,.0127,-.010],pos=(1.10,.565,-.10))
 update('root_knife_bridge',dims=[.36,.018,.025,.001],pos=(1.10,.550,-.1125))
 for x in [.94,1.26]:
  by['root_guide_'+str(x)]['dims'][0][2]=-.265;by['root_guide_'+str(x)]['dims'][1][2]=.220
  for z,target in [(-.175,-.255),(.135,.210)]:
   by['root_guide_pedestal_'+str(x)+'_'+str(z)]['pos'][2]=target
 # Rotating upper carrier spokes support short clip stems, clear of transfer jaws.
 by['feed_spindle']['dims'][1][1]=.755
 update('feed_disc','feed_disc_open',[.01751,.380,.012])
 hub=m.ring('feed_upper_hub',[0,.735,0],[0,.755,0],.045,.0176,'magazine',support='feed_spindle')
 for i in range(12):
  a=i*math.tau/12;t=np.array([-math.sin(a),0,math.cos(a)])
  for l,r in enumerate([.18,.32]):
   x,z=r*math.cos(a),r*math.sin(a);v=np.array([x,0,z])+t*.043
   post=by[f'feed_clip_post_{i}_{l}'];post['dims']=[[v[0],.750,v[2]],[v[0],.860,v[2]],.012,.0015]
   sp=m.beam(f'feed_clip_spoke_{i}_{l}',[.035*math.cos(a),.750,.035*math.sin(a)],[v[0],.750,v[2]],.010,'magazine',hub);m.set_support(post['name'],sp)
   update(f'feed_clip_{i}_{l}',pos=(x,.860,z))
   by[f'feed_clip_{i}_{l}']['dims'][3]=math.degrees(a)+25
   update(f'feed_clip_tab_{i}_{l}','rhs_axis',[[v[0],.860,v[2]],[x+t[0]*.017,.860,z+t[2]*.017],.012,.0015],(0,0,0))
   cup=by[f'feed_cup_{i}_{l}'];update(cup['name'],'axisring',[[0,0,0],[0,.030,0],.023,.015],(x,.556,z))
 # Gantry columns clear the complete magazine disc, not just its centre.
 for z in [-.24,.24]:
  zz=math.copysign(1.25,z)
  update('trim_gantry_'+str(z),dims=[.05,1.82,.05,.003],pos=(2.10,1.34,zz))
  update('trim_gantry_beam_'+str(z),dims=[1.765,.05,.05,.003],pos=(1.2675,2.225,zz))
  brace=m.beam('trim_gantry_foot_'+str(z),[1.66,.415,math.copysign(.22,z)],[2.10,.415,zz],.030,'station1','frame_0_'+str(-.22 if z<0 else .22));m.set_support('trim_gantry_'+str(z),brace)
  fp=m.foot('trim_gantry_ground_'+str(z),2.10,zz,'station1');leg=m.tube('trim_gantry_lower_leg_'+str(z),(.05,.303,.05),(2.10,.2485,zz),'station1',support=fp);m.contact(leg,brace)
 for x in [.75,1.55]:
  br=m.tube('trim_top_cross_'+str(x),(.050,.050,2.55),(x,2.250,0),'station1',support='trim_gantry_beam_-0.24')
  for z in [-.145,.145]:
   zz=.30 if z<0 else z
   hanger=m.beam('trim_axis_hanger_'+str(x)+'_'+str(z),[x,1.950,zz],[x,2.225,zz],.020,'station1',br)
   tab=m.plate('trim_axis_hanger_tab_'+str(x)+'_'+str(z),(.080,.012,.080),(x,1.956,math.copysign(.13,z)),'station1',support=hanger);m.contact(tab,'trim_axis_base')
   if z<0:update(tab,dims=[.080,.012,.24,[]],pos=(x,1.956,.20))
 gb['trim_axis']['pos'][1]=1.950
 m.set_support('trim_axis_base','trim_axis_hanger_tab_0.75_-0.145')
 # Hanging frame reaches have discrete spacers above the moving-axis base.
 for x in [-.40,-.26]:
  update('trim_drop_'+str(x),dims=[.025,.434,.025,.003],pos=(x,-.100,-.30))
  update('trim_reach_'+str(x),dims=[[.03,.130,-.11],[x,.130,-.30],.026,.003])
  spacer=m.box('trim_reach_spacer_'+str(x),(.06,.035,.04),(.03,.0995,-.11),'trim_axis_slide',support='trim_axis_carriage');m.set_support('trim_reach_'+str(x),spacer)
  tie=m.beam('trim_bottom_reach_'+str(x),[x,-.317,-.30],[x,-.380,-.30],.025,'trim_axis_slide','trim_drop_'+str(x))
  link=m.beam('trim_fixed_frame_link_'+str(x),[x,-.380,-.30],[x,-.380,.20],.025,'trim_axis_slide',tie)
  post=m.beam('trim_front_cross_post_'+str(x),[x,-.380,.20],[x,-.337,.20],.025,'trim_axis_slide',link);m.set_support('trim_fixed_cross',post)
 update('trim_fixed_cross','trim_frame_open',[.38,.020,.060],pos=(-.33,-.327,.20))
 for x in [-.49,-.17]:by['trim_guide_'+str(x)]['dims'][0][2]=-.50;by['trim_guide_'+str(x)]['dims'][1][2]=.235
 rear=m.beam('trim_rear_guide_cross',[-.52,-.380,-.480],[-.14,-.380,-.480],.020,'trim_axis_slide','trim_fixed_frame_link_-0.4')
 m.beam('trim_rear_guide_link',[-.40,-.380,-.30],[-.40,-.380,-.480],.020,'trim_axis_slide','trim_fixed_frame_link_-0.4');m.set_support(rear,'trim_rear_guide_link')
 for x in [-.49,-.17]:
  seat=m.p('trim_rear_guide_seat_'+str(x),'bored_z',[.040,.060,.025,.00502,.015],(x,-.342,-.480),'trim_axis_slide','aluminum',rear);m.contact(seat,'trim_guide_'+str(x))
 counter_cross=m.beam('trim_counter_support_cross',[-.54,-.250,.20],[-.30,-.250,.20],.016,'trim_axis_slide','trim_front_cross_post_-0.4')
 for x in [-.40,-.32]:
  post=m.beam('trim_counter_cross_riser_'+str(x),[x,-.337,.20],[x,-.258,.20],.016,'trim_axis_slide','trim_fixed_cross');m.set_support(counter_cross,post)
 for l,x in enumerate([-.49,-.35]):
  # The moving drop is in front of the fixed guide crossmember.
  update('trim_knife_drop_'+str(l),dims=[[x,-.337,-.17],[x,-.7685,-.17],.020,.003])
  m.set_support('trim_knife_drop_'+str(l),'trim_knife_tie')
  sole=m.beam('trim_blade_foot_'+str(l),[x,-.7685,-.17],[x,-.7685,-.09],.020,'trim_knife','trim_knife_drop_'+str(l));m.set_support('trim_blade_'+str(l),sole)
  by['trim_blade_'+str(l)]['pos'][1]=-.770
  by['trim_counter_'+str(l)]['pos'][1]=-.7806
  update('trim_counter_stand_'+str(l),'bored_z',[.090,.5336,.025,.0052,.1958],pos=(x,-.5228,-.230))
  cap=m.beam('trim_counter_upper_tie_'+str(l),[x,-.250,-.230],[x,-.250,.200],.012,'trim_axis_slide',counter_cross);m.set_support('trim_counter_stand_'+str(l),cap)
  shoe=m.beam('trim_counter_shoe_'+str(l),[x,-.7956,-.230],[x,-.7956,.040],.012,'trim_axis_slide','trim_counter_stand_'+str(l));m.set_support('trim_counter_'+str(l),shoe)
 update('trim_knife_tie','trim_frame_open',[.36,.02,.048],pos=(-.33,-.327,-.17))
 update('trim_cyl_rear_mount',dims=[.180,.070,.008,.001],pos=(-.23,-.302,-.470))
 for x,target in [(-.54,-.28),(-.12,-.18)]:
  for n in ['trim_cyl_support_','trim_cyl_bridge_']:
   pp=by[n+str(x)];pp['pos'][0]+=target-x
  by['trim_cyl_support_'+str(x)]['pos'][1]-=.010
  by['trim_cyl_support_'+str(x)]['dims'][0][2]=-.490
  by['trim_cyl_support_'+str(x)]['dims'][1][2]=.170
  by['trim_cyl_bridge_'+str(x)]['pos'][2]=.170
  stay=m.beam('trim_rear_flange_stay_'+str(x),[target,-.347,-.470],[target,-.337,-.470],.016,'trim_axis_slide','trim_cyl_support_'+str(x));m.contact(stay,'trim_cyl_rear_mount')
  m.set_support('trim_cyl_rear_mount',stay)
 for n in ['trim_drop_-0.26','trim_reach_-0.26','trim_bottom_reach_-0.26','trim_fixed_frame_link_-0.26','trim_front_cross_post_-0.26']:
  p=by.get(n) or next(p for p in m.PART if p['name']==n)
  if p['kind'] in ['rhs_axis']:
   for q in p['dims'][:2]:
    if abs(q[0]+.26)<1e-8:q[0]=-.32
  else:p['pos'][0]-=.060
 # Head guides and actuator rods have distinct centre-lines, 22mm apart.
 for l in range(2):
  for s in [-1,1]:
   for n in [f'peel_half_guide_{l}_{s}',f'peel_guide_bush_{l}_{s}']:
    for a in by[n]['dims'][:2]:a[1]=.050
   update(f'peel_half_slide_{l}_{s}',pos=(by[f'peel_half_slide_{l}_{s}']['pos'][0],.050,s*.060))
   by[f'peel_half_bridge_{l}_{s}']['dims'][1][1]=.050;by[f'peel_half_bridge_{l}_{s}']['dims'][1][0]-=.030
 # Half-ring split clearance is cut in the hollow manifold, without moving rod datums.
 # Motor is above the vertical stage; a dropped bracket holds the scanning head.
 ext=by['peel_carriage_extension'];ext['dims']=[.42,.012,.30,[]];ext['pos']=[.07,.088,0]
 for z in [-.13,.13]:update('peel_tower_'+str(z),dims=[.030,.776,.030,.003],pos=(.215,.482,z))
 drop=m.beam('peel_scan_head_drop',[0,.082,0],[.120,.082,0],.026,'peel_scan_slide','peel_scan_carriage');m.set_support('peel_head_anchor',drop)
 # Tool rear tie clears both the carrier bridge and vertical columns in motion.
 update('peel_head_end_-0.7',pos=(-.735,.052,0));update('peel_head_end_0.1',pos=(.010,.052,0))
 for n in ['peel_head_cross','peel_head_cross_back']:by[n]['dims'][0]=.770;by[n]['pos'][0]=-.3625
 # Wash head stays below the main clamps; tray stays below its outriggers.
 w=by['wash_carriage_extension'];w['pos'][1]=.170
 for z in [-.095,.095]:
  spacer=m.box('wash_plate_spacer_'+str(z),(.10,.082,.030),(0,.123,z),'wash_axis_slide',support='wash_axis_carriage');m.contact(spacer,'wash_carriage_extension')
 m.set_support('wash_carriage_extension','wash_plate_spacer_-0.095')
 for z in [-.16,.16]:update('wash_tower_'+str(z),dims=[.025,.354,.025,.003],pos=(-.16,.353,z))
 for p in m.PART:
  if p['parent']=='wash_axis_slide':
   if p['name'].startswith(('wash_head_arm_','wash_pipe_cross_')):
    for v in p['dims'][:2]:v[1]=.522
   elif p['name'].startswith('wash_manifold_'):p['dims'][1][1]=.530
   elif p['name'].startswith('air_knife_inlet_'):p['dims'][0][1]=.500;p['dims'][1][1]=.530
   elif p['name'].startswith('air_knife_'):p['pos'][1]=.380
 # Control air ring is below the radial-motion envelope.
 for p in list(m.PART):
  if p['name'].startswith(('air_fixed_run_','air_ring_link_')):
   for v in p['dims'][:2]:v[1]=.210
  elif p['name'].startswith('air_clip_'):
   p['dims']=[.026,.030,.024,.001];p['pos'][1]=.210
   orig=p['support'];stem=m.beam(p['name']+'_hanger',[p['pos'][0],.430,-.22],[p['pos'][0],.210,-.20],.012,p['parent'],orig);m.set_support(p['name'],stem)
 # Swinging panels swept through the neighbouring stations. Replace them with
 # guided vertical gates, closed on the +/-30 degree sector boundaries.
 obsolete=set()
 for s in [-1,1]:
  for prefix in ['wash_hinge_','wash_spring_','flap_latch_sector_','flap_latch_pin_','flap_hinge_base_']:obsolete.add(prefix+str(s))
  name='wash_gate_fixed_'+str(s);ang=math.radians(30);loc=[.85*math.cos(ang),0,s*.85*math.sin(ang)]
  m.g(name,'station3',loc,yaw=-s*30,label='双导杆与同步带隔水升降门',station=3)
  gate_fixed=m.GROUP.pop();idx=next(i for i,g in enumerate(m.GROUP) if g['name']=='wash_flap_'+str(s));m.GROUP.insert(idx,gate_fixed)
  door=gb['wash_flap_'+str(s)];door.update(parent=name,pos=[0,0,0],yaw=0,label='隔水升降挡板 / 上升1000mm后允许分度')
  j=next(j for j in m.JOINTS if j['name']==door['name']);j.update(type='prismatic',parent=name,axis=[0,1,0],limits=[0,1.0],offset=[0,0,0],home=1.0);j.pop('spring_return',None)
  update('wash_panel_'+str(s),dims=[.30,.420,.004,.0005],pos=(-.15,.785,0))
  base=m.plate('wash_gate_base_'+str(s),(.14,.012,.16),(.035,.436,0),name,support=None)
  brace=m.beam('wash_gate_frame_brace_'+str(s),[.66,.415,s*.22],[loc[0],.415,loc[2]],.030,'station3','frame_2_'+str(s*.22));m.set_support(base,brace)
  column=m.tube('wash_gate_column_'+str(s),(.040,1.62,.080),(.065,1.246,0),name,support=base)
  m.plate('wash_gate_cap_'+str(s),(.10,.012,.12),(.045,2.062,0),name,support=column)
  moving=m.plate('wash_gate_carriage_'+str(s),(.050,.100,.100),(0,.940,0),door['name'],holes=[[-.005,z,.0131] for z in [-.030,.030]],support=None)
  for z in [-.030,.030]:
   guide=m.rod('wash_gate_guide_'+str(s)+'_'+str(z),[-.005,.55,z],[-.005,2.05,z],.008,name,support=column)
   m.ring('wash_gate_bush_'+str(s)+'_'+str(z),[-.005,.90,z],[-.005,.98,z],.013,.0081,door['name'],'aluminum',moving)
   m.contact(guide,'wash_gate_bush_'+str(s)+'_'+str(z))
  for z in [-.030,.030]:
   for y in [.54,2.05]:
    seat=m.beam('wash_gate_guide_seat_'+str(s)+'_'+str(z)+'_'+str(y),[.065,y,z],[-.005,y,z],.020,name,column)
   m.set_support('wash_gate_guide_'+str(s)+'_'+str(z),seat)
  m.set_support('wash_panel_'+str(s),moving);m.set_support(moving,'wash_gate_bush_'+str(s)+'_-0.03','linear_bearing')
  # Closed-loop belt, top idler, lower driven pulley and bored servo enclosure.
  for x in [.053,.097]:m.box('wash_gate_belt_'+str(s)+'_'+str(x),(.004,1.51,.012),(x,1.285,.075),name,'rubber',column)
  update('wash_gate_belt_'+str(s)+'_0.053','belt_loop_z',[.022,.004,1.51,.012],(.075,1.285,.075))
  obsolete.add('wash_gate_belt_'+str(s)+'_0.097')
  rot=m.g('wash_gate_drive_'+str(s),name,(.075,.53,.075),label='门同步带驱动 / R22名义节圆')
  m.joint('wash_gate_motor_'+str(s),'revolute',name,rot,[0,0,1],-1e9,1e9,relation='theta=(gate_q-1.0)/0.022')
  for y in [.53,2.04]:
   par=rot if y==.53 else name;off=np.array([.075,.53,.075]) if y==.53 else np.zeros(3)
   pulley=m.ring('wash_gate_pulley_'+str(s)+'_'+str(y),np.array([.075,y,.063])-off,np.array([.075,y,.087])-off,.022,.0061,par,'dark',column)
   bearing=m.p('wash_gate_bearing_'+str(s)+'_'+str(y),'bored_z',[.050,.060,.020,.0062,0],(.075,y,.050),name,'aluminum',column);m.set_support(pulley,bearing,'rolling')
   for x in [.053,.097]:m.contact(pulley,'wash_gate_belt_'+str(s)+'_'+str(x))
  shaft=m.rod('wash_gate_drive_shaft_'+str(s),[0,0,-.034],[0,0,.080],.006,rot,support='wash_gate_pulley_'+str(s)+'_0.53')
  body=m.p('wash_gate_motor_body_'+str(s),'bored_z',[.060,.070,.060,.0062,0],(.075,.53,.140),name,'dark','wash_gate_bearing_'+str(s)+'_0.53')
  m.beam('wash_gate_motor_stay_'+str(s),[.075,.565,.040],[.075,.565,.110],.012,name,column);m.set_support(body,'wash_gate_motor_stay_'+str(s))
  clamp=m.box('wash_gate_belt_clamp_'+str(s),(.030,.025,.035),(.040,.940,.075),door['name'],'steel',moving)
  bridge=m.beam('wash_gate_clamp_bridge_'+str(s),[.020,.94,.045],[.040,.94,.075],.016,door['name'],moving);m.set_support(clamp,bridge)
  m.contact(clamp,'wash_gate_belt_'+str(s)+'_0.053')
  m.set_support('wash_gate_belt_'+str(s)+'_0.053','wash_gate_pulley_'+str(s)+'_0.53','belt')
 m.PART[:]=[p for p in m.PART if p['name'] not in obsolete];m.MOUNTS[:]=[r for r in m.MOUNTS if r['part'] not in obsolete and r['support'] not in obsolete]
 m.CONTACTS[:]=[r for r in m.CONTACTS if r['a'] not in obsolete and r['b'] not in obsolete]
 gb['pack_oem']['pos'][2]=.90
 m.REFINEMENT07=dict(loader_pickup_q=.70,unloader_drop_q=.75,scan_down_positive=True,nominal_clearances_mm=dict(guide_rod_separation=22,half_ring_split=.5,wash_head_max_y=980),scope='Nominal design clearances. Swept rigid-body, hose and CAD checks are reported independently; no blanket collision-free claim.')
