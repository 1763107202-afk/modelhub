"""Review12: pre-wrap weighing, lower heat seam, top-loaded upright cassette.
Nominal dimensions are authored design values; no production release implied.
"""
import math,json
import numpy as np
import cadquery as cq

def install(m):
    k=m.k; by={p['name']:p for p in m.PART}; gb={g['name']:g for g in m.GROUP}; old=k.shape_for
    def shape(t,d):
        key=json.dumps([t,d])
        if key in k.CQ_CACHE:return k.CQ_CACHE[key]
        if t=='former12':
            sign=d[0]
            s=m.axis_cylinder([0,.200,0],[0,.550,0],.038).cut(m.axis_cylinder([0,.199,0],[0,.551,0],.034))
            s=s.intersect(cq.Workplane('XY').box(.120,.354,.080).val().translate((0,.375,sign*.0405)))
            for x in [-.037,.037]:s=s.fuse(cq.Workplane('XY').box(.012,.350,.018).val().translate((x,.375,sign*.010)))
        elif t=='twin_bored_x12':
            w,h,z,r,dy,dz=d;s=cq.Workplane('XY').box(w,h,z).val()
            for zz in [-dz,dz]:s=s.cut(m.axis_cylinder([-w/2-.001,dy,zz],[w/2+.001,dy,zz],r))
        elif t=='collect_cup12':
            ri,ro,h=d
            s=m.axis_cylinder([0,0,0],[0,h,0],ro).cut(m.axis_cylinder([0,.004,0],[0,h+.001,0],ri))
            for x,z in [(-.018,0),(.018,0),(0,.018),(0,-.018)]:s=s.cut(m.axis_cylinder([x,-.001,z],[x,.005,z],.002))
        else:return old(t,d)
        assert s.isValid(),t
        k.CQ_CACHE[key]=s;return s
    k.shape_for=shape
    # Exchange station 4/5 tooling so measurement precedes any film contact.
    gb['weigh_axis']['parent']='station5';gb['wrap_axis']['parent']='station4'
    gb['station4']['label']='双膜成袋预封';gb['station5']['label']='独立连袋检重';gb['station6']['label']='低位封底 / 冷却 / 升降收集'
    for p in m.PART:
        if p['parent']=='station5' and p['name'].startswith('wrap_'):p['parent']='station4'
        elif p['parent']=='station4' and p['name'].startswith('weigh_'):p['parent']='station5'
        if p['name'].startswith('wrap_former11_'):p['kind']='former12'
        if p['name'].startswith(('wrap_longitudinal_heater11_','wrap_cut_edge11_','wrap_cut_anvil11_')):p['dims'][1]=.350;p['pos'][1]=.375
        if p['name'].startswith(('film_roll11_','film_nip_roller11_')):p['dims'][0][1]=.200;p['dims'][1][1]=.550
        if p['name'].startswith('film_reel_shaft11_'):p['dims'][0][1]=.175;p['dims'][1][1]=.585
        if p['name'].startswith('film_nip_shaft11_'):p['dims'][0][1]=.175;p['dims'][1][1]=.585
        if p['name'].startswith(('seal_backbar11_','seal_heat_face11_','seal_cut_wire11_')):p['pos'][1]-=.040
        if p['name'].startswith('seal_head_reach11_'):
            for v in p['dims'][:2]:v[1]-=.040
        if p['name'].startswith('seal_head_post11_'):p['dims'][1][1]-=.040
    for j in m.JOINTS:
        if j['child']=='weigh_axis':j['parent']='station5'
        if j['child']=='wrap_axis':j['parent']='station4'
    # Lift is driven through a braked 1605 screw with two rails and four blocks.
    slide,bp=m.axis('unload_Z12','unload_axis_slide',(.110,.550,.800),.450,qhome=0,roll=90)
    lift=m.g('unload_lift12',slide,label='顶部装入收集孔的450mm升降移载')
    gb={g['name']:g for g in m.GROUP};gb[lift]['pos']=[.120,.230,0]
    # Rz90*[.120,.230]=[-.230,.120]; add axis origin [.110,-.120]
    # inverse placement chosen so the lifted grippers retain their old home pose.
    gb[lift]['roll']=-90
    # Current origin: axis (.110,-.120,-.600)+Rz90*((.120,0,0)+(.120,.230,0))
    # =(-.120,.120,-.600). Set compensating local position for zero world transform.
    gb[lift]['pos']=[-.670,.110,-.800];gb[lift]['roll']=-90
    # axis+Rz90*(slider_offset+[0,.110,.600]) = [0,0,0]
    moved=[]
    for g in m.GROUP:
        if g['parent']=='unload_axis_slide' and g['name'].startswith('unload_grip_'):g['parent']=lift
    for p in m.PART:
        n=p['name']
        if p['parent']=='unload_axis_slide' and n.startswith(('unload_mast_','unload_cross','unload_reach_','unload_grip_tab_','unload_open_')):
            p['parent']=lift;moved.append(n)
    # Connect the original gripper base to the new moving carriage, with clear offset.
    a=m.beam('unload_Z12_reachA',[0,.076,0],[-.170,.076,0],.025,slide,'unload_Z12_carriage')
    a=m.beam('unload_Z12_reachB',[-.170,.076,0],[-.170,.110,0],.025,slide,a)
    m.beam('unload_Z12_reachC',[-.170,.110,0],[-.170,.110,-.800],.025,slide,a)
    for z in [-.095,.095]:
        a=m.beam('unload_Z12_mount_'+str(z),[.11,.076,z],[.11,.55,z],.030,'unload_axis_slide','unload_axis_carriage')
        m.beam('unload_Z12_mount_reach_'+str(z),[.11,.55,z],[.11,.55,.80+z],.030,'unload_axis_slide',a)
    # Apply the bored motor and nut carrier interfaces used on the baseline axes.
    for prefix in ['infeed_X12','unload_Z12']:
        bp={p['name']:p for p in m.PART}
        bp[prefix+'_servo_200W'].update(kind='bored_x',dims=[.090,.060,.060,.0052,0])
        bp[prefix+'_CPDW32'].update(kind='step_coupling_x',dims=[])
        bp[prefix+'_nut_housing'].update(dims=[.040,.056,.055,.01404,-.005],pos=[0,.042,0])
        m.set_support(prefix+'_CPDW32',prefix+'_fixed_journal12');m.set_support(prefix+'_locknut',prefix+'_fixed_journal12')
    newparts={p['name']:p for p in m.PART}
    for prefix in ['infeed_X12','unload_Z12']:
        for p in m.PART:
            if p['name'].startswith(prefix+'_endstop_'):p['pos'][1]=.0245;p['pos'][2]=.142
    for sign in [-1,1]:
        tabs=[]
        for x in [.10,.90]:
            tab=m.box(f'infeed_shield_tab12_{sign}_{x}',(.050,.010,.050),(x,.012,sign*.140),'infeed_X12',support='infeed_X12_base');tabs.append(tab)
        m.set_support('infeed_X12_side_shield_'+str(sign*.15),tabs[0])
    # Preseal the bottom with the forming jaws, below the root cut plane.
    # Subsequent weighing measures the complete free package, not a hanging web.
    for lane,x in enumerate([-.510,-.370]):
        for sign in [-1,1]:
            m.box(f'wrap_bottom_preseal12_{lane}_{sign}',(.110,.008,.003),(x,.210,sign*.00155),'wrap_jaw11_'+str(sign),'orange',f'wrap_former11_{lane}_{sign}')
    # Captive collector with 24 separate lower cups and two fixed guide levels.
    remove={p['name'] for p in m.PART if p['name'].startswith('out_insert_')}
    m.PART[:]=[p for p in m.PART if p['name'] not in remove]
    m.MOUNTS[:]=[r for r in m.MOUNTS if r['part'] not in remove and r['support'] not in remove]
    for i in range(12):
        a=i*math.tau/12
        for lane,r in enumerate([.18,.32]):
            x,z=r*math.cos(a),r*math.sin(a);n=f'out_cup_{i}_{lane}';p=by[n]
            p.update(kind='collect_cup12',dims=[.033,.037,.045],pos=[x,.680,z],mat='pad')
            # Discrete feet support raised cup base; open area drains to lower disc.
            for dx in [-.026,.026]:m.rod(f'out_cup_leg12_{i}_{lane}_{dx}',[x+dx,.592,z],[x+dx,.680,z],.003,'outfeed_rotor',support='outfeed_disc')
            for h in [.760,.860]:
                collar=m.ring(f'out_guide12_{i}_{lane}_{h}',[x,h-.004,z],[x,h+.004,z],.040,.035,'outfeed_rotor','pad')
                # Posts lie to the side of the radial cup row, 45mm from its centre.
                xx,zz=x-.045*math.sin(a),z+.045*math.cos(a)
                stem=m.rod(f'out_guide_post12_{i}_{lane}_{h}',[xx,.592,zz],[xx,h,zz],.003,'outfeed_rotor',support='outfeed_disc')
                m.rod(f'out_guide_arm12_{i}_{lane}_{h}',[xx,h,zz],[x-.039*math.sin(a),h,z+.039*math.cos(a)],.003,'outfeed_rotor',support=stem)
                m.set_support(collar,f'out_guide_arm12_{i}_{lane}_{h}')
            m.set_support(n,f'out_cup_leg12_{i}_{lane}_-0.026')
    # Root-end seats support raw stems; the root fibres can surround the narrow peg.
    for i in range(12):
        a=i*math.tau/12
        for lane,r in enumerate([.18,.32]):
            x,z=r*math.cos(a),r*math.sin(a)
            cap=m.rod(f'feed_cup_cap12_{i}_{lane}',[x,.552,z],[x,.556,z],.023,'magazine',support=f'feed_cup_{i}_{lane}')
            m.rod(f'feed_end_seat12_{i}_{lane}',[x,.556,z],[x,.580,z],.006,'magazine','pad',cap)
    # A fixed optical bracket at the 180deg loading location is outside both lanes.
    m.box('collector_sensor12',(.025,.030,.018),(0,1.03,.450),'outfeed','black','outfeed_mount')
    m.set_support('collector_sensor12','collector_sensor_post12')
    m.beam('collector_sensor_post12',[0,.434,.450],[0,1.03,.450],.012,'outfeed','outfeed_mount')
    base=m.beam('collector_sensor_base12',[0,.434,.340],[0,.434,.450],.020,'outfeed','outfeed_mount');m.set_support('collector_sensor_post12',base)
    # The U-shaped seal at the former completes the bag. Remove the redundant
    # travelling sealer whose route would cross the raised collector supports.
    removed_groups={'seal_axis'}
    while True:
        more={g['name'] for g in m.GROUP if g['parent'] in removed_groups}
        if more<=removed_groups:break
        removed_groups|=more
    removed_parts={p['name'] for p in m.PART if p['parent'] in removed_groups or p['name'].startswith(('seal_base_cross11_','seal_axis_ground11_','seal_axis_leg11_','seal_front_leg_extension11','unload_Z12_side_shield_'))}
    m.PART[:]=[p for p in m.PART if p['name'] not in removed_parts]
    m.GROUP[:]=[g for g in m.GROUP if g['name'] not in removed_groups]
    m.JOINTS[:]=[j for j in m.JOINTS if j['child'] not in removed_groups]
    m.AXES[:]=[a for a in m.AXES if a['name']!='seal_axis']
    m.MOUNTS[:]=[r for r in m.MOUNTS if r['part'] not in removed_parts and r['support'] not in removed_parts]
    m.CONTACTS[:]=[r for r in m.CONTACTS if r['a'] not in removed_parts and r['b'] not in removed_parts]
    # Extend the existing air-knife slot envelope to the processed stem length.
    # This is an air blow-off operation, not dehydration of the vegetable.
    # Order groups topologically after moving children to a newly created parent.
    ordered=[];pending=list(m.GROUP);known=set()
    while pending:
        ready=[g for g in pending if not g['parent'] or g['parent'] in known]
        assert ready,'Cycle in assembly group tree'
        for g in ready:ordered.append(g);known.add(g['name']);pending.remove(g)
    m.GROUP[:]=ordered
    m.apply_home()
    # Refresh stored route snapshots after the station move; routes remain design candidates.
    from routing07 import route_points
    for r in m.SERVICES['routes']:
        try:
            ps=route_points(r,m.SERVICES['ports'],m.k.GM)
            r['points_world']=ps.tolist()
        except Exception:pass
    m.REVIEW12=dict(automatic_infeed='双通道输送带→夹持翻转90°→上料盘空位；上游需根向一致来料，随机散料理料待试验',packaging='顶部开口、双侧纵封、底部热封的透气套袋；不宣称全密封保鲜',
        weighing='预封成袋后独立检重，显示毛重；传感器只承担托杯和整袋，主夹与所有工具脱离，净重需扣除实测袋重',
        collector='24位独立托杯 / 760、860mm双层扶正圈；450mm升降从上方装入',
        drying='先关水滴沥，再用对向风刀去除表面游离水；时间、压力需样机试验',
        validation='保留修订11管路未关闭项；新增结构必须按实际运动重做检查，不作为制造放行')
