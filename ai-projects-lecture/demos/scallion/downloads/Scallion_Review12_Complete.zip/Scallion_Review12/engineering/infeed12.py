"""Two-lane metered belt and positive-grip 90-degree verticalizer.
The belt receives root-first, aligned stock from an upstream sorting interface.
"""
import math

def install(m):
    slide,bp=m.axis('infeed_X12','station1',(.720,.230,-.450),.950,qhome=.950)
    settle=m.g('infeed_settle12',slide,label='530 mm接杯升降')
    m.joint('infeed_settle12','prismatic',slide,settle,[0,1,0],0,.530,home=.530)
    flip=m.g('infeed_flip12',settle,(0,.270,0),label='同步夹持翻转 / 横料转为竖直料')
    m.joint('infeed_turn12','revolute',settle,flip,[1,0,0],-math.pi/2,0,home=0)
    # Pivot is 530 mm behind the raw root end; shaft never traverses the stem.
    shaft=m.rod('infeed_pivot12',[.075,0,0],[.445,0,0],.012,flip)
    for x in [.105,.445]:
        seat=m.ring('infeed_pivot_bearing12_'+str(x),[x-.012,.270,0],[x+.012,.270,0],.024,.0121,settle,'dark')
        mast=m.beam('infeed_pivot_mast12_'+str(x),[x,.076,0],[x,.246,0],.025,settle,'infeed_X12_carriage');m.set_support(seat,mast)
    m.p('infeed_turn_motor12','bored_x',[.090,.080,.080,.0061,0],(.005,.270,0),settle,'black','infeed_pivot_mast12_0.105')
    m.ring('infeed_turn_coupling12',[.050,0,0],[.065,0,0],.016,.0061,flip,'chrome',shaft)
    for lane,x in enumerate([.330,.190]):
        arm=m.beam('infeed_arm12_'+str(lane),[x,0,0],[x,0,.420],.016,flip,shaft)
        zc=.270 if lane==0 else .570
        reach=m.beam('infeed_pick_reach12_'+str(lane),[x,0,.420],[x,-.380,.420],.016,flip,arm)
        for sign in [-1,1]:
            jaw=m.g(f'infeed_jaw12_{lane}_{sign}',flip)
            m.joint(f'infeed_jaw12_{lane}_{sign}','prismatic',flip,jaw,[sign,0,0],0,.025,home=.025)
            back=m.box(f'infeed_jawback12_{lane}_{sign}',(.012,.050,.080),(x+sign*.026,-.395,zc),jaw,support=reach)
            pad=m.box(f'infeed_pad12_{lane}_{sign}',(.006,.030,.060),(x+sign*.017,-.450,.420),jaw,'pad',back)
            m.beam(f'infeed_jawlink12_{lane}_{sign}',[x+sign*.026,-.395,zc],[x+sign*.026,-.450,.420],.012,jaw,back)
            for zz in [zc-.030,zc+.030]:
                guide=m.rod(f'infeed_jawguide12_{lane}_{sign}_{zz}',[x+sign*.025,-.380,zz],[x+sign*.090,-.380,zz],.003,flip,support=reach)
                m.ring(f'infeed_jawbush12_{lane}_{sign}_{zz}',[x+sign*.024,-.380,zz],[x+sign*.050,-.380,zz],.006,.0031,jaw,'chrome',back)
            m.cylinder(f'infeed_grip_cyl12_{lane}_{sign}',flip,jaw,[x+sign*.135,-.380,zc],[x+sign*.080,-.380,zc],[x+sign*.026,-.380,zc],bore=.012,stroke=.025)
            bridge=m.beam(f'infeed_actuator_bridge12_{lane}_{sign}',[x,-.340,.420],[x,-.340,zc],.012,flip,reach)
            mount=m.beam(f'infeed_cyl_mount_arm12_{lane}_{sign}',[x,-.340,zc],[x+sign*.130,-.340,zc],.012,flip,bridge)
            plate=m.p(f'infeed_cyl_mount_plate12_{lane}_{sign}','bored_x',[.012,.080,.080,.0095,0],(x+sign*.130,-.380,zc),flip,'aluminum',mount)
            m.set_support(f'infeed_grip_cyl12_{lane}_{sign}_cap_0',plate)
            m.set_support(f'infeed_grip_cyl12_{lane}_{sign}_barrel',f'infeed_grip_cyl12_{lane}_{sign}_cap_0')
            m.set_support(f'infeed_grip_cyl12_{lane}_{sign}_rod',back,'bolted')
            m.set_support(pad,f'infeed_jawlink12_{lane}_{sign}')
            for zz in [zc-.030,zc+.030]:
                bracket=m.beam(f'infeed_guide_mount12_{lane}_{sign}_{zz}',[x+sign*.090,-.380,zz],[x+sign*.130,-.380,zz],.010,flip,plate)
                cap=m.rod(f'infeed_guide_cap12_{lane}_{sign}_{zz}',[x+sign*.088,-.380,zz],[x+sign*.092,-.380,zz],.007,flip,support=bracket)
                m.set_support(f'infeed_jawguide12_{lane}_{sign}_{zz}',cap)
                m.set_support(f'infeed_jawbush12_{lane}_{sign}_{zz}',f'infeed_jawguide12_{lane}_{sign}_{zz}','linear_bearing')
            m.set_support(back,f'infeed_jawbush12_{lane}_{sign}_{zc-.030}')
            bp=next(p for p in m.PART if p['name']==back);bp.update(kind='twin_bored_x12',dims=[.012,.050,.080,.00605,.015,.030])
        m.box('infeed_stop12_'+str(lane),(.045,.025,.008),(x,-.450,.070),flip,'pad',arm)
    # Live end of the settle slide, constrained by two guide rods.
    for x in [.10,.42]:
        m.rod('infeed_settle_guide12_'+str(x),[x,.088,-.100],[x,.960,-.100],.006,slide,support='infeed_X12_carriage')
        m.ring('infeed_settle_bush12_'+str(x),[x,.120,-.100],[x,.180,-.100],.011,.0061,settle,'dark','infeed_pivot_mast12_0.105')
    m.cylinder('infeed_settle_cyl12',slide,settle,[.26,-.100,-.250],[.26,.540,-.250],[.26,.570,-.250],bore=.025,stroke=.530)
    m.rod('infeed_motor_output12',[.045,0,0],[.075,0,0],.006,flip,support='infeed_turn_coupling12')
    m.ring('infeed_turn_coupling_shaft12',[.065,0,0],[.085,0,0],.016,.0121,flip,'chrome',shaft)
    fixed=m.box('infeed_settle_base12',(.600,.006,.220),(.240,.085,-.100),slide,support='infeed_X12_carriage')
    plate=m.box('infeed_settle_plate12',(.640,.018,.200),(.230,.120,-.100),settle)
    brace=m.beam('infeed_settle_rod_link12',[.26,.570,-.250],[.26,.120,-.250],.025,settle,'infeed_settle_cyl12_rod')
    link=m.beam('infeed_settle_plate_link12',[.26,.120,-.250],[.26,.120,-.100],.025,settle,brace);m.set_support(plate,link)
    for x in [.105,.445]:m.set_support('infeed_pivot_mast12_'+str(x),plate)
    for x in [.10,.42]:
        m.set_support('infeed_settle_guide12_'+str(x),fixed)
        m.set_support('infeed_settle_bush12_'+str(x),plate)
    mount=m.beam('infeed_motor_mount12',[-.045,.129,0],[-.045,.310,0],.012,settle,plate)
    m.set_support('infeed_turn_motor12',mount)
    for lane,x in enumerate([.330,.190]):
        stop=m.beam('infeed_root_stop_stay12_'+str(lane),[x,0,.070],[x,-.450,.070],.012,flip,'infeed_arm12_'+str(lane));m.set_support('infeed_stop12_'+str(lane),stop)
    m.set_support('infeed_turn_coupling12','infeed_motor_output12')
    cap=m.p('infeed_settle_rod_cap12','drilled',[.032,.006,.032,[[0,0,.0061]]],(.26,.570,-.250),settle,'aluminum','infeed_settle_cyl12_rod_nut');m.set_support('infeed_settle_rod_link12',cap)
    # Belt lane centres match the pickup pose: X=.720+.120+.950+[.330,.190].
    belt=m.g('belt_infeed12','station1',label='双通道正向输送 / 定距止挡 / 到料检测')
    for x in [1.98,2.12]:
        for z in [.15,2.65]:
            fp=m.foot(f'belt_foot12_{x}_{z}',x,z,'station1')
            m.beam(f'belt_leg12_{x}_{z}',[x,.097,z],[x,.550,z],.030,belt,fp)
        for dx in [-.060,.060]:m.beam(f'belt_frame12_{x}_{dx}',[x+dx,.550,-.40],[x+dx,.550,2.70],.020,belt,f'belt_leg12_{x}_0.15')
        m.box('belt_surface12_'+str(x),(.110,.008,2.95),(x,.564,1.075),belt,'rubber',f'belt_frame12_{x}_-0.06')
        for z in [.10,2.55]:m.rod(f'belt_roller12_{x}_{z}',[x-.068,.536,z],[x+.068,.536,z],.024,belt,support='belt_surface12_'+str(x))
        for i in range(6):m.box(f'belt_cleat12_{x}_{i}',(.108,.012,.012),(x,.574,.30+i*.38),belt,'blue','belt_surface12_'+str(x))
        m.box('belt_drive12_'+str(x),(.055,.070,.090),(x-.09,.545,2.55),belt,'black',f'belt_frame12_{x}_-0.06')
        m.box('belt_photoeye12_'+str(x),(.015,.020,.025),(x+.080,.625,.140),belt,'orange',f'belt_frame12_{x}_0.06')
        for z in [.15,2.65]:
            cross=m.beam(f'belt_cross12_{x}_{z}',[x-.070,.550,z],[x+.070,.550,z],.020,belt,f'belt_leg12_{x}_{z}')
            for dx in [-.060,.060]:m.set_support(f'belt_frame12_{x}_{dx}',cross)
        arm=m.beam('belt_eye_base12_'+str(x),[x+.060,.550,.140],[x+.080,.550,.140],.012,belt,f'belt_frame12_{x}_0.06')
        post=m.beam('belt_eye_post12_'+str(x),[x+.080,.550,.140],[x+.080,.625,.140],.012,belt,arm);m.set_support('belt_photoeye12_'+str(x),post)
    m.box('belt_camera12' ,(.080,.035,.060),(2.05,1.20,1.80),belt,'black','belt_frame12_1.98_-0.06')
    m.beam('belt_camera_mast12',[2.30,.550,1.80],[2.30,1.20,1.80],.020,belt,'belt_frame12_2.12_0.06')
    m.beam('belt_camera_arm12',[2.30,1.20,1.80],[2.05,1.20,1.80],.020,belt,'belt_camera_mast12')
    cbase=m.beam('belt_camera_base12',[2.180,.550,1.80],[2.300,.550,1.80],.020,belt,'belt_frame12_2.12_0.06')
    m.set_support('belt_camera_mast12',cbase);m.set_support('belt_camera12','belt_camera_arm12')
    m.REVIEW12=getattr(m,'REVIEW12',{})
    m.REVIEW12['automatic_infeed']='双通道输送→到料检测→夹持→90度翻转→上料盘空位交接；前级需根向一致，任意散乱来料理料成功率未验证'
