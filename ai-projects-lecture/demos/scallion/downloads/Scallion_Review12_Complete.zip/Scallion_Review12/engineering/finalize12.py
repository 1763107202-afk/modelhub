from pathlib import Path
import json,hashlib,gzip,zipfile,shutil
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads'
a=json.loads((O/'review12_checks.json').read_text());b=json.loads((O/'rigid_screen12.json').read_text());c=json.loads((O/'mount12.json').read_text());geom=json.loads((O/'geometry_verification.json').read_text())
a.update(cad_valid_solids=geom['cad_bodies'],rigid_screen_poses=b['poses_checked'],rigid_surface_candidates=len(b['candidates']),mounts_checked=c['checked'],rigid_mount_gap_candidates=len(c['gap_candidates']),full_machine_zero_interference_verified=False,mechanical_release=False)
a['geometry_note']=f"新增/变更刚体离散筛查仍有{len(b['candidates'])}组表面相交候选，安装连接仍有{len(c['gap_candidates'])}项距离候选，未作为制造放行。"
a['geometry_file_sha256']=hashlib.sha256((O/'SCALLION_CELL_concept_mm.step').read_bytes()).hexdigest();a['source_file_sha256']={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'engineering/infeed12.py',R/'engineering/refine12.py',R/'workflow.js',R/'motion.js',R/'process-scene.js']}
(O/'review12_checks.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
report=f'''# 修订12检查结论

工程状态：流程与动作可演示，机械装配仍待进一步校核。不能称为整机无干涉终版。

- 有效CAD实体：{geom['cad_bodies']}；无效形状：{len(geom['invalid_shapes'])}。
- 关节状态采样：{a['joint_samples']}；越限：{a['limit_failures']}；主盘位置联锁违规：{a['index_interlock_failures']}。
- 物料交接：{a['material_handoffs']}次；最大位置误差：{a['max_handoff_error_m']:.5g}m；最大姿态跳变：{a['max_handoff_angle_rad']:.5g}rad。
- 新增/变更刚体离散筛查：{b['poses_checked']}个姿态，保留{len(b['candidates'])}组表面相交候选，需要逐对精确CAD复核；这不是穿透深度或连续碰撞证明。
- 新增刚性安装连接距离检查：{c['checked']}项，保留{len(c['gap_candidates'])}项大于0.3mm的距离候选。未自动忽略或涂改失败结果。
- 原修订11的管间196组、管对机械件136组候选仍保留为历史未关闭事项；本轮未认证整机连续含管路避碰。
- 浏览器WebGL、真实SolidWorks、PLC、电气与食品接触验证未运行。

自动化边界：输送带需根向一致的来料；从输送带到立式料位不再依赖人工逐根插料。随机散料解缠、自动辨向剔除与全线实料成功率尚未验证。检重显示毛重示例，不含自动凑重包装。24位盘满后停止，取料与换盘未自动化。

包装边界：顶部开口的透气套袋，成袋站纵封、封底、保压冷却后独立检重，末站复检再移载。膜材与热封温压需要真实样品验证。

SW交付为保留层级的毫米制AP214实体装配，能够作为导入/建配合的基础；不是已经在SolidWorks中建立原生配合或运动研究的SLDASM。
'''
(O/'review12_conclusion.md').write_text(report,encoding='utf-8')
# Keep pending counts visible beside the presentation rather than hiding them in downloads.
p=D/'index.html';s=p.read_text();needle='<p id="validationSummary">'
a0=s.index(needle)+len(needle);a1=s.index('</p>',a0)
s=s[:a0]+f"动作与交接检查通过；新增/变更刚体仍有{len(b['candidates'])}组表面相交候选，安装连接有{len(c['gap_candidates'])}项距离候选。当前为待校核预览，未达到整机无干涉验收。"+s[a1:]
p.write_text(s)
print(json.dumps({k:a[k] for k in ['cad_valid_solids','rigid_screen_poses','rigid_surface_candidates','rigid_mount_gap_candidates']},ensure_ascii=False))
