"""Outer-radius capsule screen of every routed chord against actual CAD meshes.

Unchanged route/body relative poses reuse exact prior results. End attachment
bodies are excluded; every other contact remains a candidate for review.
"""
import json,sys,time,os
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from collision_engine import Engine,world,fcl,tkey,SHAPE_HASH
import machine as m
from routing07 import route_points

src=Path(sys.argv[1]);raw=json.loads(src.read_text());poses=raw['poses'][::int(os.environ.get('STRIDE','1'))]
if os.environ.get('LIMIT'):poses=poses[:int(os.environ['LIMIT'])]
e=Engine();ports=m.SERVICES['ports'];routes=m.SERVICES['routes'];names=list(e.objs);hits={};calls=0;t0=time.time();seen={}
req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True)
for pi,state in enumerate(poses):
 e.pose(state['q']);W=world(state['q']);lo=[];hi=[]
 for n in names:
  a,b=e.bounds[n];M=e.transforms[n];c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2);lo.append(c-r);hi.append(c+r)
 lo=np.array(lo);hi=np.array(hi)
 for rt in routes:
  ps=route_points(rt,ports,W);ro=rt['outer_radius'];ignored={ports[n]['body'] for n in [rt['start'],rt['end']]}|{'fit_'+rt['start'],'fit_'+rt['end']}
  routekey=tuple(ps.reshape(-1).round(8));low=ps.min(0)-ro;high=ps.max(0)+ro
  candidates=np.flatnonzero(np.all(low<=hi,axis=1)&np.all(high>=lo,axis=1));todo=[]
  for j in candidates:
   n=names[j];key=rt['name']+'|'+n
   if n in ignored or key in hits:continue
   sig=(routekey,tkey(e.transforms[n]))
   if seen.get(key)==sig:continue
   seen[key]=sig;todo.append(j)
  if not todo:continue
  jj=np.array(todo)
  for si,(a,b) in enumerate(zip(ps,ps[1:])):
   d=b-a;L=float(np.linalg.norm(d))
   if L<1e-8:continue
   low=np.minimum(a,b)-ro;high=np.maximum(a,b)+ro;js=jj[np.all(low<=hi[jj],axis=1)&np.all(high>=lo[jj],axis=1)]
   if not len(js):continue
   u=d/L;v=np.cross([0,0,1],u);c=np.clip(u[2],-1,1)
   R=np.eye(3) if c>.999999 else Rotation.from_rotvec(v/np.linalg.norm(v)*np.arccos(c)).as_matrix() if c>-.999999 else np.diag([1,-1,-1])
   cap=fcl.CollisionObject(fcl.Capsule(ro,L),fcl.Transform(R,(a+b)/2))
   for j in js:
    n=names[j];key=rt['name']+'|'+n
    if key in hits:continue
    res=fcl.CollisionResult();fcl.collide(cap,e.objs[n],req,res);calls+=1
    if res.is_collision:hits[key]=dict(route=rt['name'],solid=n,phase=state['phase'],t=state['t'],segment=si,q=state['q'])
 if pi%20==0:
  print('pose',pi,'route/rigid candidates',len(hits),'calls',calls,flush=True)
  src.with_name(src.stem+'-flex-partial.json').write_text(json.dumps(dict(poses_checked=pi+1,contacts=list(hits.values()))))
out=dict(poses=len(poses),routes=len(routes),rigid_bodies=len(names),capsule_contacts=list(hits.values()),narrow_phase_calls=calls,elapsed_s=time.time()-t0,geometry_code_sha256=SHAPE_HASH,scope='Discrete outer-radius capsules against rigid meshes. End attachments excluded. Surface candidates require exact solid review; no continuous collision or fatigue certification.')
dest=Path(os.environ.get('OUTPUT',str(src.with_name(src.stem+'-flex.json'))));dest.write_text(json.dumps(out,ensure_ascii=False,indent=2));print('DONE',len(hits),dest,flush=True)
