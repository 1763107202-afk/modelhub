"""Recheck all new/changed parts and parts under moved groups against revision09."""
import json, os, runpy, subprocess
from pathlib import Path
R = Path(__file__).resolve().parents[1]
os.chdir(R)
old = json.loads(subprocess.check_output(['git', 'show', '03b46ff65575a9678d7f286f201986943aeacf17:engineering/scene_manifest.json'], cwd=R))
new = json.loads((R/'engineering/scene_manifest.json').read_text())
old_parts = {p['name']: p for p in old['parts']}
old_groups = {g['name']: g for g in old['groups']}
groups = {g['name']: g for g in new['groups']}
def moved(parent):
    while parent:
        g = groups[parent]
        if g != old_groups.get(parent): return True
        parent = g.get('parent')
    return False
selected = [p['name'] for p in new['parts'] if p != old_parts.get(p['name']) or moved(p['parent'])]
selected += sorted(set(old_parts) - {p['name'] for p in new['parts']})
print('New, changed or moved parts:', len(selected), flush=True)
os.environ['PARTS'] = ','.join(selected)
runpy.run_path(str(R/'engineering/check_mounts.py'), run_name='__main__')
