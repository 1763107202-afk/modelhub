import sys,json,numpy as np,cadquery as cq
from OCP.gp import gp_Trsf
sys.path.insert(0,'/workspace/sites/scallion-mechanical-lab/engineering')
import machine as m
from collision_engine import world
root='/workspace/sites/scallion-mechanical-lab/'
checks=json.load(open(root+'engineering/published08_full_cycle_screen.json'));raw=json.load(open('/workspace/scratch/23396c524f3a/full-clearance-published08-paths.json'));report=json.load(open(root+'engineering/review-cases.json'));by={p['name']:p for p in m.PART}
def move(s,M):
 tr=gp_Trsf();tr.SetValues(*[float(v) for v in M[:3,:].reshape(-1)]);return s.moved(cq.Location(tr))
def cad(n,W):
 p=by[n];return move(m.k.shape_for(p['kind'],p['dims']),W[p['parent']]@m.k.mat4(p))
confirmed=[]
for case in report['cases']:
 if case['id'] not in ['C07','C09']:continue
 ref=case['parts'][0];h=next(h for h in checks['extra_candidates'] if h['extra_path']==ref['path'] and h['solid']==case['parts'][1]['name'])
 pose=min(raw['poses'],key=lambda p:abs(p['t']-case['t']));extra=next(e for e in pose['extras'] if e['path']==ref['path']);g=raw['geometries'][extra['geometry']];v=np.array(g['v']).reshape(-1,3);lo=v.min(0);hi=v.max(0)
 assert len(g['t'])==36,'expected a box';box=cq.Workplane('XY').box(*(hi-lo)).val().translate(tuple((lo+hi)/2));W=world(h['q']);A=move(box,np.array(extra['M']).reshape(4,4).T);B=cad(h['solid'],W);volume=A.intersect(B).Volume()*1e9
 assert volume>.1
 case['evidence']='实体相交复核：约'+str(round(volume))+' mm³';case['overlap_mm3']=volume
 confirmed.append(dict(case=case['id'],overlap_mm3=volume,method='Web BoxGeometry rebuilt as an exact box; nominal CAD BREP common at the displayed pose. No continuous clearance claim.'))
 print(case['id'],round(volume,3),'mm3',flush=True)
json.dump(confirmed,open(root+'engineering/review09_exact_selected.json','w'),ensure_ascii=False,indent=2)
for path in ['engineering/review-cases.json','dist/downloads/assembly_review_09.json']:json.dump(report,open(root+path,'w'),ensure_ascii=False,indent=2)
