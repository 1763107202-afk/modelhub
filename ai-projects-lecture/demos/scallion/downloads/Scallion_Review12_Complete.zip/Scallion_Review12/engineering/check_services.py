"""Check graph connectivity, real endpoint geometry and full-stroke hose length reserve."""
import json,itertools,copy
from pathlib import Path
import numpy as np
import machine as m
from routing07 import route_points
k=m.k;svc=m.SERVICES;ports=svc['ports'];routes=svc['routes']
root=Path(__file__).resolve().parents[1];by={p['name']:p for p in m.PART};graph={n:set() for n in ports}
for rt in routes:graph[rt['start']].add(rt['end']);graph[rt['end']].add(rt['start'])
for ns in svc['internal_connections']:
 for a,b in itertools.combinations(ns,2):graph[a].add(b);graph[b].add(a)
def reach(start):
 seen={start};todo=[start]
 while todo:
  for b in graph[todo.pop()]-seen:seen.add(b);todo.append(b)
 return seen
air=reach('AIR_IN');water=reach('W_SITE_IN');drain=reach('D_TRAY')
unfed=[n for n,p in ports.items() if (p['medium']=='air' and n not in air) or (p['medium']=='water' and n not in water) or (p['medium']=='drain' and n not in drain)]
assert not unfed,unfed
assert not (water&drain),'Waste water cross-connection'
path_endpoint_errors=[]
for rt in routes:
 pts=route_points(rt,ports,k.GM)
 for ix,n in [(0,rt['start']),(-1,rt['end'])]:
  p=ports[n];target=(k.GM[p['parent']]@np.r_[p['point'],1])[:3]
  err=float(np.linalg.norm(pts[ix]-target));path_endpoint_errors.append(dict(route=rt['name'],port=n,error_m=err))
assert max(x['error_m'] for x in path_endpoint_errors)<1e-8,sorted(path_endpoint_errors,key=lambda x:-x['error_m'])[:5]
# Cylinder endpoints must coincide with the explicit CAD fitting tips, not a virtual floating coordinate.
port_errors=[]
for c in m.CYL:
 for j in [0,1]:
  p=by[c['name']+'_port_'+str(j)];cfg=ports[c['name']+'_C'+str(j)]
  err=float(np.linalg.norm(np.asarray(cfg['point'])-p['dims'][1]));port_errors.append(err)
  assert cfg['parent']==p['parent'] and err<1e-10
original=copy.deepcopy(m.GROUP);gby={g['name']:g for g in m.GROUP}
def world(q):return (k.GM[q['parent']]@np.r_[q['point'],1])[:3]
bad=[];records=[]
for rt in routes:
 deps=set()
 for endpoint in [ports[rt['start']]['parent'],ports[rt['end']]['parent']]:
  p=endpoint
  while p:deps.add(p);p=gby[p]['parent']
 js=[j for j in m.JOINTS if j['child'] in deps and j['type']=='prismatic']
 # Independent motion extremes, plus intermediate poses on each axis.
 configs=list(itertools.product(*[j['limits'] for j in js])) if js else [()]
 for j in js:
  for q in np.linspace(*j['limits'],9):configs.append(tuple(q if j2 is j else j2.get('home',0) for j2 in js))
 max_d=0;max_len_error=0;min_R=1e6
 for cfg in configs:
  for j,q in zip(js,cfg):gby[j['child']]['pos']=(np.array(j.get('offset',[0,0,0]))+np.array(j['axis'])*q).tolist()
  k.GM.clear()
  for g in m.GROUP:k.GM[g['name']]=(k.GM[g['parent']] if g['parent'] else np.eye(4))@k.mat4(g)
  a,b=world(ports[rt['start']]),world(ports[rt['end']]);d=float(np.linalg.norm(b-a));max_d=max(max_d,d)
  if d>rt['length_m']+1e-7:bad.append(dict(route=rt['name'],distance_m=d,length_m=rt['length_m']))
  if rt.get('straight'):continue
  pts=route_points(rt,ports,k.GM)
  max_len_error=max(max_len_error,abs(float(np.linalg.norm(np.diff(pts,axis=0),axis=1).sum())-rt['length_m']))
  # Circumcircle estimate at every sampled bend.
  if len(pts)<3:continue
  u=pts[1:-1]-pts[:-2];v=pts[2:]-pts[1:-1];w=pts[2:]-pts[:-2]
  den=2*np.linalg.norm(np.cross(u,v),axis=1);rad=np.linalg.norm(u,axis=1)*np.linalg.norm(v,axis=1)*np.linalg.norm(w,axis=1)/np.maximum(den,1e-14)
  min_R=min(min_R,float(rad.min()))
 records.append(dict(route=rt['name'],poses_checked=len(configs),length_m=rt['length_m'],max_endpoint_distance_m=max_d,minimum_sampled_bend_radius_mm=round(min_R*1000,2),max_length_residual_m=max_len_error))
 for g,orig in zip(m.GROUP,original):g['pos']=orig['pos'].copy()
assert not bad,bad
out=dict(routes=len(routes),ports=len(ports),cylinder_ports_connected=len(port_errors),unreachable_ports=unfed,air_water_waste_separated=True,taut_hoses=bad,max_cylinder_endpoint_error_m=max(port_errors),max_length_residual_m=max(r['max_length_residual_m'] for r in records),pose_samples=sum(r['poses_checked'] for r in records),checks=records,scope='Graph and independent prismatic limits. Bend-radius measurements are reported, not supplier-approved. Does not verify pipe self-collision, strain relief, pressure loss, flow rates or hygienic qualification.')
(root/'dist/downloads/service_checks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
