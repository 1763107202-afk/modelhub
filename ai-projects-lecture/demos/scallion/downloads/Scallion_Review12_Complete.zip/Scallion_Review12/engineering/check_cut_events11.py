"""Verify severing markers against actual material mesh cross-sections."""
from pathlib import Path
import json,numpy as np
from collision_engine import world
import machine as m
R=Path(__file__).resolve().parents[1]
raw=json.loads((R/'repair11-final.json').read_text());events=json.loads((R/'engineering/evidence11/cut_event_inputs.json').read_text())
parts={p['name']:p for p in m.PART};results=[]
for event in events:
    prior=max((p for p in raw['poses'] if p['t']<event['t']-1e-8),key=lambda p:p['t'])
    W=world(event['q'])
    for lane,blade in enumerate(event['blades']):
        p=parts[blade];inv=np.linalg.inv(W[p['parent']]@m.k.mat4(p));w,h,z=p['dims'];ys=-h/2+.0001;cross=[]
        for x in prior['extras']:
            if not x['name'].startswith(f'product_0_{lane}_'):continue
            if event['kind']=='root' and not (x['name'].endswith('_stem') or x['name'].endswith('_skin_shell')):continue
            if event['kind']=='leaf' and '_leaf_' not in x['name']:continue
            g=raw['geometries'][x['geometry']];v=np.array(g['v']).reshape(-1,3);M=inv@np.array(x['M']).reshape(4,4).T;v=v@M[:3,:3].T+M[:3,3]
            ix=np.array(g['t']).reshape(-1,3)
            for ia,ib in [(0,1),(1,2),(2,0)]:
                a,b=v[ix[:,ia]],v[ix[:,ib]];d=b[:,1]-a[:,1];f=np.divide(ys-a[:,1],d,out=np.full_like(d,np.nan),where=np.abs(d)>1e-12);keep=(f>=0)&(f<=1)
                cross.extend((a[keep]+f[keep,None]*(b[keep]-a[keep])).tolist())
        assert cross,(event['kind'],lane)
        cross=np.array(cross);clearance=z/2-float(cross[:,2].max());lateral=w/2-float(np.abs(cross[:,0]).max())
        assert clearance>.001 and lateral>.001,(blade,clearance,lateral)
        results.append(dict(blade=blade,cut_marker_s=event['t'],kind=event['kind'],continuous_straight_edge=True,edge_past_last_cross_section_mm=clearance*1000,lateral_coverage_margin_mm=lateral*1000))
out=dict(checks=results,scope='Actual nominal material mesh section at the blade plane, just before severing, transformed into the blade frame at the marker. Confirms display event occurs after a continuous edge crosses that section. No cutting-force, fibre deformation or real-food process certification.')
(R/'dist/downloads/cut_event_checks_11.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
