"""Lossless hosting transport and review artifacts for mechanical revision10."""
from pathlib import Path
import gzip, hashlib, json, shutil, zipfile
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads'
raw=(D/'cell.glb').read_bytes() if (D/'cell.glb').exists() else gzip.decompress((D/'cell.glb.gz').read_bytes())
compressed=gzip.compress(raw,compresslevel=9,mtime=0)
assert gzip.decompress(compressed)==raw
(D/'cell.glb.gz').write_bytes(compressed)
with zipfile.ZipFile(O/'Scallion_GLB_10.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('SCALLION_CELL_10.glb',raw)
for p in (R/'renders').glob('*.jpg'):shutil.copy2(p,D/'images'/p.name)
review=json.loads((O/'assembly_review_10.json').read_text())
data=json.loads((D/'mechanics.json').read_text())
data['view_counts']={p.stem:json.loads(p.read_text())['visible_meshes'] for p in (R/'renders').glob('*.json')}
(D/'mechanics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
readme='''青葱工坊 · 结构修订10

演示：打开已发布站点，点击“完整作业”，使用工序跳转、跟随当前作业或跟随A组物料。
本包是结构修订与复核资料，不是通过整机工业验收的制造文件。
7项原阻挡通过限定范围密集回归；包装、封口和剪叶进给仍有4项未关闭。
SW交换包内含AP214毫米制STEP、产品树、运动副/端口表和导入说明；原生SW配合未建立和实机验收。
GLB压缩包包含展示模型的原始完整字节。网页仅对传输作无损gzip压缩。
检查边界与残余问题详见 assembly_review_10.json 和 assembly-review-10.html。
'''
with zipfile.ZipFile(O/'Scallion_Mechanical_10.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('README_中文.txt',readme)
    for n in ['Scallion_SW_Assembly_10.zip','Scallion_GLB_10.zip','assembly_review_10.json','full_workflow_clearance_screen_10.json','exchange_clearance_checks_10.json','full_workflow_checks_10.json','full_workflow_timeline_10.json','review_interaction_checks_10.json','hosted_interaction_checks_10.json','geometry_verification.json','delivery_checks.json','mount_checks.json','service_checks.json','kinematic_geometry_checks.json']:
        p=O/n
        if p.exists():z.write(p,'review/'+n)
    z.write(D/'assembly-review-10.html','assembly-review-10.html')
    z.write(D/'mechanics.json','mechanics.json')
    for p in (R/'engineering/evidence10').glob('*'):z.write(p,'source/engineering/evidence10/'+p.name)
    for p in (R/'engineering').glob('*.py'):z.write(p,'source/engineering/'+p.name)
    for n in ['workflow.js','motion.js','process-scene.js','services.js','follow-camera.js','viewer.js','collision-review.js','model-loader.js','check-workflow.mjs','export-full-poses.mjs']:
        z.write(R/n,'source/'+n)
report=dict(model_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),lossless_gzip_bytes=len(compressed),lossless_roundtrip=True,resolved_case_count=len(review['resolved_ids']),unresolved_case_count=len(review['unresolved_ids']),production_release=False)
(O/'release10_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
# Keep the unchanged original bytes in the downloadable ZIP; each hosted asset
# must remain below the 25MiB single-asset cap. The viewer decodes cell.glb.gz.
(D/'cell.glb').unlink(missing_ok=True)
(O/'SCALLION_CELL.glb').unlink(missing_ok=True)
assert all(p.stat().st_size < 25*1024**2 for p in D.rglob('*') if p.is_file())
