"""Analytical closest distance between hose chords, including outer radii."""
import json,sys,os,itertools,time
from pathlib import Path
import numpy as np
import machine as m
from collision_engine import world
from routing07 import route_points

def distances(a,b):
 a0=a[:-1,None,:];b0=b[None,:-1,:];u=np.diff(a,axis=0)[:,None,:];v=np.diff(b,axis=0)[None,:,:];w=a0-b0
 aa=(u*u).sum(-1);bb=(u*v).sum(-1);cc=(v*v).sum(-1);dd=(u*w).sum(-1);ee=(v*w).sum(-1);det=aa*cc-bb*bb
 ss=np.divide(bb*ee-cc*dd,det,out=np.zeros_like(det),where=det>1e-18);tt=np.divide(aa*ee-bb*dd,det,out=np.zeros_like(det),where=det>1e-18)
 A=a0+ss[...,None]*u;B=b0+tt[...,None]*v;d=((A-B)**2).sum(-1);d[(ss<0)|(ss>1)|(tt<0)|(tt>1)|(det<=1e-18)]=np.inf
 best=(A+B)/2
 for ss,tt in [(0,np.clip(ee/np.maximum(cc,1e-20),0,1)),(1,np.clip((ee+bb)/np.maximum(cc,1e-20),0,1)),(np.clip(-dd/np.maximum(aa,1e-20),0,1),0),(np.clip((bb-dd)/np.maximum(aa,1e-20),0,1),1)]:
  A=a0+np.asarray(ss)[...,None]*u;B=b0+np.asarray(tt)[...,None]*v;dist=((A-B)**2).sum(-1);mask=dist<d;best=np.where(mask[...,None],(A+B)/2,best);d=np.minimum(d,dist)
 return np.sqrt(d),best

if __name__=='__main__':
 src=Path(sys.argv[1]);states=json.loads(src.read_text())['poses'][::int(os.environ.get('STRIDE','1'))]
 if os.environ.get('LIMIT'):states=states[:int(os.environ['LIMIT'])]
 routes=m.SERVICES['routes'];ports=m.SERVICES['ports'];hits={};t0=time.time()
 for state in states:
  W=world(state['q']);ps=[route_points(r,ports,W) for r in routes];bounds=[(a.min(0)-r['outer_radius'],a.max(0)+r['outer_radius']) for a,r in zip(ps,routes)]
  for i,j in itertools.combinations(range(len(routes)),2):
   r,s=routes[i],routes[j];key=r['name']+'|'+s['name']
   if key in hits:continue
   lo,hi=bounds[i];lj,hj=bounds[j]
   if np.any(lo>hj) or np.any(hi<lj):continue
   d,p=distances(ps[i],ps[j]);shared={r['start'],r['end']}&{s['start'],s['end']}
   for n in shared:
    q=ports[n];c=(W[q['parent']]@np.r_[q['point'],1])[:3];d[np.linalg.norm(p-c,axis=-1)<.030]=np.inf
   index=np.unravel_index(np.argmin(d),d.shape);minimum=float(d[index]);outer=r['outer_radius']+s['outer_radius']
   if minimum<outer-.00010:hits[key]=dict(a=r['name'],b=s['name'],distance_mm=minimum*1000,required_mm=outer*1000,location_m=p[index].tolist(),t=state['t'],phase=state['phase'],q=state['q'])
 out=dict(poses=len(states),routes=len(routes),hose_pair_candidates=list(hits.values()),elapsed_s=time.time()-t0,scope='Discrete chord distance including both outer radii; only actual shared-port junctions within30mm are excluded. Not continuous motion, flexible-body mechanics or production qualification.')
 dest=Path(os.environ.get('OUTPUT','dist/downloads/hose_pair_checks_11.json'));dest.write_text(json.dumps(out,ensure_ascii=False,indent=2));print('pipe pair candidates',len(hits),'poses',len(states),'seconds',round(out['elapsed_s'],1),flush=True)
