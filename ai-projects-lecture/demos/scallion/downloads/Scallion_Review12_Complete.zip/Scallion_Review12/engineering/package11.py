"""Package exact reviewed bytes; the review remains explicitly unqualified."""
from pathlib import Path
import gzip,hashlib,json,shutil,zipfile
R=Path(__file__).resolve().parents[1];D=R/'dist';O=D/'downloads'
raw=(D/'cell.glb').read_bytes() if (D/'cell.glb').exists() else gzip.decompress((D/'cell.glb.gz').read_bytes());delivery=json.loads((O/'delivery_checks.json').read_text())
assert hashlib.sha256(raw).hexdigest()==delivery['glb_sha256']
transport=gzip.compress(raw,compresslevel=9,mtime=0);assert gzip.decompress(transport)==raw
(D/'cell.glb.gz').write_bytes(transport)
temporary=O/'Scallion_GLB_11.building.zip'
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.writestr('SCALLION_CELL_11.glb',raw)
with zipfile.ZipFile(temporary) as z:assert z.testzip() is None
temporary.replace(O/'Scallion_GLB_11.zip')
with zipfile.ZipFile(O/'Scallion_SW_Assembly_11.zip') as z:
    p=next(n for n in z.namelist() if n.endswith('.step'))
    assert hashlib.sha256(z.read(p)).hexdigest()==delivery['step_sha256']
for p in (R/'renders').glob('*.jpg'):shutil.copy2(p,D/'images'/p.name)
data=json.loads((D/'mechanics.json').read_text())
data['view_counts']={p.stem:json.loads(p.read_text())['visible_meshes'] for p in (R/'renders').glob('*.json')}
(D/'mechanics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
poses=(R/'repair11-final.json').read_bytes();(R/'engineering/evidence11/full_workflow_poses.json.gz').write_bytes(gzip.compress(poses,compresslevel=9,mtime=0))
review=json.loads((O/'assembly_review_11.json').read_text())
report=dict(raw_glb_sha256=hashlib.sha256(raw).hexdigest(),step_sha256=delivery['step_sha256'],pose_sha256=hashlib.sha256(poses).hexdigest(),
 raw_bytes=len(raw),lossless_gzip_bytes=len(transport),lossless_roundtrip=True,SW_ZIP_STEP_matches_validated_bytes=True,
 rigid_candidate_count=review['rigid_candidate_count'],hose_pair_candidate_count=review['hose_pair_candidate_count'],
 hose_rigid_candidate_count=review['hose_rigid_candidate_count'],production_release=False)
(O/'release11_checks.json').write_text(json.dumps(report,indent=2))
readme='''青葱工坊 · 结构修订11

完整作业保留：进料、切根、交接、剪叶、去皮、洗/干、成袋、称重、横封、成品输出、空夹回位。
支持当前工序跟随、A组物料跟随、自由观察与各工序跳转。
本版为参数化重建设计；外围护架直径约7.34m，未保持原始紧凑布局。
管间、管对机械件仍有候选，尚未达到整机无干涉或工业制造验收。

SW交换包保留AP214毫米制STEP产品树，并附运动副、介质端口、名义管长和导入说明。
它不含原生SolidWorks配合、建模历史或经SW运动研究验收的SLDASM。
GLB包是被检查的完整展示模型，网页gzip只改变无损传输。

检查方法、排除边界、原始候选和未关闭项目见assembly-review-11.html及review/内JSON。
source/包含模型、动作与检查脚本。evidence11/full_workflow_poses.json.gz保存本轮完整离散姿态。
复现需要CadQuery/OpenCascade、python-fcl、NumPy/SciPy以及Three.js。
机械几何先由machine.py生成，再依次refine_hose_meshes.py、compact_glb.py。
动作/姿态由check-workflow11.mjs和export-full-poses.mjs使用共享GLB生成。
不能以本包作为生产下料、采购冻结、热封工艺或食品接触批准。
'''
temporary=O/'Scallion_Mechanical_11.building.zip'
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('README_中文.txt',readme)
    for n in ['Scallion_SW_Assembly_11.zip','Scallion_GLB_11.zip','assembly_review_11.json','full_workflow_clearance_screen_11.json',
       'full_workflow_checks_11.json','full_workflow_timeline_11.json','hose_pair_checks_11.json','hose_rigid_checks_11.json',
       'review_interaction_checks_11.json','hosted_interaction_checks_11.json','geometry_verification.json','delivery_checks.json',
       'mount_checks.json','service_checks.json','kinematic_geometry_checks.json','drive_calculations.json','cut_event_checks_11.json','release11_checks.json']:
        p=O/n
        assert p.exists(),n
        z.write(p,'review/'+n)
    page=(D/'assembly-review-11.html').read_text().replace('<meta charset="utf-8">','<meta charset="utf-8"><base href="https://scallion-mechanical-lab.supergenet16.chatgpt.site/">',1)
    z.writestr('assembly-review-11.html',page);z.write(D/'mechanics.json','mechanics.json')
    for p in (R/'engineering/evidence11').glob('*'):
        if p.suffix!='.glb':z.write(p,'source/engineering/evidence11/'+p.name)
    for p in (R/'engineering').glob('*.py'):z.write(p,'source/engineering/'+p.name)
    for n in ['workflow.js','motion.js','process-scene.js','services.js','follow-camera.js','viewer.js','collision-review.js','model-loader.js','check-workflow11.mjs','export-full-poses.mjs','build11.mjs','style.css','package.json']:
        z.write(R/n,'source/'+n)
with zipfile.ZipFile(temporary) as z:assert z.testzip() is None
temporary.replace(O/'Scallion_Mechanical_11.zip')
(D/'cell.glb').unlink(missing_ok=True);(O/'SCALLION_CELL.glb').unlink(missing_ok=True);(O/'SCALLION_CELL_concept_mm.step').unlink(missing_ok=True)
assert all(p.stat().st_size<25*1024**2 for p in D.rglob('*') if p.is_file()),[(str(p),p.stat().st_size) for p in D.rglob('*') if p.is_file() and p.stat().st_size>=25*1024**2]
print(json.dumps(report,indent=2))
