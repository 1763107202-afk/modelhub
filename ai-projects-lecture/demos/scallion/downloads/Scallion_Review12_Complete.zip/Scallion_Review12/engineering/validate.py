import json,struct,hashlib,gzip
from pathlib import Path
import numpy as np
import cadquery as cq
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'dist';P=D/'downloads'
raw=(D/'cell.glb').read_bytes() if (D/'cell.glb').exists() else gzip.decompress((D/'cell.glb.gz').read_bytes());magic,v,L=struct.unpack_from('<III',raw,0);assert magic==0x46546c67 and v==2 and L==len(raw)
n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);buf=raw[28+n:]
sizes={5126:4,5125:4,5123:2,5120:1,5121:1};types={5126:'<f4',5125:'<u4',5123:'<u2',5120:'i1',5121:'u1'};dim={'VEC3':3,'VEC4':4,'SCALAR':1,'VEC2':2}
def acc(i):
 a=g['accessors'][i];b=g['bufferViews'][a['bufferView']];off=b.get('byteOffset',0)+a.get('byteOffset',0);count=a['count']*dim[a['type']];assert off+count*sizes[a['componentType']]<=len(buf);ar=np.frombuffer(buf,dtype=types[a['componentType']],count=count,offset=off);assert np.isfinite(ar).all();return ar
for mesh in g['meshes']:
 for p in mesh['primitives']:
  q=acc(p['attributes']['POSITION']);ix=acc(p['indices']);assert ix.max()<len(q)/3;acc(p['attributes']['NORMAL'])
scene=json.loads((ROOT/'engineering/scene_manifest.json').read_text());node={x['name']:x for x in g['nodes']};assert len(node)==len(g['nodes'])
assert sum('mesh'in x for x in g['nodes'])==len(scene['parts'])
for p in scene['parts']:
 q=node[p['name']];assert np.max(np.abs(np.array(q['translation'])-p['pos']))<1e-10
from scipy.spatial.transform import Rotation
err=0
for p in scene['parts']:
 from math import radians,cos,sin
 a,b=radians(p['yaw']),radians(p.get('roll',0));ca,sa,cb,sb=cos(a),sin(a),cos(b),sin(b)
 expected=np.array([[ca*cb,-ca*sb,sa],[sb,cb,0],[-sa*cb,sa*sb,ca]])
 err=max(err,float(np.max(np.abs(Rotation.from_quat(node[p['name']]['rotation']).as_matrix()-expected))))
assert err<1e-10
stats=json.loads((P/'geometry_verification.json').read_text());assert not stats['invalid_shapes']
step=P/'SCALLION_CELL_concept_mm.step';model=cq.importers.importStep(str(step));solids=model.solids().vals();assert len(solids)==stats['cad_bodies'];bad=[i for i,s in enumerate(solids) if not s.isValid()];assert not bad
result={'glb_nodes':len(g['nodes']),'mesh_nodes':len(scene['parts']),'binary_valid':True,'all_index_ranges_valid':True,'finite_attributes':True,'max_mesh_rotation_residual':err,'step_reimport_solids':len(solids),'step_invalid_solids':bad,'unit_STEP':'mm','unit_GLB':'m','glb_sha256':hashlib.sha256(raw).hexdigest(),'step_sha256':hashlib.sha256(step.read_bytes()).hexdigest(),'scope':'Format/placement and solid-validity checks. This is not a strength, continuous collision, flexible hose, food-contact or production approval.'}
(P/'delivery_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
