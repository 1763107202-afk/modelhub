"""Dense material/CAD regression of the seven corrected obstruction groups."""
import json,sys,re,time
from pathlib import Path
import numpy as np
from collision_engine import Engine,fcl,m
src=Path(sys.argv[1]);raw=json.loads(src.read_text());allparts=list(m.PART)
max_step=max(b['t']-a['t'] for a,b in zip(raw['poses'],raw['poses'][1:]));assert max_step<=.100001
rules={'C01':r'^trim_counter_[01]$','C02':r'^(loader|unload)_grip_[01]_frame$','C03':r'^peel_head_(cross|cross_back|end_0\.1)$','C04':r'^wash_pipe_(cross|bracket)_','C06':r'^weigh_(drop|reach|cell_rear_link)_','C08':r'^grip_[0-5]_[01]_frame$','C10':r'^(grip_[0-5]_[01]|loader_grip_[01]|unload_grip_[01])_guide_'}
parts={c:[p['name'] for p in allparts if re.search(rx,p['name'])] for c,rx in rules.items()};selected={n for ns in parts.values() for n in ns};m.PART[:]=[p for p in allparts if p['name'] in selected];engine=Engine();geoms={}
for n,g in raw['geometries'].items():
 v=np.array(g['v'],float).reshape(-1,3);t=np.array(g['t'],np.int32).reshape(-1,3);b=fcl.BVHModel();b.beginModel(len(v),len(t));b.addSubModel(v,t);b.endModel();geoms[n]=(b,v.min(0),v.max(0))
req=fcl.CollisionRequest(num_max_contacts=1,enable_contact=True);hits={};count={c:0 for c in rules};tests={c:0 for c in rules};started=time.time()
for i,state in enumerate(raw['poses']):
 engine.pose(state['q']);bounds={}
 for n in selected:
  a,b=engine.bounds[n];M=engine.transforms[n];c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2);bounds[n]=(c-r,c+r)
 for case,ns in parts.items():
  if case=='C01' and state['phase'] not in ['feed','root','load']:continue
  count[case]+=1
  for ex in state['extras']:
   if not ex['product']:continue
   geom,a,b=geoms[ex['geometry']];M=np.array(ex['M']).reshape(4,4).T;c=M[:3,:3]@((a+b)/2)+M[:3,3];r=np.abs(M[:3,:3])@((b-a)/2);lo,hi=c-r,c+r;ob=None
   for n in ns:
    aa,bb=bounds[n]
    if not (np.all(lo<=bb+1e-7) and np.all(hi>=aa-1e-7)):continue
    if ob is None:ob=fcl.CollisionObject(geom,fcl.Transform(M[:3,:3],M[:3,3]))
    res=fcl.CollisionResult();tests[case]+=1;fcl.collide(ob,engine.objs[n],req,res)
    if res.is_collision:hits.setdefault(case+'|'+ex['name']+'|'+n,dict(case=case,material=ex['name'],solid=n,t=state['t'],phase=state['phase']))
 if i%400==0:print('dense pose',i,'hits',len(hits),flush=True)
out=dict(poses=len(raw['poses']),maximum_time_step_seconds=max_step,selected_cad_parts=len(selected),case_pose_counts=count,narrow_phase_calls=tests,candidates=list(hits.values()),seconds=time.time()-started,scope='Dense discrete material/CAD obstruction regression. C01 covers parked shear during feed/root/load only. Cutting-entry reaction-shoe contact remains open as C11. No continuous, containment-only, flexible or full-machine clearance certificate.')
Path('dist/downloads/exchange_clearance_checks_10.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('DONE',len(raw['poses']),len(hits),flush=True)
if hits:raise SystemExit(1)
