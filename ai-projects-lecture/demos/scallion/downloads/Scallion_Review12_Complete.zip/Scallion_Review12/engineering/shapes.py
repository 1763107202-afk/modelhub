import math,json
import numpy as np
import cadquery as cq
import kernel as d
V=cq.Vector

original_shape=d.shape_for
new_cache={}

def axis_cylinder(a,b,r):
    a,b=V(*a),V(*b);v=b-a
    return cq.Solid.makeCylinder(r,v.Length,a,v.normalized())

def filleted_box(w,h,z,r):
    obj=cq.Workplane('XY').box(w,h,z)
    try:return obj.edges().fillet(min(r,min(w,h,z)*.22)).val()
    except Exception:return obj.val()

def refined_shape(kind,ds):
    key=json.dumps([kind,ds],sort_keys=True)
    if key in new_cache:return new_cache[key]
    if kind=='softbox':
        s=filleted_box(*ds)
    elif kind=='rhs_round':
        w,h,z,t=ds;vals=[w,h,z];axis=int(np.argmax(vals));ax='XYZ'[axis]
        inside=[x-2*t for x in vals];inside[axis]=vals[axis]+.004
        r=min(.003,min(x for i,x in enumerate(vals) if i!=axis)*.15)
        outer=cq.Workplane('XY').box(*vals)
        inner=cq.Workplane('XY').box(*inside)
        try:outer=outer.edges('|'+ax).fillet(r)
        except Exception:pass
        try:inner=inner.edges('|'+ax).fillet(max(.0003,r-t))
        except Exception:pass
        s=outer.val().cut(inner.val())
    elif kind=='socket_bolt':
        r,h=ds;hr=r if h<.012 else 1.65*r
        hh=min(h*.80,r*1.5)
        s=cq.Solid.makeCylinder(r,h,V(0,-h/2,0),V(0,1,0))
        if h>=.012:s=s.fuse(cq.Solid.makeCylinder(hr,hh,V(0,h/2-hh,0),V(0,1,0)))
        pts=[V(hr*.53*math.cos(a),h/2-hh*.65,hr*.53*math.sin(a)) for a in np.linspace(0,math.tau,7)]
        recess=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts),[],V(0,hh,0))
        s=s.cut(recess)
    elif kind=='hexnut':
        r,h=ds;pts=[V(r*math.cos(a),-h/2,r*math.sin(a)) for a in np.linspace(0,math.tau,7)]
        s=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts),[],V(0,h,0))
        s=s.cut(cq.Solid.makeCylinder(r*.57,h+.002,V(0,-h/2-.001,0),V(0,1,0)))
    elif kind=='rail_detail':
        w,h,z=ds;s=filleted_box(w,h,z,.0007)
        axis=0 if w>z else 2;L=max(w,z)
        for t in np.arange(-L/2+.026,L/2-.015,.06):
            x,zz=(t,0) if axis==0 else (0,t)
            s=s.cut(cq.Solid.makeCylinder(.00225,h+.002,V(x,-h/2-.001,zz),V(0,1,0)))
            s=s.cut(cq.Solid.makeCylinder(.0038,.004,V(x,h/2-.003,zz),V(0,1,0)))
    elif kind=='axisring':
        a,b,ro,ri=ds;s=axis_cylinder(a,b,ro)
        av,bv=np.array(a),np.array(b);unit=(bv-av)/np.linalg.norm(bv-av)
        s=s.cut(axis_cylinder(av-unit*.001,bv+unit*.001,ri))
    elif kind=='cylinder_cap':
        a,b,r,ri=ds;aa,bb=np.array(a,dtype=float),np.array(b,dtype=float);u,v,w=unitbasis(aa,bb)
        pts=[V(*(aa+v*x*r+w*y*r)) for x,y in [(-1,-1),(1,-1),(1,1),(-1,1),(-1,-1)]]
        s=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts),[],V(*(bb-aa)))
        s=s.cut(axis_cylinder(aa-u*.001,bb+u*.001,ri))
    elif kind=='bearingblock':
        w,h,z=ds;s=filleted_box(w,h,z,.0016)
        for x in [-w*.32,w*.32]:
            for zz in [-z*.30,z*.30]:
                s=s.cut(cq.Solid.makeCylinder(.0025,h+.002,V(x,-h/2-.001,zz),V(0,1,0)))
    elif kind=='clevis':
        w,h,z,slot=ds;s=filleted_box(w,h,z,.001)
        s=s.cut(cq.Workplane('XY').box(slot,h*.7,z+.002).val().translate((0,h*.24,0)))
        s=s.cut(cq.Solid.makeCylinder(.003,w+.002,V(-w/2-.001,h*.18,0),V(1,0,0)))
    else:return original_shape(kind,ds)
    if not s.isValid():raise ValueError('invalid refinement '+kind)
    new_cache[key]=s
    return s


def unitbasis(a,b):
 u=np.asarray(b,dtype=float)-a;u/=np.linalg.norm(u)
 v=np.cross(u,[0,1,0] if abs(u[1])<.9 else [1,0,0]);v/=np.linalg.norm(v)
 return u,v,np.cross(u,v)
