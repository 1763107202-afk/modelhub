import json,math,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
meta=json.loads((ROOT/'dist/mechanics.json').read_text());scene=json.loads((ROOT/'engineering/scene_manifest.json').read_text());mass=json.loads((ROOT/'engineering/mass_breakdown.json').read_text());groups={g['name']:g for g in scene['groups']}
def under(n,a):
 while n:
  if n==a:return True
  n=groups[n]['parent']
 return False
profiles=json.loads((ROOT/'engineering/evidence11/motion_profiles.json').read_text())['maxima']
rows=[]
for a in meta['linear_axes']:
 M=sum(x['mass_kg'] for x in mass if under(x['parent'],a['slide']))+.50
 profile=profiles[a['name']];vmax,acc=profile['v'],profile['a']
 vertical=a['name']=='peel_scan';F=M*(acc+(9.81 if vertical else .02*9.81))+20
 L=a['L'];mscrew=7930*math.pi*.008**2*L;Js=mscrew*.008**2/2
 Jm=3e-5;Jc=8e-6
 Tl=F*.005/(2*math.pi*.9);Ta=(Js+Jm+Jc)*2*math.pi*acc/.005;T=Tl+Ta+.08
 rated=200/(3000*2*math.pi/60)
 critical=.8*60/math.tau*(3.9266**2/L**2)*math.sqrt(200e9*.012**2/(16*7930))
 rows.append({'commanded_speed_m_s':vmax,'commanded_acceleration_m_s2':acc,'critical_speed_80percent_rpm':critical,'critical_speed_margin':critical/(60*vmax/a['lead']),'axis':a['name'],'stroke_mm':a['stroke']*1000,'model_moving_mass_with_0p5kg_kg':M,'assumed_force_N':F,'estimated_torque_Nm':T,'candidate_200W_3000rpm_Nm':rated,'nominal_torque_margin':rated/T,'max_speed_rpm':60*vmax/a['lead'],'load_direction':'vertical' if vertical else 'horizontal'})
I=meta['stats']['model_rotor_Iy_kg_m2']+3*(.83**2+.97**2)/2
T=I*profiles['main_index']['a']+10;available=750/(3000*math.tau/60)*80*.85
out={'linear_axes':rows,'main_drive':{'model_and_assumed_material_inertia_kg_m2':I,'angular_acceleration_rad_s2':profiles['main_index']['a'],'angular_velocity_rad_s':profiles['main_index']['v'],'assumed_friction_Nm':10,'required_output_torque_Nm':T,'candidate_750W_80to1_available_Nm':available,'nominal_margin':available/T},'assumptions':{'linear_acceleration_m_s2':'per commanded axis profile; see rows','critical_speed_model':'Euler beam first lateral mode; beta=3.9266 fixed/supported, root diameter conservatively 12mm, E=200GPa, rho=7930kg/m3, 80% speed cap; supplier shaft root and boundary stiffness must be confirmed','horizontal_friction_coefficient':.02,'drag_N':20,'ballscrew_efficiency':.9,'motor_inertia_kg_m2':3e-5,'coupling_inertia_kg_m2':8e-6,'preload_torque_Nm':.08,'motor_rated_speed_rpm':3000,'material_allowance_per_axis_kg':.50,'main_products_total_kg':3},'limits':'Power classes are candidates, not a frozen motor/reducer purchase selection. Simplified CAD densities, assumed friction/preload and motor inertia require actual catalogue/component confirmation. Cutting reaction, guide moments, fatigue, food contact and loaded process performance are not validated.'}
(ROOT/'dist/downloads/drive_calculations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
assert all(r['critical_speed_margin']>1 and r['nominal_torque_margin']>1 for r in rows),rows
custom=[]
for name,joints,power,span in [('counter',['trim_counter_shift'],100,.63),('wrap',['wrap_jaw11_-1','wrap_jaw11_1'],200,.86),('seal',['seal_jaw11_-1','seal_jaw11_1'],200,.86)]:
 js=[j for j in meta['joints'] if j['name'] in joints]
 moving=sum(x['mass_kg'] for x in mass if any(under(x['parent'],j['child']) for j in js))
 v=max(profiles[j['name']]['v'] for j in js);ac=max(profiles[j['name']]['a'] for j in js)
 force=moving*(ac+.02*9.81)+20*len(js)
 torque=force*.003/(math.tau*.30)+(3e-5+8e-6)*math.tau*ac/.003+.08
 speed=60*v/.003;critical=.8*60/math.tau*(3.9266**2/span**2)*math.sqrt(200e9*.009**2/(16*7930))
 custom.append(dict(drive=name,lead_mm=3,handedness='opposed RH/LH' if len(js)>1 else 'single',motor_power_candidate_W=power,
  moving_mass_kg=moving,motion_only_force_N=force,motion_only_torque_Nm=torque,nominal_torque_margin=(power/(3000*math.tau/60))/torque,
  maximum_rpm=speed,critical_speed_80percent_rpm=critical,critical_speed_margin=critical/speed,
  process_reaction_included=False,scope='Motion loads only; assumed efficiency 0.30 and 9mm root. Cutting/heat-seal reaction, holding torque, guide moment and actual supplier ratings remain unverified.'))
out['custom_TR12x3_motion_only']=custom
assert all(x['critical_speed_margin']>1 and x['nominal_torque_margin']>1 for x in custom),custom
(ROOT/'dist/downloads/drive_calculations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
mm={r['name']:r for r in mass}
with (ROOT/'dist/downloads/BOM_nominal.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['Part','Rigid_group','Geometry','Material_visual_category','Nominal_CAD_mass_kg','Declared_mount','Connection','Status'])
 for p in scene['parts']:
  if p['cad']:w.writerow([p['name'],p['parent'],p['kind'],p['mat'],round(mm.get(p['name'],{}).get('mass_kg',0),5),p.get('support'),p.get('connection'),'Nominal design; supplier-CAD and production drawing not released'])
print(json.dumps({'main':out['main_drive'],'smallest_axis_margin':min(r['nominal_torque_margin'] for r in rows)},indent=2))
