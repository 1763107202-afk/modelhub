import os,json,time
from pathlib import Path
import numpy as np
from collision_engine import Engine
root=Path(__file__).resolve().parents[1];states=json.loads((root/'engineering/poses12.json').read_text())['poses']
# Include all new bodies and the three changed process tool groups; baseline
# mesh contacts are screened too when a new body is involved.
selected=set()
import collision_engine as ce
for p in ce.m.PART:
 if '12' in p['name'] or p['name'].startswith(('wrap_former11','seal_','weigh_','loadcell','out_cup')):selected.add(p['name'])
os.environ['PARTS']=','.join(sorted(selected))
e=Engine();hits={};calls=0;start=time.time();poses=states[::5]
for i,s in enumerate(poses):
 e.pose(s['q']);pairs,n=e.contacts();calls+=n
 for a,b in pairs:hits.setdefault(a+'|'+b,dict(a=a,b=b,phase=s['phase'],t=s['t'],q=s['q']))
 if i%20==0:print('pose',i,'hits',len(hits),'calls',calls,flush=True)
 out=dict(poses_checked=i+1,full_poses=len(states),stride=5,selected_components=len(selected),rigid_components=len(e.parts),narrow_phase_calls=calls,candidates=list(hits.values()),seconds=time.time()-start,scope='New or changed rigid components versus every CAD rigid body, discrete FCL surfaces. Same rigid body and named mounting contacts excluded. Flexible routes not certified.')
 (root/'dist/downloads/rigid_screen12.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('DONE',len(hits),'seconds',time.time()-start,flush=True)
