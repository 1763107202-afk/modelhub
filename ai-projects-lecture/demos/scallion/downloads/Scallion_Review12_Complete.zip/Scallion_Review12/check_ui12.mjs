import fs from 'node:fs';
import {makeProgram,evaluate} from './motion.js';
import {diagram12} from './dist/schematic12.js';
const d=JSON.parse(fs.readFileSync('dist/mechanics.json')),p=makeProgram(d,'full');let out=[];
for(const s of p.stages){const t=(s.start+s.end)/2,svg=diagram12(evaluate(p,d,t),t,p);if(/NaN|undefined|Infinity/.test(svg))throw Error('Invalid SVG '+s.id);out.push({id:s.id,svg});}
fs.writeFileSync('/workspace/scratch/cc26d361fe9d/ui12_svg_samples.json',JSON.stringify(out));console.log('Schematic states',out.length);
