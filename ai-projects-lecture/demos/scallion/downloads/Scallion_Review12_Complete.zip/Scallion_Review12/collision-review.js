import * as T from 'three';
import report from './engineering/review-cases.json';

// Case positions come from the actual published model and full-workflow screen.
// Highlighting is a diagnostic overlay, never a replacement for clearance checks.
export function createCollisionReview({seek,getModel,getScene,getCamera,getControls,getRoutes,revealRoutes}) {
  const panel=document.querySelector('#clearancePanel');
  const list=document.querySelector('#clearanceCases');
  const detail=document.querySelector('#clearanceDetail');
  const note=document.querySelector('#clearanceNote');
  let active=null,overlays=[],saved=[];
  const set=(id,value)=>document.querySelector(id).textContent=value;
  list.innerHTML=report.cases.map(c=>`<button data-case="${c.id}" class="threeOnly ${c.resolved?'resolved':''}"><span>${c.id}</span>${c.title}<b>${c.resolved?'复核':'定位'} ↗</b></button>`).join('');
  function clear() {
    for(const [object,material,replacement] of saved){object.material=material;replacement.dispose();}
    saved=[];
    for(const helper of overlays){helper.removeFromParent();helper.geometry.dispose();helper.material.dispose();}
    overlays=[];active=null;
    list.querySelectorAll('[data-case]').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
    note.textContent='点击问题，暂停到对应时刻并高亮相关部件。';
  }
  function locate(id) {
    const c=report.cases.find(c=>c.id===id);if(!c)return;
    if(!getModel()){note.textContent='三维未就绪；下方保留问题说明。';return;}
    clear();seek(c.t);if(c.parts.some(p=>p.route))revealRoutes?.();active=c;
    const model=getModel(),scene=getScene(),objects=[];
    for(const ref of c.parts){
      let object;
      if(ref.route)object=getRoutes().find(r=>r.cfg.name===ref.route)?.mesh;
      else if(ref.trace)object=ref.trace.reduce((p,r)=>p?.children.filter(c=>c.name===r.name)[r.occurrence],model);
      else if(ref.path)object=ref.path.reduce((p,i)=>p?.children[i],model);
      else model.traverse(o=>{if(o.name===ref.name)object=o;});
      if(object)objects.push(object);
    }
    if(objects.length!==c.parts.length){note.textContent='零件定位与当前模型不一致，请查看审查清单。';return;}
    const bounds=new T.Box3();
    for(const [i,object] of objects.entries()){
      const color=c.resolved?(i?0x68bfff:0x59d69b):(i?0xffb753:0xff554c);
      object.traverse(o=>{if(!o.isMesh||Array.isArray(o.material))return;const original=o.material,replacement=original.clone();replacement.color.setHex(color);replacement.emissive?.setHex(color);if('emissiveIntensity' in replacement)replacement.emissiveIntensity=.35;replacement.transparent=false;replacement.opacity=1;o.material=replacement;saved.push([o,original,replacement]);});
      bounds.union(new T.Box3().setFromObject(object));
      const helper=new T.BoxHelper(object,color);helper.material.depthTest=false;helper.material.transparent=true;helper.material.opacity=.85;helper.renderOrder=20;scene.add(helper);overlays.push(helper);
    }
    if(!bounds.isEmpty()){
      const centre=bounds.getCenter(new T.Vector3()),size=bounds.getSize(new T.Vector3());
      const radial=new T.Vector3(centre.x,0,centre.z);if(radial.lengthSq()<.01)radial.set(1,0,1);radial.normalize();
      const distance=Math.max(.65,Math.max(size.x,size.y,size.z)*2.7),camera=getCamera(),controls=getControls();
      controls.target.copy(centre);camera.position.copy(centre).addScaledVector(radial,distance).add(new T.Vector3(.13,distance*.37,.15));controls.update();
    }
    detail.hidden=false;set('#clearanceTitle',c.title);set('#clearanceProblem',c.problem);set('#clearanceAction',c.action);set('#clearanceEvidence',c.evidence+' · '+c.status);
    set('#clearanceParts',c.parts.map(p=>p.name).join(' / '));
    note.textContent=`已暂停在 ${c.t.toFixed(2)} s · ${c.resolved?'绿色 / 蓝色为复核部件':'红色 / 橙色为相关部件'}`;
    list.querySelectorAll('[data-case]').forEach(b=>{const selected=b.dataset.case===c.id;b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));});
    document.querySelector('#scenePanel').scrollIntoView?.({behavior:'smooth',block:'start'});
  }
  list.onclick=e=>{const button=e.target.closest('[data-case]');if(button)locate(button.dataset.case);};
  document.querySelectorAll('[data-open-clearance]').forEach(b=>b.onclick=()=>{panel.hidden=false;panel.scrollIntoView?.({behavior:'smooth',block:'nearest'});});
  document.querySelector('#clearanceClose').onclick=()=>{clear();panel.hidden=true;};
  document.querySelector('#clearanceClear').onclick=clear;
  return {clear,locate,report,get active(){return active;}};
}
