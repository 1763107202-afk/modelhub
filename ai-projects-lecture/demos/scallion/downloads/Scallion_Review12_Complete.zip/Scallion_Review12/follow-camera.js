// Camera smoothing stays separate from the mechanical state and timeline.
export function followStep(camera,controls,frame,dt,snap=false){
 if(!frame||[...frame.position.toArray(),...frame.target.toArray()].some(x=>!Number.isFinite(x)))return false;
 const a=snap?1:1-Math.exp(-4.5*Math.max(0,Math.min(.1,dt)));
 camera.position.lerp(frame.position,a);controls.target.lerp(frame.target,a);controls.update();return true;
}
